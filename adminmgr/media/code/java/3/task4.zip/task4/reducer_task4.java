
import java.io.IOException; 
import java.util.Map; 
import java.util.TreeMap; 
import java.util.*;
import java.util.Scanner;

import org.apache.hadoop.io.IntWritable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 
import org.apache.hadoop.mapred.*;

public class reducer_task4 extends Reducer<Text, 
					IntWritable,Text,Text> { 

	private Map<String, String > hash_map;  
	private Map<String,String> tree_map;
	
	@Override
	public void setup(Context context) throws IOException, 
									InterruptedException 
	{ 
		hash_map = new HashMap<>();
		tree_map = new TreeMap<>();
	} 

	//@Override
	public void reduce(Text key, Iterable<IntWritable> values, 
	Context context) throws IOException, InterruptedException 
	{
		int ball = 0;
		int sum = 0;
		float sr;
		for(IntWritable val:values){
			sum += val.get();
			ball +=1;
		}
		if(ball >=10){
			sr = (sum * 100) /ball;
			String[] temp = key.toString().split(",");
			
			String test= temp[1] + "," +String.valueOf(sr)+","+String.valueOf(sum);

			if(hash_map.containsKey(temp[0]))
			{
				String[] b = hash_map.get(temp[0]).split(",");
				if(sr > Float.valueOf(b[1]))
				{
					
					hash_map.put(temp[0],test);
				}
				else if(sr == Float.valueOf(b[1]))
				{
					if(Integer.valueOf(b[2]) <= sum )
					{
						hash_map.put(temp[0],test);
					}
				}
			}
			else{
				hash_map.put(temp[0],test);
			}
	 
	} 
}

	@Override
	public void cleanup(Context context) throws IOException, 
									InterruptedException 
	{
		//System.out.println(hash_map);
		tree_map.putAll(hash_map);
		for(Map.Entry<String, String> entry : tree_map.entrySet())
		{
			String[] x = entry.getValue().split(",");

			context.write(new Text(entry.getKey()) , new Text(x[0] ) );
		}

		
			
	}	
} 
