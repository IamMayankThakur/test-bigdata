import java.io.*; 
import java.util.*; 
import java.util.Map; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.IntWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class mapper_task4 extends Mapper<Object, 
							Text, Text, IntWritable> { 


	String venue;
	String batsman;
	
	@Override
	public void setup(Context context) throws IOException, 
									InterruptedException 
	{ 
		int flag =  0;
	} 


	@Override
	public void map(Object key, Text value, 
	Context context) throws IOException, 
					InterruptedException 
	{ 
		int cur_run;
		String[] tokens = value.toString().split(","); 

		if(tokens[1].equals("venue")){

			venue =tokens[2];
		}
		else if(tokens[0].equals("ball") && tokens[8].equals("0") && tokens.length >=8)
		{
			cur_run =Integer.parseInt(tokens[7]);
			batsman = tokens[4];
			context.write(new Text(venue+","+batsman) ,new IntWritable(cur_run));
		}
	
	} 

	@Override
	public void cleanup(Context context) throws IOException, 
									InterruptedException 
	{ 
		// for(Map.Entry<String, int[]> entry : hash_map.entrySet())
		// 	{

		// 		context.write(new Text(venue),new Text(entry.getKey() + ","+ entry.getValue()[0] +","+entry.getValue()[1]) );
		// 	}
		// 	hash_map.clear();
			
	} 
} 	
