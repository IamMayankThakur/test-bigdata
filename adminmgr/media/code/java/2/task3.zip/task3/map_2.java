
import java.io.*;
import java.util.*;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class map_2 extends Mapper<Object, Text, Text, IntWritable>
 {
	String bman;
	String bowler;

	public void map(Object key, Text value,Context context)
   throws IOException,InterruptedException
	{
		String[] itr = value.toString().split(",");

		if(itr.length >=8){
			bman = itr[4];
			bowler = itr[6];
			String run=itr[7];

			context.write(new Text(bowler +","+bman) ,new IntWritable(Integer.parseInt(run)));
		}
	}

}
