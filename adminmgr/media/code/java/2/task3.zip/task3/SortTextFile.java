import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
 
class SortBasedOnWic
{
	int wic;
    int run;
    String name1;
	String name2;
   
    public SortBasedOnWic(int w,int r,String n1,String n2) 
    {
        
		wic = w;	
		run = r;
		name1 = n1;
		name2 = n2;
    }
}

 
class wiccompare implements Comparator<SortBasedOnWic>
{
    @Override
    public int compare(SortBasedOnWic s1, SortBasedOnWic s2)
    {
        int diff_wic = s2.wic - s1.wic;
		if(diff_wic > 0 || diff_wic < 0)		
			return diff_wic;
		else
		{
			int diff_run = s2.run-s1.run;
			if(diff_run == 0)
				return (s2.name1).compareTo(s1.name1);
			else 
				return diff_run;
		}    
	}
}
 
class SortTextFile
{
    public static void main(String[] args)throws IOException
    {
        //Creating BufferedReader object to read the input text file
         
        BufferedReader reader = new BufferedReader(new FileReader("/home/manoj/Downloads/out2.txt"));
         
        //Creating ArrayList to hold Student objects
         
        ArrayList<SortBasedOnWic> records = new ArrayList<SortBasedOnWic>();
         
        //Reading Student records one by one
         
        String currentLine = reader.readLine();
         
        while (currentLine != null)
        {
            String[] detail = currentLine.split(",");
			String readname1 = detail[0];
			String readname2 = detail[1];
			int readwic = Integer.valueOf(detail[2]);             
            int readrun = Integer.valueOf(detail[3]);
         
            //Creating Student object for every student record and adding it to ArrayList
             
            records.add(new SortBasedOnWic(readwic,readrun,readname1,readname2));
             
            currentLine = reader.readLine();
        }
         
        //Sorting ArrayList studentRecords based on marks
         
        Collections.sort(records, new wiccompare());
         
        //Creating BufferedWriter object to write into output text file
         
        BufferedWriter writer = new BufferedWriter(new FileWriter("/home/manoj/Desktop/finaloutput2.txt"));
         
        //Writing every studentRecords into output text file
         
        for (SortBasedOnWic res : records) 
        {
			//System.out.println(res.wic+" "+res.run+" "+res.name1+" "+res.name2+"\n");
			writer.write(res.name1);   
			writer.write(","+res.name2);         
			writer.write(","+res.wic);
			writer.write(","+res.run);
            
			
            writer.newLine();
        }
         
        //Closing the resources
         
        reader.close();
         
        writer.close();
    }
}

