import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.*;
import java.util.Scanner;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapred.*;



public class reduce_1 extends Reducer<Text,IntWritable,Text,IntArrayWritable> {
	private Map<String, int[]> hash_map;

	public void setup(Context context)
	 throws IOException,InterruptedException
	{
		hash_map = new HashMap<>();
	}

	public void reduce(Text key, Iterable<IntWritable> values, Context context)
	 throws IOException,InterruptedException
	{
		int wickets = 0;
		IntWritable v;
		int balls = 0;
		String itr1 = key.toString();


		for(IntWritable val :values){
			wickets += val.get();
			balls +=1;
		}
		int []arr={wickets,balls};
		hash_map.put(itr1,arr);	//HashMap contains an array of the nodes.

	}

	public void cleanup(Context context)
	 throws IOException,InterruptedException
	{
		int temp;
		List names = new ArrayList<String>();
		List wickets = new ArrayList<Integer>();
		List ball_faced = new ArrayList<Integer>();

		for(Map.Entry<String, int[]> entry : hash_map.entrySet())
		{
			int wicket = entry.getValue()[0];
			int balls = entry.getValue()[1];
			String name_q = entry.getKey();
			if( balls >5)
			{
				if(names.size()==0){
					names.add(name_q);
					wickets.add(wicket);
					ball_faced.add(balls);
				}
				else{
					Iterator itr2 =wickets.iterator();
					while(itr2.hasNext())
					{
						//Integer q=it.next();
						temp = (int) itr2.next();
						if(wicket > temp){
							int i = wickets.indexOf(temp);
							wickets.add(i,wicket);
							names.add(i,name_q);
							ball_faced.add(i,balls);
							break;
						}
						else if(wicket == temp)
						{
							//comparing balls....
							int k=0;
							int i = wickets.indexOf(temp);
							while(itr2.hasNext() && temp == wicket && balls > (int)ball_faced.get(i+k))
							{
								temp = (int)itr2.next();
								k++;
							}

							if(balls ==(int)ball_faced.get(i+k))
							{
								//comparing names....
								int j=0;
								while(name_q.compareTo((String)names.get(i+j+k)) > 0
										 && balls ==(int)ball_faced.get(i+j+k)&&wicket== 												(int)wickets.get(i+j+k))
									j+=1;


								names.add(i+j+k,name_q);
								ball_faced.add(i+j+k,balls);
								wickets.add(i+j+k,wicket);
							}
							else
							{
								wickets.add(i+k,wicket);
								ball_faced.add(i+k,balls);
								names.add(i+k,name_q);
							}
							break;
						}
					}
				}
			}
		}
		Iterator<String> it1 = names.iterator();
		Iterator<Integer> it2 = wickets.iterator();
		Iterator<Integer>it3 = ball_faced.iterator();
		IntWritable x1 = new IntWritable();
		IntWritable x2 =new IntWritable();
		IntWritable[] arr2 = new IntWritable[2];


			while(it1.hasNext() && it2.hasNext() && it3.hasNext()){

				x1.set(it2.next());
				x2.set(it3.next());

				arr2[0] = x1;
				arr2[1] = x2;


				context.write(new Text(it1.next() ),new IntArrayWritable(arr2));
			}
	}
}
