
import java.io.*;
import java.util.*;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class map_1 extends Mapper<Object, Text, Text, IntWritable>
 {
	String bman;
	String bowler;

	public void map(Object key, Text value,Context context)
   throws IOException,InterruptedException
	{
		String[] itr = value.toString().split(",");

		if(itr.length >=8){
			bman = itr[4];
			bowler = itr[6];
			String str=itr[9];

			if(str.length() == 2 || str.equals("run out") || str.equals("retired hurt"))
      {
				context.write(new Text(bman+","+bowler), new IntWritable(0));
			}
			else {
				context.write(new Text(bman +","+bowler) ,new IntWritable(1));
			}
		}
	}

}
