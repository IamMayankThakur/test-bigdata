
import java.io.*; 
import java.util.*; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.IntWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class mapper_test extends Mapper<Object, 
							Text, Text, IntWritable> { 



	String batsman;
	String bowler;


	@Override
	public void map(Object key, Text value, 
	Context context) throws IOException, 
					InterruptedException 
	{ 
		String[] tokens = value.toString().split(","); 
		
		if(tokens.length >=8){
			batsman = tokens[4];
			bowler = tokens[6];
			String s=tokens[9];
			//System.out.println(s.length());
			//System.out.println(s);
			if(s.length() == 2 || s.equals("run out") || s.equals("retired hurt") ){
				context.write(new Text(batsman+","+bowler), new IntWritable(0));
			}
			else {
				context.write(new Text(batsman +","+bowler) ,new IntWritable(1));
			}
		}
	} 

	@Override
	public void cleanup(Context context) throws IOException, 
									InterruptedException 
	{ 
		
			
	} 
} 	
