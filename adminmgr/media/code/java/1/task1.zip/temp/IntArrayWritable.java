
import java.io.IOException; 
import java.util.Map; 
import java.util.TreeMap; 
import java.util.*;
import java.util.Scanner;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 
import org.apache.hadoop.mapred.*;

public class IntArrayWritable extends ArrayWritable{
	private IntWritable[] intw;
	public IntArrayWritable(IntWritable[] intw){
		super(IntWritable.class,intw);
		this.intw= intw;
	}
	@Override
	public IntWritable[] get(){
		return (IntWritable[]) super.get();
	}
	@Override
	public String toString(){
		IntWritable[] intw =get();
		return intw[0].toString() + ","+intw[1].toString();
	}

}