import java.io.IOException; 
import java.util.Map; 
import java.util.TreeMap; 
import java.util.*;
import java.util.Scanner;

import org.apache.hadoop.io.ArrayWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 
import org.apache.hadoop.mapred.*;



public class reducer_test extends Reducer<Text, 
					IntWritable, Text,IntArrayWritable> { 




	private Map<String, int[]> hash_map; 
	
	@Override
	public void setup(Context context) throws IOException, 
									InterruptedException 
	{ 
		hash_map = new HashMap<>(); 
	} 

	//@Override
	public void reduce(Text key, Iterable<IntWritable> values, 
	Context context) throws IOException, InterruptedException 
	{

		int sum = 0;
		IntWritable v;
		int ball = 0;
		String name = key.toString(); 

		
		for(IntWritable val :values){

			sum += val.get();
			ball +=1;

		}
		int []arr={sum,ball};
		hash_map.put(name,arr);
	 
	} 

	@Override
	public void cleanup(Context context) throws IOException, 
									InterruptedException 
	{
	
		
		int temp;
		List list_names = new ArrayList<String>();
		List list_wickets = new ArrayList<Integer>();
		List list_ball_faced = new ArrayList<Integer>();

		System.out.println("Here--------------------");

		for(Map.Entry<String, int[]> entry : hash_map.entrySet()) 
		{
			int wicket = entry.getValue()[0];
			int balls = entry.getValue()[1];
			String name_q = entry.getKey();
			if( balls >5)
			{
				if(list_names.size()==0){
					list_names.add(name_q);
					list_wickets.add(wicket);
					list_ball_faced.add(balls); 
				}
				else{
					Iterator it =list_wickets.iterator();
					while(it.hasNext())
					{
						//Integer q=it.next();
						temp = (int) it.next();
						if(wicket > temp){
							int i = list_wickets.indexOf(temp);
							list_wickets.add(i,wicket);
							list_names.add(i,name_q);
							list_ball_faced.add(i,balls);
							break;
						}
						else if(wicket == temp)
						{
							//comparing balls....
							int k=0;
							int i = list_wickets.indexOf(temp); 
							while(it.hasNext() && temp == wicket && balls > (int)list_ball_faced.get(i+k))
							{
								temp = (int)it.next();
								k++;
							}

							if(balls ==(int)list_ball_faced.get(i+k))
							{
								//comparing names....
								int j=0;
								while(name_q.compareTo((String)list_names.get(i+j+k)) > 0
										 && balls ==(int)list_ball_faced.get(i+j+k) && wicket == (int)list_wickets.get(i+j+k))
								{
									j+=1;
								}
								
								list_names.add(i+j+k,name_q);
								list_ball_faced.add(i+j+k,balls);
								list_wickets.add(i+j+k,wicket);
							}
							else
							{
								list_wickets.add(i+k,wicket);
								list_ball_faced.add(i+k,balls);
								list_names.add(i+k,name_q);
							}
							break;
						}
					}
				} 
			}
		}
			Iterator<String> it1 = list_names.iterator();
			Iterator<Integer> it2 = list_wickets.iterator();
			Iterator<Integer>it3 = list_ball_faced.iterator();
			IntWritable x1 = new IntWritable();
			IntWritable x2 =new IntWritable(); 
			IntWritable[] ar = new IntWritable[2];
			
			
			while(it1.hasNext() && it2.hasNext() && it3.hasNext()){

				x1.set(it2.next());
				x2.set(it3.next());
				
				ar[0] = x1;
				ar[1] = x2;

				
				context.write(new Text(it1.next() ),new IntArrayWritable(ar));
			}
	}	
} 

