import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.data.Stat;



public class watches
{
 private static final Logger LOG = Logger.getLogger(watches.class);
 private static ZooKeeper zk;
 private static ZooKeeperConnection conn;
 private static String watchedNodePath;
 private static String processNodePath;

 public static void setwatches(String node,int id)
 {
  String path="/"+node;
  printTime pt=new printTime();
  try{
  final List<String> childNodePaths=zk.getChildren(path,false);
  Collections.sort(childNodePaths);
  //System.out.println(path);
  //if(int index = childNodePaths.indexOf(processNodePath.substring(processNodePath.lastIndexOf('/') + 1)))==null){System.out.println(path);}
  int index= id-1; 
  if(index==0)
  {
   if(LOG.isInfoEnabled()) {
				System.out.println("[Process: " + id + "] I am the new leader!");
				pt.waitMethod();
			}
		} else {
			int number=id-1;
//			System.out.println(number);
			final String watchedNodesShortPath = path+"/"+number;
//			System.out.println(watchedNodesShortPath);
			Stat status=zk.exists(watchedNodesShortPath,false);
			if(status==null)
			{
			 System.out.println("[Process: " + id + "] I am the new leader!");
			 pt.waitMethod();
			}
			else{
			final String watchedNodeShortPath = childNodePaths.get(index - 1);
			
				watchedNodePath = path + "/" + watchedNodeShortPath;
			
				if(LOG.isInfoEnabled()) {
				System.out.println("[Process: " + id + "] - Setting watch on process with path: " + watchedNodePath);
			}
			} 
			
}
 }
 catch (KeeperException | InterruptedException e) {
			throw new IllegalStateException(e);
		}
 }

 public static void createSubProcess(String node,int id) throws KeeperException,InterruptedException
 {
  String path="/"+node+"/"+id;
  processNodePath=zk.create(path, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.PERSISTENT);
  System.out.println("Process P"+id+" Created with Path "+processNodePath);
 }

 public static void main(String[] args)
 {
  String node="fsc_ZooKeeper_Election";
  int id=Integer.valueOf(args[0]);
  
  try
  {
   conn=new ZooKeeperConnection();
   zk=conn.connect("localhost");
   String path="/"+node+"/"+id;
   Stat status=zk.exists(path,false);
   if(status==null)
   	createSubProcess(node,id);
   setwatches(node,id);
   conn.close();
  }
  catch (Exception e)
  {
   System.out.println(e.getMessage());
  }
  
 }

}
