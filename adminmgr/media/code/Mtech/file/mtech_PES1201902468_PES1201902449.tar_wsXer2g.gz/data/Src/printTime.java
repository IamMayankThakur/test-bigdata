import java.util.Calendar;

 
public class printTime {
 

	public synchronized void waitMethod() {
 
		while (true) {
			System.out.println(Calendar.getInstance().getTime());
			try {
				this.wait(2000);
			} catch (InterruptedException e) {
 
				e.printStackTrace();
			}
		}
 
	}
}
