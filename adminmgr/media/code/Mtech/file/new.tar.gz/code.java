public class ThreadSleep{
public static void main(static args[])throw InterruptedException
{
long start=System.currentTimeMillis();
Thread.seep(2000);
    System.out.println("Sleep time in ms ="+(System.currentTimeMillis()-star));
}
}
