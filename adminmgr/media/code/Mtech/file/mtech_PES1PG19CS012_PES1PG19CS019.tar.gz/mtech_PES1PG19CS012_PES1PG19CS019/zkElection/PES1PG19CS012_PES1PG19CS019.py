import time
import threading
from datetime import datetime
import null as null
from kazoo.client import KazooClient

# global variables
t = threading.Condition()
election = null
tl = null
terminate = 1
isFirstTime = 1


def zookeeper_connect():
    global election, t
    # connect to zookeeper client
    zk = KazooClient("localhost:2181/disbLocking")
    # start zookeeper client
    zk.start()

    # accept user id as a command line argument
    election = zk.Election("/fsc/nodes", threading.current_thread().getName())
    print("pid " + threading.current_thread().getName() + " is connected to zookeeper")
    election.run(leader_func)


def leader_op():
    global terminate
    while 1:
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        print("Pid = " + threading.current_thread().getName() + " Current time = " + current_time)
        time.sleep(5)
        if terminate == 0:
            print("pid " + threading.current_thread().getName() + " is terminated")
            terminate = 1
            break


# what should the leader do? - is defined by the following function
def leader_func():
    global tl, isFirstTime

    tl = threading.current_thread().getName()
    print("\npid " + threading.current_thread().getName() + " became the leader\n")
    time.sleep(5)

    if isFirstTime == 1:
        leader_op()
        isFirstTime = 0
    else:
        tn = threading.Thread(target=child, args=())
        tn.start()
        leader_op()
        print("pid "+tn.getName()+" is created")


def child():
    # connect to zookeeper
    zookeeper_connect()


def parent():
    global election, t, tl, terminate

    t1 = threading.Thread(name='T1', target=child)
    t2 = threading.Thread(name='T2', target=child)
    t3 = threading.Thread(name='T3', target=child)

    t1.start()
#    t1.join()
    t2.start()
#    t2.join()
    t3.start()

    while 1:
        time.sleep(30)
        if tl != null:
            tl = null
            terminate = 0


parent()
