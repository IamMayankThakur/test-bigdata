import time, sys
from kazoo.client import KazooClient
from pip._vendor.distlib.compat import raw_input

# connect to zookeeper client
zk=KazooClient("localhost:2181/disbLocking")
# start zookeeper client
zk.start()
# accept user id as a command line argument
userId=sys.argv[1]
with zk.Lock("/fsc/nodes", userId):
	print("Obtained lock")
	time.sleep(60)
	print("Done")
print("Released lock")
