package con.zooktutorial.app;

import java.util.Calendar;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;




public class CreateZNode {
      private static final String LEADER_ELECTION_ROOT_NODE = null;
	private static ZooKeeper zk;
      private static ZkConnector zkc;
      public static List<String> znodeList = new ArrayList<String>();
      public static void create(String path, byte[] data)throws KeeperException, InterruptedException
      {
      zk.create(path, data, Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
      
}
public static void main(String[] args) throws IllegalStateException, IOException, InterruptedException, KeeperException
{
	String path = "/myparentnode";
	byte[] data="sample znode data".getBytes();
	
	zkc=new ZkConnector();
	zk=zkc.connect("localhost");
	create(path,data);
	

	znodeList=zk.getChildren("/", true);
	
	for (String znode : znodeList)
	{
		System.out.println(znode);
	}
	{
		  String node=path+"/P_";
		  String node1=path+"/P_";
		  String node2=path+"/P_";
		  
		  Object processNodePath = zk.create(node, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.EPHEMERAL_SEQUENTIAL);
		  Object processNodePath1 = zk.create(node1, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.EPHEMERAL_SEQUENTIAL);
		  Object processNodePath2 = zk.create(node2, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.EPHEMERAL_SEQUENTIAL);

		
		System.out.println("Process P childnode with Path "+processNodePath);
		System.out.println("Process P childnode with Path "+processNodePath1);
		System.out.println("Process P childnode with Path "+processNodePath2);

		 }
}
public synchronized void waitMethod() {
	 
	while (true) {
		System.out.println(Calendar.getInstance().getTime());
		try {
			this.wait(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

}

 private String node,node1,node2;
	 private void LeaderPosition() {
			
			final List<String> childNodePaths = zooKeeperService.getChildren(LEADER_ELECTION_ROOT_NODE, false);			
			Collections.sort(childNodePaths);
			
			int index = childNodePaths.indexOf(processNodePath.substring(processNodePath.lastIndexOf('/') + 1));
			Object LOG;
			if(index == 0) {
				if(LOG.isInfoEnabled()) {
					LOG.info("[Process: " + id + "] I am the new leader!");
				}
			} else {
				final String watchedNodeShortPath = childNodePaths.get(index - 1);
				
				String watchedNodePath = LEADER_ELECTION_ROOT_NODE + "/" + watchedNodeShortPath;
				
				if(LOG.isInfoEnabled()) {
					LOG.info("[Process: " + id + "] - Setting watch on node with path: " + watchedNodePath);
				}
				zooKeeperService.watchNode(watchedNodePath, true);
			}
		}
	



}




	
	
		
		
