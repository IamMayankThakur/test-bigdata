package con.zooktutorial.app;


import java.io.IOException;
import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

public class zooKeeperService {
	
	private ZooKeeper zooKeeper;
	
	public zooKeeperService(final String url) throws IOException {
		Watcher processNodeWatcher = null;
		zooKeeper = new ZooKeeper(url, 3000, processNodeWatcher);
	}

	public static List<String> getChildren(String leaderElectionRootNode, boolean b) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void watchNode(String watchedNodePath, boolean b) {
		// TODO Auto-generated method stub
		
	}

	}

