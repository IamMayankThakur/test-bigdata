ZookeeperConnection.java file which connects to the ZooKeeper, basically it is a Connection File.

CreateNode.java File which creates a PERSISTENT Node in ZooKeeper and name of the node is fsc_ZooKeeper_Election and data as FSC Assignment ZooKeeper Election. 
Path will be /fsc_ZooKeeper_Election.

watches.java file which creates a SubNodes inside the node fsc_ZooKeeper_Election node and the type of the node is EPHEMERAL_SEQUENTIAL.

if we simultaneously run the watches.java file for 3 time it'll create 3 subnode(Process) and the first node will be having the Highest Priority which will become a the Leader and is watched by the successor node.

Leader Node will always (Executes printTime.java)prints the data and Current Time.

if the Leader Process/Node is Deleted it's task has be carried by its successor node and which be the leader node.
