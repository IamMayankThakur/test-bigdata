import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.data.Stat;



public class watches
{
 private static final Logger LOG = Logger.getLogger(watches.class);
 private static ZooKeeper zk;
 private static ZooKeeperConnection conn;
 private static String watchedNodePath;
 private static String processNodePath;
 private static int id;
 private static String path="/fsc_ZooKeeper_Election";
 private static boolean flag=false;
 private static boolean done=false;

 public static boolean watchNode(final String node, final boolean watch) {
		
		boolean watched = false;
		try {
			final Stat nodeStat =  zk.exists(node, watch);
			
			if(nodeStat != null) {
				watched = true;
			}
			
		} catch (KeeperException | InterruptedException e) {
			throw new IllegalStateException(e);
		}
		
		return watched;
	}


 public static void setwatches()
 {
  try
  {
   final List<String> childNodePaths=zk.getChildren(path,false);
   Collections.sort(childNodePaths);
   int index = childNodePaths.indexOf(processNodePath.substring(processNodePath.lastIndexOf('/') + 1));
   if(index==0)
   {
    if(LOG.isInfoEnabled())
    {
     System.out.println("\n[Process: P" + id + "] "+processNodePath+" I am the new leader!");
     flag=true;
    }
   }
   else
   {
    final String watchedNodeShortPath = childNodePaths.get(index - 1);
    watchedNodePath=path+"/"+watchedNodeShortPath;
    if(!done)
    if(LOG.isInfoEnabled())
    {
     done=true;
     System.out.println("[Process: " + id + "] - Setting watch on node with path: " + watchedNodePath);
    }
    watchNode(watchedNodePath, true);
   }
  }
 catch(KeeperException | InterruptedException e)
 {
  throw new IllegalStateException(e);
 }
}

 public static void createSubProcess() throws KeeperException,InterruptedException
 {
  String node=path+"/P_";
  processNodePath=zk.create(node, null, ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.EPHEMERAL_SEQUENTIAL);
  System.out.println("Process P"+id+" Created with Path "+processNodePath);
 }

 public static void main(String[] args)
 {
  id=Integer.valueOf(args[0]);
  try
  {
   conn=new ZooKeeperConnection();
   zk=conn.connect("localhost");
   createSubProcess();
   while(true)
   {
    setwatches();
    if(flag)
    {
     printTime pt=new printTime();
     pt.waitMethod();
     conn.close();
    }
   }
  }
  catch (Exception e)
  {
   System.out.println(e.getMessage());
  }
 }
}
