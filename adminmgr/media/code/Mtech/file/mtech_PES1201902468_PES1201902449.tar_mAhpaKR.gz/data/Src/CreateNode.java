import java.io.IOException;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs;

public class CreateNode
{

 private static ZooKeeper zk;
 private static ZooKeeperConnection conn;
 
 public static void createMainNode(String node,byte[] data) throws KeeperException,InterruptedException
 {
  String path="/"+node;
  zk.create(path,data,ZooDefs.Ids.OPEN_ACL_UNSAFE,CreateMode.PERSISTENT);
  System.out.println("Node "+path+" Created Successfully");
 }

 public static void main(String[] args)
 {
  String node="fsc_ZooKeeper_Election";
  byte[] data = "FSC Assignment ZooKeeper Election".getBytes();
  
  try
  {
   conn=new ZooKeeperConnection();
   zk=conn.connect("localhost");
   createMainNode(node,data);
   conn.close();
  }
  catch (Exception e)
  {
   System.out.println(e.getMessage());
  }
  
 }
}
