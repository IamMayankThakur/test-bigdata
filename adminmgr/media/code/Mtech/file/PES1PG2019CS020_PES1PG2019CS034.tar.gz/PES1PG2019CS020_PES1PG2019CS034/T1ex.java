//package com.zetcode;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
public class T1ex{
	public static void main(String args[]){
		int i=0,ipid,ipid1,ipid2;
		//pid1,pid2;
		ProcessBuilder pb=new ProcessBuilder();
		try{
			Process p=pb.start();		
			/*long pid=p.pid();
			ipid=(int) pid;*/
		/*catch(Exception e){
			System.out.println(e);		
		}*/
			if(p.isAlive()){//ipid==0){
				System.out.println("process 1");// pid= %d"+getpid());		
				DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
				while(i<5){
					LocalDateTime now=LocalDateTime.now();
					System.out.println("Current Time is "+dtf.format(now));		
					try{
						Thread.sleep(5000);
					}catch(Exception e){
						System.out.println(e);		
					}
					i++;
				}
			}/*catch(Exception e){
			System.out.println(e);		
		}*/
			else{
				ProcessBuilder pb1=new ProcessBuilder();
				try{
					Process p1=pb1.start();		
					/*long pid1=p1.pid();
				ipid1=(int) pid1;*/
			/*}catch(Exception e){
				System.out.println(e);		
			}*/
					if(p1.isAlive()){//ipid1==0){
						System.out.println("process 2");// pid= %d"+getpid());		
						DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
						while(i<5){
							LocalDateTime now=LocalDateTime.now();
							System.out.println("Current Time is "+dtf.format(now));		
							try{
								Thread.sleep(5000);
							}catch(Exception e){
								System.out.println(e);		
							}
							i++;
						} //eof while
					}/*eof if p1 catch(Exception e){
					System.out.println(e);		
					}*/
					else{
						ProcessBuilder pb2=new ProcessBuilder();
						try{
							Process p2=pb2.start();		
					/*long pid2=p2.pid();
					ipid2=(int) pid2;*/
				/*}catch(Exception e){
					System.out.println(e);		
				}*/
							if(p2.isAlive()){//ipid2==0){
								System.out.println("process 3");// pid= %d"+getpid());		
								DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
								while(i<5){
									LocalDateTime now=LocalDateTime.now();
									System.out.println("Current Time is "+dtf.format(now));		
									try{
										Thread.sleep(5000);
									}catch(Exception e){
										System.out.println(e);		
									}
									i++;
								}//eof while
							}//eof p2
							else{
								Thread.sleep(3000);
							}
						}catch(Exception e){ //eof try p2
							System.out.println(e);		
						}
					}//eof else p2
				}catch(Exception e){
					System.out.println(e);		
				}	
			}
		}catch(Exception e){
			System.out.println(e);		
		}
	}
}
