package Assignment1Package;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import java.util.Date;

class ProcessWatcher implements Watcher{
    int id;

    public ProcessWatcher(int id){
        this.id = id;
    }

    @Override
    public void process(WatchedEvent we) {			
        if(EventType.NodeDeleted.equals(we.getType())) {
            //If the watched Node is deleted then this Node will be the leader.
            System.out.println("Process " + id + " is the leader...");
            MyLogger.printLog("Process " + id + " - Starting a New Process With ID : " + (id + 2));
            ProcessNode.StartNewProcess(String.valueOf(id + 2));
            MyLogger.printTime("Process " + id);
        }	
    }
}