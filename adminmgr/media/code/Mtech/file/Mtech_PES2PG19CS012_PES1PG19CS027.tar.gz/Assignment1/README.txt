just Execute the file buildScript.sh i.e(./buildScript.sh)
