#!/bin/sh

sudo ./apache-zookeeper-3.5.6-bin/bin/./zkServer.sh start
java -cp ./apache-zookeeper-3.5.6-bin/lib/*:. Assignment1Package.ProcessCreator

