package Assignment1Package;

class ProcessCreator{
    public static void main(String[] args) throws Exception{
        ProcessNode.StartNewProcess("1");
        Thread.sleep(200);
        ProcessNode.StartNewProcess("2");
        Thread.sleep(200);
        ProcessNode.StartNewProcess("3");
        Thread.sleep(200);
        while(true);
        
        // Runtime.getRuntime().addShutdownHook(new Thread()
        // {
        //     @Override
        //     public void run()
        //     {
        //         while(true);
        //     }
        // });
    }
}