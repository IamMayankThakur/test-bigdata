package Assignment1Package;

class DoLeaderElection {	
	public static void main(String[] args){
		final int id = Integer.valueOf(args[0]);
		ProcessNode process = new ProcessNode(id);
		process.CreateNodesAndAttemptForLeader();
		while(true);
	}
}