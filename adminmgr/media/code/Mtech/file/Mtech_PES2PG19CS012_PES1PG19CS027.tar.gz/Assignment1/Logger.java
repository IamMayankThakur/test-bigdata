package Assignment1Package;

import java.util.Date;

class MyLogger{

    static void printTime(String message){
        try{
           while(true){
                System.out.println(message + " : " + new Date());
                Thread.sleep(5000);
            }
        }catch(Exception e){
            printException(e, "Printing Time");
        }
    }

    static void printException(Exception e, String message){
        System.out.println(message + " : " + e);
    }

    static void printLog(String message){
        System.out.println(message);
    }
}