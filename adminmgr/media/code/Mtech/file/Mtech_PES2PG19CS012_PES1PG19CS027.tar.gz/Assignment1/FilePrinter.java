package Assignment1Package;

import java.io.*;

class FilePrinter{

    //static File file = new File("time.txt");
    // static File errorFile = new File("error.txt");
    // static File logFile = new File("log.txt");

    // public static void PrintTime(String message){
    //     try{
    //         FileWriter fr = new FileWriter(file, true);
    //         fr.write(message + "\n");
    //         fr.close();
    //     }
    //     catch(Exception e){
    //     }
    // }

    // public static void PrintError(Exception e, String messString){
    //     try{
    //         FileWriter fr = new FileWriter(errorFile);
    //         fr.write(messString + " : " + e);
    //         fr.close();
    //     }
    //     catch(Exception ex){
    //     }
    // }

    // public static void PrintLog(String message){
    //     try{
    //         FileWriter fr = new FileWriter(logFile);
    //         fr.write(message + "\n");
    //         fr.close();
    //     }
    //     catch(Exception ex){
    //     }
    // }

}