package Assignment1Package;

public class Constants{
    public static final String ZookeeperUrl = "localhost";
    public static final String ROOTNAME = "/election1";
    public static final String NODENAME = ROOTNAME + "/process_";
    public static final String ZookeeperPath = "./apache-zookeeper-3.5.6-bin";
    public static final String ClassPath = ZookeeperPath + "/lib/*:.";
    public static final String MainClass = "Assignment1Package.DoLeaderElection";
    public static final String CommandOptions = "-cp";
}