package Assignment1Package;

import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.Watcher.Event.EventType;
import org.apache.zookeeper.CreateMode;
import java.util.List;

public class zook{

    ZooKeeper zookeeper;

    public zook(String url, ProcessWatcher processWatcher) throws Exception{
        zookeeper = new ZooKeeper(url, 5000, processWatcher);
    }

    public String CreateNewNode(String path, CreateMode nodeType){
        try{
            //False is to specify not to set any Watch on that node.
            //if(zookeeper.exists(path, false) == null) 
            if(!IsNodePresent(path)) 
                return zookeeper.create(path, path.getBytes(), Ids.OPEN_ACL_UNSAFE, nodeType);
            else
                throw new Exception("Node already Exists");
        }
        catch(Exception e){
            MyLogger.printException(e, "Create Node");
        }
        return path;
    }

    public boolean IsNodePresent(String path){
        try{
            return zookeeper.exists(path, false) == null ? false : true;
        }
        catch(Exception e){
            MyLogger.printException(e, "IsNodePresent");
        }
        return false;
    }

    public void WatchOnNode(String node){
        try{
            zookeeper.exists(node, true);
        }
        catch(Exception e){
            MyLogger.printException(e, "Watch Node");
        }
    }

    public List<String> GetChildrenOfNode(String node) {
		try {
            //False is not to set any watch...
			return zookeeper.getChildren(node, false);
        } catch (Exception e) {
            MyLogger.printException(e, "Get Children");
            return null;
		}		
    }
    
    public void close(){
        try{
            zookeeper.close();
        }
        catch(Exception e){
            MyLogger.printException(e, "Closing Z-Node");
        }
    }
}