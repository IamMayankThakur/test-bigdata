package Assignment1Package;

import java.lang.ProcessBuilder.Redirect;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.apache.zookeeper.CreateMode;

class ProcessNode{
    int processId;
    String processNode;
    zook zookeeper;

    public ProcessNode(int id){
        try{
            processId = id;
            zookeeper = new zook(Constants.ZookeeperUrl, new ProcessWatcher(id));
        }catch(Exception ex){
            MyLogger.printException(ex, "Process Node(Constructor)");
        }
    }

    boolean attemptForLeaderPosition() {
        List<String> childNodePaths = zookeeper.GetChildrenOfNode(Constants.ROOTNAME);
        Collections.sort(childNodePaths);
        int indexOfThisProcess = childNodePaths.indexOf(processNode);
		if(indexOfThisProcess == 0) {
            MyLogger.printLog("Process " + processId + " is the leader...");
            return true;
		} else {
			String processNodeToBeWatched = Constants.ROOTNAME + "/" + childNodePaths.get(indexOfThisProcess - 1);			
            zookeeper.WatchOnNode(processNodeToBeWatched);
            return false;
		}
    }
    
    void CreateNodesAndAttemptForLeader(){
        if(!zookeeper.IsNodePresent(Constants.ROOTNAME))
            zookeeper.CreateNewNode(Constants.ROOTNAME, CreateMode.PERSISTENT);
        String fullNodePath = zookeeper.CreateNewNode(Constants.NODENAME, CreateMode.EPHEMERAL_SEQUENTIAL); //Returns the full path.
        processNode = fullNodePath.substring(fullNodePath.lastIndexOf('/') + 1); //Taking out only the process Node Name.
        if(attemptForLeaderPosition()){//Executes only for first process.
            MyLogger.printTime("Process " + processId);
        }
    }

    void CreateRootNode(){
        zookeeper.CreateNewNode(Constants.ROOTNAME, CreateMode.PERSISTENT);
    }

    void CloseConnection(){
        try{
            zookeeper.close();
        }
        catch(Exception e){
            MyLogger.printException(e, "Closing Zookeeper Connection");
        }
    }

    static void StartNewProcess(String ProcessId){
        try{
            ProcessBuilder process = new ProcessBuilder("java", Constants.CommandOptions, Constants.ClassPath, Constants.MainClass, ProcessId);
            process.redirectOutput(Redirect.INHERIT);
            process.start();
        }catch(Exception ex){
            MyLogger.printException(ex, "Starting Process");
        }
    }
}