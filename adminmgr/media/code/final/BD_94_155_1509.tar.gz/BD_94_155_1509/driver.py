import os

file_1 = open('CLI_Query.txt','w')
query = input("Enter the SQL Query: ")
file_1.write(query)
file_1.close()

query_l = query.split()

if(query_l[0]=="LOAD" or query_l[0]=="load"):
	#Parse through the query
	path = query_l[1].split("/")
	database_name = path.split[0]
	csv_name = path.split[1]
	table_name = csv_name.split(".")[0]
	
	inter_schema = query_l[3][1:(len(query_l[3])-1)]
	schema = {}
	name = table_name+".txt"
	
	file_2 = open(name,"w")
	for i in inter_schema.split(","):
		schema[i.split(":")[0]] = i.split(":")[1]
	
	file_2.write(schema)
	file_2.close()
	
	loc = os.popen("readlink -f "+name).read()
	
	#Put it onto HDFS
	hdfs_ins_command1 = "hdfs dfs mkdir /BD_FINAL_PROJECT"
	hdfs_ins_command2 = "hdfs dfs mkdir /BD_FINAL_PROJECT/"+database_name
	hdfs_ins_command3 = "hdfs dfs -put "+csv_name " /BD_FINAL_PROJECT/"+database_name
	hdfs_ins_command3 = "hdfs dfs -put "+loc.rstrip()+" "+"/BD_FINAL_PROJECT/"+database_name
	os.system(hdfs_ins_command1)
	os.system(hdfs_ins_command2)
	os.system(hdfs_ins_command3)
	

elif(query_l[0]=="DELETE" or query_l[0]=="delete"):
	to_delete = query_l[1].split('/')
	to_delete_database = to_delete[0]
	to_delete_table = to_delete[1]
	to_delete_table_name = to_delete[1].split(".")[0]	#Remove the 'csv' part
	
	hdfs_del_command1 = "hdfs dfs -rm /BD_FINAL_PROJECT/"+to_delete_database+"/"+to_delete_table_name+".txt"
	hdfs_del_command2 = "hdfs dfs -rm /BD_FINAL_PROJECT/"+to_delete_database+"/"+to_delete_table
	
	os.system(hdfs_del_command1)
	os.system(hdfs_del_command2)
	
elif((query_l[0]=="SELECT" or query_l[0]=="select") and ("WHERE" not in query_l) and (query_l[1][:query_l.index("(")-1] !="MAX" or query_l[1][:query_l.index("(")-1] !="MIN" or query_l[1][:query_l.index("(")-1] !="SUM")):
	
	
	database_name = query_l[3].split("/")[0]
	table_name = query_l[3]/split("/").[1]
	os.system("hdfs dfs -cat /"+database_name+"/"+table_name+" | python3 mapper.py")
	
	
elif((query_l[0]=="SELECT" or query_l[0]=="select") and (query_l[4]=="WHERE") and (query_l[1][:query_l.index("(")-1] !="MAX" or query_l[1][:query_l.index("(")-1] !="MIN" or query_l[1][:query_l.index("(")-1] !="SUM")):
	
	
	database_name = query_l[3].split("/")[0]
	table_name = query_l[3]/split("/").[1]
	os.system("hdfs dfs -cat /"+database_name+"/"+table_name+" | python3 mapper.py")
	
elif((query_l[0]=="SELECT" or query_l[0]=="select") and (query_l[1][:query_l.index("(")-1] =="MAX" or query_l[1][:query_l.index("(")-1] =="MIN" or query_l[1][:query_l.index("(")-1] =="SUM")):
	if(query_l[1]=="MAX"):
		database_name = query_l[3].split("/")[0]
		table_name = query_l[3]/split("/").[1]
		os.system("hdfs dfs -cat /"+database_name+"/"+table_name+" | python3 mapper.py")
	elif(query_l[1]=="MIN"):
		database_name = query_l[3].split("/")[0]
		table_name = query_l[3]/split("/").[1]
		os.system("hdfs dfs -cat /"+database_name+"/"+table_name+" | python3 mapper.py")
	else:
		database_name = query_l[3].split("/")[0]
		table_name = query_l[3]/split("/").[1]
		os.system("hdfs dfs -cat /"+database_name+"/"+table_name+" | python3 mapper.py")
	
	
	
	
	
	
'''
import pickle
import os
import subprocess
#from hdfs import InsecureClient
import csv
import sys
import time
n = input("enter schema \n")
schema = n.split(" ")
counter = 0
d=dict()
for i in schema:
	key=i.split(":")
	key = key[0]
	d[key] = counter
	counter+=1

print(d)



#print(schema)
pickle_out = open("schema","wb")
pickle.dump(d, pickle_out)
os.system("hdfs dfs -mkdir /stream/{}".format(pickle_out))
pickle_out.close()


#subprocess.call(['hdfs','dfs','-cat','/stream/FIFA_modded_small_1.csv','|','python3','mapper.py'])


#f = open('mapper.py','w')

query = input("enter query: ")
args = query.split(" ")
if(args[0]=='SELECT' or args[0]=='select' and (args[4]!='WHERE' or args[4]!='where')):
	col_names = args[1].split(",")



#os.system("hdfs dfs -cat /stream/FIFA_modded_small.csv | python3 mapper.py")
os.system("hdfs dfs -cat /stream/craigslistVehicles.csv  | python3 mapper.py")
#os.system("hdfs dfs -cat /stream/kruthik.txt | python3 mapper.py")
'''
	
	
	
