#!usr/bin/python3

import sys

from_mapper=[i for i in sys.stdin]

print(sum(from_mapper))
