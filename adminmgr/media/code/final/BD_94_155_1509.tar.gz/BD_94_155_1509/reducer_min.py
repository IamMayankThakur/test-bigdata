#!usr/bin/python3

import sys

from_mapper=[i for i in sys.stdin]

print(min(from_mapper))
