import sys 
print("MAPPER STARTED")
infile = sys.stdin 
counter = 0 
output = list()
for i in infile:
	print(i)
	if(counter > 2000):
		break
	counter+=1

fd = tablename.read()
fd = fd.split(',')

yolo=open("query.txt","r")
com=yolo.read()
com=com.split(" ")

if 'SELECT' in com:
	if 'WHERE' in com :
		f = com[indexof('where')+1]
		col_num = fd(index(f))
		print(col_num)
		
		
	else:
		if ">" == com[com.index("WHERE")+2]:
		print("entering > ")
		output.append(i)

