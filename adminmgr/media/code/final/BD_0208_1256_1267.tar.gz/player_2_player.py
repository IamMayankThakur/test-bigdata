import sys
import csv
from collections import defaultdict
dictionary1 = defaultdict(list)
newdictionary = dict()
with open('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/probability_computation/ipl.csv', 'r') as csvFile:
    reader = csv.reader(csvFile)
    for row in reader:
    	dictionary1[row[0],row[1]].append([row[2],row[3]])	#key of dict

csvFile.close()
csvfile = open('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/probability_computation/player_to_player.csv','w')
writer = csv.DictWriter(csvfile, fieldnames = ['batsman', 'bowler', '0','1','2','3','4','6','out','batclustno','bowlclustno','balls'])
writer.writeheader()


for key,values in dictionary1.items():
	#print(key,type(key),key[0],key[1])
	dot, one, two, three, four, six, wick, balls = 0, 0, 0, 0, 0, 0, 0, 0

	for i in values:
		p = i[0]
		
		if (p == '0') == True:
			dot += 1
		elif (p == '1') == True:
			one += 1
		elif (p == '2') == True:
			two += 1
		elif (p == '3') == True:
			three += 1
		elif (p == '4') == True:
			four += 1
		elif (p == '6') == True:
			six += 1
		if (i[1] == '1') == True:
			wick += 1
		balls += 1
	#print(key,dot,one,two,three,four,six,wick,balls)
	#print(key,wick)
	batclustno, bowlclusrno = 0, 0

	with open('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/cluster_files/bat_clusters.csv') as file1:
		read = csv.reader(file1)
		for row in read:
			if (row[0] == key[0]) == True:
				batclustno = row[1]
				break
	with open('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/cluster_files/bowl_clusters.csv') as file2:
		read = csv.reader(file2)
		for row in read:
			if (row[0] == key[1]) == True:
				bowlclustno = row[1]
				break
	#newdictionary[key] = [dot/balls,one/balls,two/balls,three/balls,four/balls,six/balls,wick/balls]
	writer.writerow({'batsman':key[0],'bowler':key[1],'0':dot/balls,'1':one/balls,'2':two/balls,'3':three/balls,'4':four/balls,'6':six/balls,'out':wick/balls,'batclustno':batclustno,'bowlclustno':bowlclustno,'balls':balls})
