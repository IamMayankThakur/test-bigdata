from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans


spark1 = SparkSession.builder.appName('cricket')
spark = spark1.getOrCreate()

def removeB(x):
	a = []
	for i in x:
		if "b'" in i:
			new = i[2:-2]
			a.append(new)
		else:
			a.append(i)
	return a


s1 = spark.read.text('hdfs://localhost:9000/usr/sarvesh/batting.csv').rdd
s2 = s1.map(lambda x:x[0]).map(lambda x : x.split(",")).map(removeB)
bat_fp = s2.map(lambda x: (x[0],x[1:]))

s3 = spark.read.csv('hdfs://localhost:9000/usr/sarvesh/bowling.csv').rdd
s4 = s3.map(lambda x:x[0]).map(lambda x : x.split(",")).map(removeB)

bowl_fp = s4.map(lambda x: (x[0],x[1:]))


# def EuclidianDistance(a,b):
# 	d = 0
# 	l = len(a)
# 	for i in range(l):
# 		dist += ((float(a[i])-float(b[i]))**2)
# 	return d
	
def FindCluster(a,centroid):
	
	idx = 0
	c = float("+inf")
	l = len(centroid)
	for i in range(l):
		# dist = EuclidianDistance(a, centroid[i])

		d = 0
		l = len(a)
		b = centroid[i]
		for i in range(l):
			dist += ((float(a[i])-float(b[i]))**2)

		if c > dist:
			c = dist
			idx = i
	
	return idx

# def random_points(rdd1, k):
# 	samp = rdd1
# 	a = samp.takeSample(False, k, 1)
# 	v = [i[0] for i in a]
# 	return v
	
	

def kmeans(rdd1, k):
	# cen = random_points(rdd1, k)
	samp = rdd1
	a = samp.takeSample(False, k, 1)
	cen = [i[0] for i in a]

	conv = 0.00000000000001
	
	dist = 1.00
	
	while (dist>conv) == True :
		
		temp1 = rdd1.map(lambda x : (FindCluster(x[1],cen), (x[1],1)))
		temp = temp1.reduceByKey(reducer).map(avg).collect()
		dist = sum(find_distance(cen[i],idx) for (i,idx) in temp)
		for i in temp:
			cen[i[0]] = i[1]
			
	return cen
	
