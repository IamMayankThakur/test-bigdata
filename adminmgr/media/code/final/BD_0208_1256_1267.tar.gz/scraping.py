from bs4 import BeautifulSoup as soup
import csv
import pandas as pd


bat_arr = [['Player', 'Mat', 'Inns', 'NO', 'Runs', 'HS', 'Ave', 'BF', 'SR', '100', '50', '0', '4s', '6s']]
bowl_arr = [['Player', 'Mat', 'Inns', 'Overs', 'Mdns', 'Runs', 'Wkts', 'BBI', 'Ave', 'Econ', 'SR', '4', '5', 'Ct', 'St']]

def dup(fn, res, row_arr):
    df = pd.DataFrame(row_arr)
    
    for dup in res:
        if((fn == '/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-1/batting.csv' and len(dup) != 15) or (fn == '/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-1/bowling.csv' and len(dup) != 16)) :
            dup.insert(1, '-')
        #print("g" not in df[0].values.tolist(), df[0].values.tolist()) #print dup[0] not in df[0].values.tolist()
        if(dup[0] not in df[0].values.tolist()):
    	    row_arr.append(dup)
    	    df = pd.DataFrame(row_arr) #print("dts0", str(dup[0]) not in df[0].values.tolist(), dup[0], df[0].values.tolist())
        else:
            print(dup[0])
            for i in row_arr:
                query = (dup[0] == i[0])
                if(query):
                    q1 = (fn == '/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-1/batting.csv')
                    if(q1):
                        for c in [1, 2, 3, 4, 7, 9, 10, 11, 12, 13]:
                            add = int(i[c]) + int(dup[c])
                            i[c] = str(add)
                        ans = float(i[6]) + float(dup[6])
                        i[6] = str( ans / 2)
                        ans = float(i[8]) + float(dup[8])
                        i[8] = str( ans / 2)
                    q2 = (fn == '/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-1/bowling.csv')
                    if(q2):
                        for c in [1, 2, 4, 5, 6, 11, 12, 13, 14]:
                            add = int(i[c]) + int(dup[c])
                            i[c] = str(add)
                        
                        ans = float(i[3]) + float(dup[3])
                        i[3] =str(ans)
                        ans = float(i[8]) + float(dup[8])
                        i[8] = str(ans/ 2)
                        ans = float(i[9]) + float(dup[9])
                        i[9] =str( ans/ 2)
                        ans = float(i[10]) + float(dup[10])
                        i[10] =str( ans/ 2)
                   
                        
                    df = pd.DataFrame(row_arr)


filename = 'batting.csv'
my_off_url = '/home/sarvesh/Desktop/1.html'


#scrapping part

op = open(my_off_url, 'rb').read()
page = soup(op, "html.parser") # Offline

rows=page.find_all('tr') #print(rows)

res=[]
l=[]
for row in rows:
    cols=row.find_all('td')
    cols=[x.text.strip().replace('-', '0').encode('utf8') for x in cols]
    res.append(cols)

for i in res:
    if len(i)<14:
        l.append(i)

for i in l:
    res.remove(i)

dup(filename, res, bowl_arr)

#writter part
with open(filename, 'w') as myFile:
    writer = csv.writer(myFile)

    length = len(filename)
    for i in range(length):
        for r in bowl_arr:
            writer.writerow(r[2:-2])
    myFile.close()



# FOR BOWLING


filename = 'bowling.csv'
my_off_url = '/home/sarvesh/Desktop/2.html'


#scraper part

op = open(my_off_url, 'rb').read()
page = soup(op, "html.parser") # Offline

rows=page.find_all('tr') #print(rows)

res=[]
l=[]
for row in rows:
    cols=row.find_all('td')
    cols=[x.text.strip().replace('-', '0').encode('utf8') for x in cols]
    res.append(cols)

for i in res:
    if len(i)<14:
        l.append(i)

for i in l:
    res.remove(i)

dup(filename, res, bowl_arr)


#writer part
with open(filename, 'w') as myFile:
    writer = csv.writer(myFile)

    length = len(filename)
    for i in range(length):
        for r in bowl_arr:
            writer.writerow(r[2:-2])
    myFile.close()
