import pandas as pd
cpairs = pd.read_csv('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/probability_computation/player_to_player.csv')
del cpairs['batsman']
del cpairs['bowler']

final0 = cpairs.groupby(['batclustno','bowlclustno'])

final = final0.mean()   #Find average of probabilities by grouping by bat cluster no and 

final.to_csv('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/probability_computation/clust_to_clust.csv')
