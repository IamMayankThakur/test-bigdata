import pandas as pd

cpairs = pd.read_csv('/home/sarvesh/Desktop/BigData---IPL-Match-Simulation-master/Step-2/probability_computation/player_to_player.csv')
del cpairs['batsman']
del cpairs['bowler']

diff_arr = [['bowler','replacing_bowler','Econ_diff']]
bowl_fp = pd.read_csv('/home/sarvesh/Desktop/bowling.csv')
differnce = pd.DataFrame(columns=['bowler','replacing_bowler','Econ_diff'])

filename = '/home/sarvesh/Desktop/collaborative_filtering.csv'
#bowling_change = pd.DataFrame(columns=['Econ'])
l = len(bowl_fp)
for i in range(l):
	l1 = len(bowl_fp)
	for j in range():
		if ((bowl_fp.at[i,'0']) == (bowl_fp.at[i,'0']) == True):
			j=j+1
		
		else :
			x= float(bowl_fp[i,'Econ']) - float(bowl_fp[j,'Econ'])
			difference.at[i,'0'] = (bowl_fp.at[i,'0'])                            #Finding cumulative probabilities
			difference.at[i,'1'] = (bowl_fp.at[j,'0'])
			difference.at[i,'2'] = x
			
			
writer(filename, diff_arr)
			
			
def writer(fn, row_arr):
    with open(fn, 'w') as myFile:
        writer = csv.writer(myFile)
        for r in row_arr:
            writer.writerow(r)
        myFile.close()
