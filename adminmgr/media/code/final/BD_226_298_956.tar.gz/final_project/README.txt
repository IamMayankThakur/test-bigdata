SQL Engine Project done by:
Shashank MG	(PES1201700298)
Sparsha (PES1201700226)
Shreyas BS (PES1201700956)


Make sure directories named 'DATABASES' and 'outputs' are on HDFS
	-> hadoop fs -mkdir /DATABASES
	-> hadoop fs -mkdir /outputs

[...] --> optional

Following is the syntax to be followed for queries:

1. For creating database:
		create database <database-name>		(Being inside the directory 'DATABASES')

2. For deleting database:
		drop database <database-name>

3. For using database:
		use database <database-name>		(Being inside the directory 'DATABASES')

4. For creating table:
		create table <path-to-csv-file-on-local-system> as <schema>

		<schema> format:
		(col1:<datatype>,col2:<datatype>,col3:<datatype>,.....)		

		(Supported datatypes are 'int' and 'string')

5. For dropping table:
		drop table <table-name>

6. For SELECT and PROJECT queries:
		select <columns-seperated-by-commas> from <table-name> [where <column> <condition> <value>]

7. For AGGREGATE queries:
		Supported operations:
			a) min(<column>)
			b) max(<column>)
			c) count(*)

		select <supported-operations-seperated-by-commas> from <table-name> [where <column> <condition> <value>]






Sample input file:

test.csv

1,a
2,b
3,c
4,d


Sample query:

create table test.csv as (id:int,name:string)
select * from test


Sample output:
id  name
1	 a
2	 b
3	 c
4	 d

