
import os
import pyarrow as pa
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import re

fs= pa.hdfs.connect('127.0.0.1', 50071)

def create_db(db_name):
    dir_name = os.environ['MY_DATABASE_DIR']
    if(dir_name == '/DATABASES'):
        if(not os.system("hadoop fs -test -d "+dir_name+'/{}'.format(db_name))):
            return -1
        return(os.system('hadoop fs -mkdir /DATABASES/{}'.format(db_name)))

def use_db(db_name):
    dir_name = os.environ['MY_DATABASE_DIR']
    if(os.system("hadoop fs -test -d "+dir_name+'/{}'.format(db_name))):
        return 0
    os.environ['MY_DATABASE_DIR'] = '/DATABASES/{}'.format(db_name)
    return 1


def drop_db(db_name):
    os.environ['MY_DATABASE_DIR'] = '/DATABASES'
    return(os.system('hadoop fs -rm -r /DATABASES/{}'.format(db_name)))

def create_table(table_name,schema,local_path):
    data_name = os.environ['MY_DATABASE_DIR']
    if(not data_name == '/DATABASES'):
        if(not os.system("hadoop fs -test -e "+data_name+'/{}_schema.parquet'.format(table_name))):
            return -1
        
        colnames=[]
        types=[]
        for i in schema:
            colnames.append(i.split(':')[0])
            types.append(i.split(':')[1])
        df = pd.DataFrame({'name':colnames,"data_type":types})
        table = pa.Table.from_pandas(df)

        
        check_sanity = sanity_check(local_path,types)
        if(check_sanity):
            os.system('hadoop fs -put {} {}'.format(local_path,data_name+"/"+table_name+".csv"))
            os.system('hadoop fs -touch '+data_name+'/{}_schema.parquet'.format(table_name))
            pq.write_table(table, "hdfs://"+data_name+'/{}_schema.parquet'.format(table_name))
        else:
            return 2
            
        return 1
    else:
        return 0
    
def drop_table(table_name):
    data_name = os.environ['MY_DATABASE_DIR']
    if(not data_name == '/DATABASES'):
        os.system('hadoop fs -rm {}'.format(data_name+"/"+table_name+".csv"))
        os.system('hadoop fs -rm {}'.format(data_name+"/"+table_name+"_schema.parquet"))
        return 1
    else:
        return 0


def sanity_check(local_path,types):
    fd = open(local_path)
    for i in fd:
        data = i.split(',')
        if(len(data) != len(types)):
            return 0
        for j in range(len(types)):
            if(types[j]=='int'):
                if(not data[j].strip().isnumeric()):
                    return 0
            elif(types[j]!='string'):
                    return 0
    return 1



    
    
