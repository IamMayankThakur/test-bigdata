import os
from utils_db import *
from utils_queries import *
os.environ['MY_DATABASE_DIR'] = '/DATABASES'

while(1):
        a=input(">>>  ")
        if(a.startswith('create database')):
                try:
                        b = a.split(' ')
                        x=create_db(b[2])
                        if(x==0):
                                print("Database %s created successfully"%(b[2]))
                        if(x==-1):
                                print("Database already exists")
                except Exception as e:
                        print(e)
                        print('Create format: create database <database-name>')

        elif(a.startswith('use database')):
                try:
                        b = a.split(' ')
                        x = use_db(b[2])
                        if(x):
                                print("Switched database to %s"%(b[2]))
                        else:
                                print("Database does not exist")
                except Exception as e:
                        print(e)
                        print('Use format: use database <database-name>')
                        
        elif(a.startswith('drop database')):
                try:
                        b = a.split(' ')
                        drop_db(b[2])
                except:
                        print('Drop format: drop database <database-name>')

                        
        elif(a.startswith('create table')):
                try:
                        b= a.split(' ')
                        local_path= b[2]
                        table_name= local_path.split('/')[-1].split('.')[0]
                        schema= b[4].split(',')
                        schema[0]= schema[0].lstrip('(')
                        schema[-1]= schema[-1].rstrip(')')
                        temp = create_table(table_name, schema, local_path)
                        if(temp==0):
                                print('Should be in a database to create table')
                        elif(temp==-1):
                                print('Table already exists')
                        elif(temp==2):
                                print('Data does not match with schema')
                except Exception as e:
                        print('Create table format: create table <table-name> <schema (col1:type,col2:type,...)>')

        elif(a.startswith('drop table')):
                try:
                        b= a.split(' ')
                        if(drop_table(b[2])==0):
                                print('Should be in a database to create table')
                except:
                        print('Drop table format: create table <table-name>')
                        
        elif(a.startswith('select')):
                try:
                        query(a)
                except Exception as e:
                        print(e)
                        print("select <projection> from <table name>")
        elif(a.startswith('quit')):
                exit(0)
        else:
             print("Allowed operations:\nCreate : create database <database-name>\nUse : use database <database-name>\nDrop : drop database <database-name>")
