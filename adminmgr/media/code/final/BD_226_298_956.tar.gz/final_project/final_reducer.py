#!/usr/bin/python3
import sys
import csv
infile = sys.stdin
current_key = ""
test =  0
count = None
min_val = None
max_val = None
project = 0
for line in infile:
    line = line.strip()
    key,val = line.split(";")
    val = eval(val)
    if(val['project']):
        if (current_key != key):
            data = ",".join(val['line'].split('!'))
            print("%s" % (data))
            current_key = key
    else:
        data = val['line'].split('!')
        if(test):
            if(val['count']):
                count += 1
            if(val['min'][0] != -1):
                min_val = min(min_val,data[val['min'][0]])
            if(val['max'][0] != -1):
                max_val = max(max_val,data[val['max'][0]])
        else:
            if(val['count'] != 0):
                count = 1
            if(val['min'][0] != -1):
                min_val = data[val['min'][0]]
            if(val['max'][0] != -1):
                max_val = data[val['max'][0]]
            if(val['project']):
                project = 1
            test=1
 

                
if(not project):
    s = ''
    if(count is not None):
        s=s+str(count)+','
    if(min_val is not None):
        s=s+str(min_val)+','
    if(max_val is not None):
        s=s+str(max_val)
    s=s.rstrip(',')
    print(s)
