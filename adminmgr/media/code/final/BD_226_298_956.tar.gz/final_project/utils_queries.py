import pyarrow.parquet as pq
import os
import random
import sys
import subprocess
import pandas as pd
import uuid

def query_parser(query,l):
        q= query.split(' ')
        d={}
        if(len(q)==8 and 'where' in q):
                cond=q[6]
                value=q[7]
                col=q[5]
                colstr= q[1]
                cols= q[1].split(',')

                for i in l:
                        if(i[0][0]==col):
                                if((("'" in value or '"' in value )and i[0][1]=='string') or (value.isnumeric() and i[0][1]=='int')):
                                        ind= i[1] 
                                        fullcond=cond+value
                                        if(i[0][1]=='string'):
                                                typ= 'str'
                                        else:
                                                typ=i[0][1]
                                else:
                                        pass
                        else:
                                pass
                d['select']=[ind,fullcond,typ]
                if('max' in colstr or 'min' in colstr or 'count' in colstr):
                        d['project']=[]
                        d['max']=[]
                        d['min']=[]
                        d['count']=0
                        
                        if('count' in colstr):
                                d['count']=1
                        for i in cols:
                                if('max' in i):
                                        for j in l:
                                                if(j[0][0]==i.split('(')[-1].split(')')[0]):
                                                        d['max'].append(j[1])
                                if('min' in i):
                                        for j in l:
                                                if(j[0][0]==i.split('(')[-1].split(')')[0]):
                                                        d['min'].append(j[1])
                else:
                        if('*' in cols):
                                cols= [i[1] for i in l]
                        else:
                                for i in l:
                                        if(i[0][0] in cols):
                                                cols[cols.index(i[0][0])]=i[1]
                                        
                        d['project']=cols
                        d['max']=[]
                        d['min']=[]
                        d['count']=0

        elif(len(q)==4 and 'where' not in q):
                cols= q[1].split(',')
                colstr= q[1]

                for i in l:
                        if(i[0][0] in cols):
                                cols[cols.index(i[0][0])]=i[1]

                d['select']=[]
	
                if('max' in colstr or 'min' in colstr or 'count' in colstr):
                        d['project']=[]
                        d['max']=[]
                        d['min']=[]
                        d['count']=0

                        if('count' in colstr):
                                d['count']=1
                        for i in cols:
                                if('max' in i):
                                        for j in l:
                                                if(j[0][0]==i.split('(')[-1].split(')')[0]):
                                                        d['max'].append(j[1])
                                if('min' in i):
                                        for j in l:
                                                if(j[0][0]==i.split('(')[-1].split(')')[0]):
                                                        d['min'].append(j[1])
                else:
                        if('*' in cols):
                                cols=[i[1] for i in l]
                        else:
                                for i in l:
                                        if(i[0][0] in cols):
                                                cols[cols.index(i[0][0])]=i[1]
			
                        d['project']=cols
                        d['max']=[]
                        d['min']=[]
                        d['count']=0
                        
        return d



def query(q):
    dir_name = os.environ['MY_DATABASE_DIR']
    to_proj = q.split('from')[0].split(" ")[1].split(",")
    tab_name = q.split('from')[1].split(" ")[1]
    df = pq.read_table("hdfs://"+dir_name+"/"+tab_name+"_schema.parquet")
    df = df.to_pandas()
    col_data = list(zip(list(df['name']),list(df['data_type'])))
    to_send = []
    where_col = None
    if(len(q.split(' ')) == 8):
            where_col = q.split('where')[1].lstrip().split(" ")[0]

    if where_col not in to_proj and where_col != None:
            to_proj.append(where_col)
    if(to_proj[0] == '*' or 'count' in q or 'min' in q or 'max' in q):
        for i in range(len(col_data)):
            to_send.append([col_data[i],i])
    else:
        for i in to_proj:
            for j in range(len(col_data)):
                if(i == col_data[j][0]):
                    to_send.append([col_data[j],j])


    if(len(to_send) == len(to_proj) or to_proj[0]=='*' or 'count' in q or 'min' in q or 'max' in q):
        d = query_parser(q.lower(),to_send)
        out_dir = uuid.uuid4().hex
        print('Submitting map reduce job ...')
        if(len(d['min'])==0):
                d['min'].append(-1)
        if(len(d['max'])==0):
                d['max'].append(-1)
        os.environ['MY_PARAMS'] = str(d)
        os.system("hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.1.2.jar -mapper 'python3 /home/hadoop/Desktop/final_proj/mr_jobs/final_mapper.py' -reducer 'python3 /home/hadoop/Desktop/final_proj/mr_jobs/final_reducer.py' -input {0} -output /outputs/output{1}".format(str(dir_name)+"/"+str(tab_name)+".csv",str(out_dir)))
        
        output = subprocess.Popen(['hadoop','fs','-cat','/outputs/output{}/part*'.format(out_dir)],stdout=subprocess.PIPE)
        out_list = []
        for line in output.stdout:
                out_list.append(line.decode('utf-8').replace('\t','').replace('\n','').split(','))

        if(len(d['project'])==0):
                a=[]
                for i in out_list:
                        a.extend(i)

                a=[a]
                out_list=a

        col_names = []
        if(len(d['project']) >0):
                for i in d['project']:
                        for j in to_send:
                                if i==j[1]:
                                        col_names.append(j[0][0])
                                        
        if(d['count'] != 0):
                for i in to_proj:
                        if('count' in i):
                                col_names.append(i)
        if(d['min'][0] != -1):
                for i in to_proj:
                        if('min' in i):
                                col_names.append(i)
        if(d['max'][0] != -1):
                for i in to_proj:
                        if('max' in i):
                                col_names.append(i)
        final_output = pd.DataFrame(out_list,columns=col_names)
        if(len(out_list) > 0):
                print(final_output.to_string(index = False))
        os.system("hadoop fs -rm -r /outputs/output{}".format(out_dir))
    else:
        print("Error with query please follow syntax\nselect <columns> from <table name> where <column name> <operator> <value>")
        
    
