#!/usr/bin/python3
import sys
import csv
import os
infile = sys.stdin
d = eval(os.environ["MY_PARAMS"])
for line in infile:
        line = line.strip()
        my_data = line.split(',')
        for i in range(len(my_data)):
                my_data[i] = my_data[i].strip()
        project_data = []
        if(len(d['select']) > 0):
                index,cond,my_type = d["select"]
                if(eval("eval(my_type)(my_data[index])"+cond)):
                        if(len(d['project']) > 0):
                                for i in d["project"]:
                                        project_data.append(my_data[i])
                                my_line = "!".join(project_data)
                                print('(%s);%s' % (my_line,str(eval("{'line':my_line,'project': 1,'min':d['min'],'max':d['max'],'count':d['count']}"))))
                        else:
                                my_line = "!".join(my_data)
                                print('(%s);%s' % (my_line,str(eval("{'line':my_line,'project': 0,'min':d['min'],'max':d['max'],'count':d['count']}"))))
        else:
                if(len(d['project']) > 0):
                        for i in d["project"]:
                                project_data.append(my_data[i])
                        my_line = "!".join(project_data)
                        print('(%s);%s' % (my_line,str(eval("{'line':my_line,'project': 1,'min':d['min'],'max':d['max'],'count':d['count']}"))))
                else:
                        my_line = "!".join(my_data)
                        print('(%s);%s' % (my_line,str(eval("{'line':my_line,'project': 0,'min':d['min'],'max':d['max'],'count':d['count']}"))))

                    
        

        
