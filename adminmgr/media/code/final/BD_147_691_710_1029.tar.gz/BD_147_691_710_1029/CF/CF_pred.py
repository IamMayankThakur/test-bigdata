import pandas as pd
import numpy as np
from sklearn import model_selection
from sklearn.tree import DecisionTreeClassifier
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating

data = sc.textFile("/home/jnanesh/Desktop/project/test.data")
ratings = data.map(lambda l: l.split(','))\
    .map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))
    
print "HELLO WORLD!"
print"COLLABORATIVE FILTERING FOR IPL SCORE PREDICTION BIG DATA PROJECT!"

