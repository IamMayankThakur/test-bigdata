from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from __future__ import print_function
import numpy as np

def parseVector(line):
    return np.array([float(x) for x in line.split(' ')])
    
def kmean(p, centers):
    bestIndex = 0
    closest = float("+inf")
    for i in range(len(centers)):
        tempDist = np.sum((p - centers[i]) ** 2)
        if tempDist < closest:
            closest = tempDist
            bestIndex = i
    return bestIndex


if __name__ == "__main__":

    if len(sys.argv) != 4:
        print("Usage: kmeans <file> <k> <convergeDist>", file=sys.stderr)
        sys.exit(-1)

    spark = SparkSession\
        .builder\
        .appName("PythonKMeans")\
        .getOrCreate()

    lines = spark.read.text(sys.argv[1]).rdd.map(lambda r: r[0])
    data = lines.map(parseVector).cache()
    K = int(sys.argv[2])
    convergeDist = float(sys.argv[3])

    kPoints = data.takeSample(False, K, 1)
    tempDist = 1.0

    while tempDist > convergeDist:
        closest = data.map(
            lambda p: (closestPoint(p, kPoints), (p, 1)))
        pointStats = closest.reduceByKey(
            lambda p1_c1, p2_c2: (p1_c1[0] + p2_c2[0], p1_c1[1] + p2_c2[1]))
        newPoints = pointStats.map(
            lambda st: (st[0], st[1][0] / st[1][1])).collect()

        tempDist = sum(np.sum((kPoints[iK] - p) ** 2) for (iK, p) in newPoints)

        for (iK, p) in newPoints:
            kPoints[iK] = p

    print("Final centers: " + str(kPoints))


spark = SparkSession.builder.appName('cricket').getOrCreate()

bat_fp = spark.read.csv('/project/Input/batsmen2016.csv', header=True, inferSchema=True)
bowl_fp = spark.read.csv('/project/Input/bowler2016.csv', header=True, inferSchema=True)

bat_cols = ['Avg','SR']
bowl_cols = ['Econ', 'SR']

def clustering(fp, cols):
	assembler = VectorAssembler(inputCols=cols, outputCol='features')
	assembled_data = assembler.transform(fp)
	scaler = StandardScaler(inputCol='features', outputCol='scaledFeatures')
	print('dkks' scaler)
	scaler_model = scaler.fit(assembled_data)
	scaled_data = scaler_model.transform(assembled_data)
	k_means_3 = kmean(featuresCol='scaledFeatures', k=10)
	model_k3 = k_means_3.fit(scaled_data)
	model_k3_data = model_k3.transform(scaled_data)
	return model_k3_data

bat_det = clustering(bat_fp, bat_cols)
bowl_det = clustering(bowl_fp, bowl_cols)

print("\nbat\n")
bat_det.show(50)
bat_det.groupBy('prediction').count().show()

print("bowl\n")
bowl_det.show(50)
bowl_det.groupBy('prediction').count().show()
