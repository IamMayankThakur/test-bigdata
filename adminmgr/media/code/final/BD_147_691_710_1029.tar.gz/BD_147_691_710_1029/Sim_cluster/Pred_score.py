import csv
import random

def randscore(a,b):
	r=random.randrange(100)
	if r<15
	return 1
	if r>15 and r<40
	return 2
	if r>40 and r<50
	return 3
	if r>50 and r<65
	return 4
	if r>65 and r<80
	return 6
	if r>80 and r<95
	return 0
	if r>90
	return 'W'

t1_bat_order = []
t1_bow_order = []
t2_bat_order = []
t2_bow_order = []

Dist = [0, 1, 2, 3, 4, 6, 'W']

with open('Input/TestInputMatch.csv', 'rb') as f:
    pmatch = csv.reader(f)
    pmatch.next()
    for row in pmatch:
        t1_bat_order.append(row[0])
        t1_bow_order.append(row[1])
        t2_bat_order.append(row[2])
        t2_bow_order.append(row[3])

t1_bat_order = [x for x in t1_bat_order if x != '']
t1_bow_order = [x for x in t1_bow_order if x != '']
t2_bat_order = [x for x in t2_bat_order if x != '']
t2_bow_order = [x for x in t2_bow_order if x != '']

t1_bow_order = t1_bow_order[:5]
t2_bow_order = t2_bow_order[:5]

def cluster_number(batsman, bowler) :

	with open('Data/BatsmenCluster.csv', 'rb') as f:
	    bat_cluster_reader = csv.reader(f)
	    for row in bat_cluster_reader:
	    	if batsman == row[0]:
	    		curr_bat_cluster_num = row[14]

	with open('Data/BowlersCluster.csv', 'rb') as f:
	    bow_cluster_reader = csv.reader(f)
	    for row in bow_cluster_reader:
	    	if bowler == row[0]:
	    		curr_bow_cluster_num = row[13]

	return curr_bat_cluster_num, curr_bow_cluster_num

def pvp_plist(batsman, bowler) :
	pvp_check = False
	with open('Data/PvP_Probabilities.csv', 'rb') as f:
	    pvp_reader = csv.reader(f)
	    for row in pvp_reader:
	    	if batsman == row[0] and bowler == row[1]:
	    		pvp_check = True
	    		probs_list = row
                break
				
	if pvp_check :		
		probs_list = map(float, probs_list)
		probs_list = probs_list[2:9]
		return pvp_check,probs_list
	else :
		return pvp_check,None
	
def gvg_plist(bat_cluster_number, bowler_cluster_number) :
	
	with open('Data/GvG_Probabilities.csv', 'rb') as f:
	    gvg_reader = csv.reader(f)
	    for row in gvg_reader:
	    	if bat_cluster_number == row[0] and bowler_cluster_number == row[1]:
	    		probs_list = row

	probs_list = map(float, probs_list)
	probs_list = probs_list[2:]
	return probs_list


def innings(bat_order, bow_order, inn) : 
	
	tot_wickets = 0
	b1 = 1    # Index of current batsman (Will be swapped in loop)
	b2 = 0  # Index of standing batsman (Will be swapped in loop)

	# Assuming that only 5 players bowl
	# 20 elements. Each element represents which bowler has to bowl the respective over.
	bow_index_order = [for x in range(0,20) randscore(1,5)]
	x = bow_index_order[0]
	totruns = 0
	k = -1
	for i in range(0,120) :

		# Swap batsmen and Change bowlers for every 6 balls
		if i%6 == 0 :
			k += 1
			x = bow_index_order[k]
			tmp_b = b1
			b1 = b2
			b2 = tmp_b

		curr_bat = bat_order[b1] # Current Batsman
		other_bat = bat_order[b2] # Standing Batsman
		curr_bow = bow_order[x] # Current Bowler
		
		# Prediction
		existent, pvp_p_list = pvp_plist(curr_bat, curr_bow)  
		if existent :
			prediction = randscore(Dist, pvp_p_list)
		else :
			bat_c_num, bow_c_num = cluster_number(curr_bat, curr_bow)
			gvg_p_list = gvg_plist(bat_c_num, bow_c_num)
			prediction = randscore(Dist, gvg_p_list)
		if prediction!='W': 
			totruns+=prediction 
			if prediction==1 or prediction==3:
				tmp_b = b1
				b1 = b2
				b2 = tmp_b
		else:
			tot_wickets+=1
			b1=max(b1,b2) + 1
		if b1 > 10 :
				break
		if inn == 2 and totruns > first_inn_score :
			break
	if inn == 1 :
		first_inn_score = totruns
	num_of_overs_played+= (i+1)%6  
	return totruns, str(totruns)+"/"+str(tot_wickets)+" Overs : "+ num_of_overs_played

# MAIN 
i1score, tscore1 = innings(t1_bat_order, t2_bow_order, 1)
print "Team 1 Score : " + tscore1

i1score, tscore2 = innings(t2_bat_order, t1_bow_order, 2)
print "Team 2 Score : " + tscore2

if i1score>i2score :
	print "Team 1 wins!"
elif i2score>i1score :
	print "Team 2 wins!"
else :
	print "Match Tied."

