#!/usr/bin/python3
import sys
import csv
infile = sys.stdin
infile = sys.stdin
for i in infile:
	a=i.split()
	#print(a)
	dbname=a[1]
	columns=i.split('(')[1].split(')')[0].split(',')
	#print(columns)
	for j in range (len(columns)):
		#print(columns[j])
		b=columns[j].split(':')
		#print(b)
		print("%s,%s,%s,%d"%(dbname.strip(),b[0].strip(),b[1].strip(),j))
