#!/usr/bin/python3

from operator import itemgetter
import sys

inline = sys.stdin 
#!/usr/bin/python3
import sys
import csv
infile = sys.stdin
su=0
count=0
for i in infile:
	i=i.strip().split(',')
	#print(i)

	if(i[1]=='1'):
		if(i[2]=='0'):
			print("%s"%(i[0]))
		else:
			try:
				su+=float(i[0])
				count+=1
				#print(su,count)
			except:
				print("Data is string cant perform aggregate function")
				sys.exit(-1)
if(i[2]=='1'):
				print("%s %s"%("Count:",count))
if(i[2]=='2'):
				print("%s %s"%("Sum:",su))
if(i[2]=='3'):
			print("%s %s"%("Average:",su/count))
			
	
