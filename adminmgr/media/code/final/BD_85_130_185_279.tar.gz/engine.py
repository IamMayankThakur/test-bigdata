import subprocess


def run_cmd(args_list):
        print('Running system command: {0}'.format(' '.join(args_list)))
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        print(s_output.decode('utf-8'),s_err.decode('utf-8'))
        return s_return, s_output, s_err 

while(1):
	com=input()
	i=com.strip()[:-1].split()
	f=open("select","w")
	f.write(com)
	f.close()
	if(i[0]=='LOAD'):
		print(i[0])
		run_cmd(['hadoop','fs','-put','/home/hduser/select','/loadinp/'])
		run_cmd(['hadoop','jar','/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar','-mapper','/home/hduser/mapperload.py','-reducer','/home/hduser/reducerload.py','-input','/loadinp','-output','outputload'])		
		run_cmd(['hadoop','fs','-cat','outputload/*'])
		run_cmd(['hadoop','fs','-rm','-r','outputload'])
		run_cmd(['hadoop','fs','-rm','/loadinp/*'])
	elif(i[0]=="SELECT"):
		run_cmd(['hadoop','jar','/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.2.jar','-mapper','/home/hduser/mapper.py','-reducer','/home/hduser/reducer.py','-input',i[3].strip(),'-output','outputload'])
		run_cmd(['hadoop','fs','-cat','outputload/*'])
		run_cmd(['hadoop','fs','-rm','-r','outputload'])
