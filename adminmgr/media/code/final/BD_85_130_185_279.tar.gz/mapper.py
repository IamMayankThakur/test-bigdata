#!/usr/bin/python3
import sys
import csv

infile = sys.stdin
f=open("select","r")
#print(f.read())
com=f.read()#"SELECT b FROM sample.csv WHERE a = 34 aggregate_by AVERAGE;"
i=com.strip()[:-1]
a=i.split()
#print(a)
projcol=a[1].strip()
dbname=a[3].strip()
whcol=a[5].strip()
whsym=a[6].strip()
whval=a[7].strip()
agg=""
if(len(a)>9):
	agg=a[9].strip()
#print(dbname,projcol,whcol,whsym,whval)
projcol1=[]
whcol1=[]
with open('schema1/schema.csv','r') as sch:
	read=csv.reader(sch)
	for row in read:
		#print(row)
		if (row[1]==projcol):
			projcol1+=row
		if (row[1]==whcol):
			whcol1+=row
	#print(len(whcol1)==0,len(projcol1)==0)
	if(len(whcol1)==0 or len(projcol1)==0):
		print("Database/table/column not found")
		sys.exit(-1)
for i in infile:
	ag=0
	if(agg=="COUNT"):
		ag=1
	elif(agg=="SUM"):
		ag=2
	elif(agg=="AVERAGE"):
		ag=3
	
	if i.strip():
		rd=i.strip().split(",")
		n=0
		if(rd[int(whcol1[3])]==whval):
			n=1
		print("%s,%s,%s"%(rd[int(projcol1[3])],n,ag))


