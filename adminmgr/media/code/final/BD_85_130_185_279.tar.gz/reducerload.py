#!/usr/bin/python3

from operator import itemgetter
import sys

inline = sys.stdin 
#!/usr/bin/python3
import sys
import csv
infile = sys.stdin
for i in infile:
	with open('schema1/schema.csv','a') as c:
		writer = csv.writer(c)
		a=i.split(',')
		a[-1]=a[-1].strip()
		writer.writerow(a)
		print("%s %s"%(i.strip(),"Loaded"))


