##!usr/bin/python3

import sys
d = []
l = []


for i in sys.stdin:
	#print(i)
	d.append(i.strip())

while "" in d:
	d.remove("")

#print(d)
#print(max(d))

maxi = 0
for i in d:
	try:
		if(float(i) > maxi):
			maxi = float(i)
	except:
		print("Not the right datatype")

print(maxi)
