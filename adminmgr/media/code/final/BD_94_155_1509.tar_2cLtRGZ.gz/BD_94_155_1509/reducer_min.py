##!usr/bin/python3

import sys
d = []
l = []


for i in sys.stdin:
	#print(i)
	d.append(i.strip())

while "" in d:
	d.remove("")

#print(d)
mini = 999999999
#print(min(d))
for i in d:
	try:
		if(mini > float(i)):
			mini = float(i)
	except:
		print("not the right datatype")
print(mini)
