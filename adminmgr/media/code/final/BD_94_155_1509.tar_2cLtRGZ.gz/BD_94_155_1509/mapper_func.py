import os 
import sys

def no_where(query,rows,schema):
    to_reducer = []
    if(query[1]=="*"):
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            for col in row:
                if(count<len(row)-1):
                    app = app + str(col)+","
                    count += 1
                else:
                    app = app + str(col)
            to_reducer.append(app)
    else:
        query_cols = query[1].split(',')
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            for col in query_cols:
                if(count<len(query_cols)-1):
                    app = app + str(row[schema.index(col)])+","
                    count += 1
                else:
                    app = app + str(row[schema.index(col)])
            to_reducer.append(app)
    return to_reducer

def equal_to(query,rows,schema):
    to_reducer = []
    where_col = query[5]
    where_val = query[7]

    if(query[1]=="*"):
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) == float(where_val)):
                for col in row:
                    if(count<len(row)-1):
                        app = app + str(col)+","
                        count += 1
                    else:
                        app = app + str(col)
                to_reducer.append(app)
    else:
        query_cols = query[1].split(',')
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) == float(where_val)):
                for col in query_cols:
                    if(count<len(query_cols)-1):
                        app = app + str(row[schema.index(col)])+","
                        count += 1
                    else:
                        app = app + str(row[schema.index(col)])
                to_reducer.append(app)
    return to_reducer

def greater_than(query,rows,schema):
    to_reducer = []
    where_col = query[5]
    where_val = query[7]

    if(query[1]=="*"):
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) > float(where_val)):
                for col in row:
                    if(count<len(row)-1):
                        app = app + str(col)+","
                        count += 1
                    else:
                        app = app + str(col)
                to_reducer.append(app)
    else:
        query_cols = query[1].split(',')
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) > float(where_val)):
                for col in query_cols:
                    if(count<len(query_cols)-1):
                        app = app + str(row[schema.index(col)])+","
                        count += 1
                    else:
                        app = app + str(row[schema.index(col)])
                to_reducer.append(app)
    return to_reducer

def lesser_than(query,rows,schema):
    to_reducer = []
    where_col = query[5]
    where_val = query[7]

    if(query[1]=="*"):
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) < float(where_val)):
                for col in row:
                    if(count<len(row)-1):
                        app = app + str(col)+","
                        count += 1
                    else:
                        app = app + str(col)
                to_reducer.append(app)
    else:
        query_cols = query[1].split(',')
        for row in rows:
            row = row.split('.')
            app = ""
            count=0
            if(float(row[schema.index(where_col)]) < float(where_val)):
                for col in query_cols:
                    if(count<len(query_cols)-1):
                        app = app + str(row[schema.index(col)])+","
                        count += 1
                    else:
                        app = app + str(row[schema.index(col)])
                to_reducer.append(app)
    return to_reducer


def send(to_reducer):
    for each_mapper_output in to_reducer:
        print(each_mapper_output)

def parseQuery(query):
    if(query[0]=="EXIT"):
        print("Exiting the program!")
        sys.exit()
    
    elif(query[0]=="SELECT" or query[0]=="select"):
        #Variable Declarations
        rows = []
        i=0
        ignore_row=0
        aggregate_functions = ["MIN","MAX","SUM"]
        to_reducer = []

        table_name_with_csv = query[3].split('/')[1]
        table_name = table_name_with_csv.split('.')[0]

        schema_file = open("/usr/local/hadoop/"+table_name+".txt")
        schema = schema_file.read()
        schema_file.close()
        schema = schema.split(',')

        for row in sys.stdin:
            #If the first row is column headers, ignore!
            if(i==0):
                row1 = row.split(",")  # It is a CSV file
                for j in range(len(row1)):
                    if(type(row1[j])!=type(schema[j])):
                        ignore_row=1
                i+=1
            rows.append(row)
        
        if(query[1][0:3] not in aggregate_functions):
            #Check if WHERE is present
            #Assumed that the query is entered properly with space after WHERE clause i.e:
            #Eg: ...  WHERE age > 10 
            if "WHERE" in query:
                if(query[6] == "="):
                    to_reducer = equal_to(query,rows,schema)
                
                elif(query[6] == ">"):
                    to_reducer = greater_than(query,rows,schema)

                elif(query[6] == "<"):
                    to_reducer = lesser_than(query,rows,schema)

                else:
                    print("Invalid operation!")
                    sys.exit()
            
            else:
                to_reducer = no_where(query,rows,schema)

        else:
            # Replace MAX(avg) with just avg in query and send to appropriate reducer
            aggregate_column = query[1].split('(')[1]   #Column to perform aggregation on
            aggregate_column = aggregate_column[:(len(aggregate_column)-1)]
            query[1] = aggregate_column #Reducer will take care of checking condition
            
            if "WHERE" in query:
                if(query[6] == "="):
                    to_reducer = equal_to(query,rows,schema)
                
                elif(query[6] == ">"):
                    to_reducer = greater_than(query,rows,schema)

                elif(query[6] == "<"):
                    to_reducer = lesser_than(query,rows,schema)

                else:
                    print("Invalid operation!")
                    sys.exit()
            else:
                to_reducer = no_where(query,rows,schema)
        
        send(to_reducer)
    
    else:
        print("Invalid operation!")
        sys.exit()



query_file = open("/usr/local/hadoop/query.txt","r")
query = query_file.read()
query = query.split()
query_file.close()

parseQuery(query)
