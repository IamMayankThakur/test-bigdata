#!usr/bin/python3

import sys


data=[i for i in sys.stdin]
for i in data:
	print(i)	
