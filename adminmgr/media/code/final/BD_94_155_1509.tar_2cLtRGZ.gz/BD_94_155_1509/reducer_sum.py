#!usr/bin/python3

import sys
d = []
l = []


for i in sys.stdin:
	#print(i)
	d.append(i.strip())

while "" in d:
	d.remove("")

#print(d)
#print(sum(d))
s=0.0
for i in d:
	try:
		s=s+float(i)


	except:
		print("wrong datatype to execute sum on ")
print(s)
