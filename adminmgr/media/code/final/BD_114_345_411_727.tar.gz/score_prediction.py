#!/usr/bin/python3

import sys
import random
import subprocess

#file contains the order of batsman_1
fd_ba_1 = open("batsman_1_order.txt", "r")
lines_bat_1 = fd_bat_1.read()
batsman_1= lines_bat_1.split("\n")
#batsman_1 contains list of batsman_1 in order

#batsman_1=['dhoni','Vk','rohit','raina']

#file contains the order of bowler_1
fd_bowl_1 = open("bowler_1_order.txt", "r")
lines_bowl_1 = fd_bowl_1.read()
bowler_1 = lines_bowl_1.split("\n")

#bowler_1=['jadej','shami','rasheed']

#bowler_1 contains list of bowler_1s in order

#file contains the order of batsman_1
fd_ba_2 = open("batsman_2_order.txt", "r")
lines_bat_2 = fd_bat_2.read()
batsman_2= lines_bat_2.split("\n")
#batsman_2 contains list of batsman_2 in order

#file contains the order of bowler_2
fd_bowl_2 = open("bowler_2_order.txt", "r")
lines_bowl_2 = fd_bowl_2.read()
bowler_2= lines_bowl_1.split("\n")
#bowler_2 contains list of bowler_1s in order

#print(batsman_1)
#print(bowler_1)

#bat1 = batsman_1[0]
#bowl1 = bowler_1[0]

def swap(a, b):
	return b,a

#operations on HDFS
def run_cmd(args_list):
         # import subprocess
        print('Running system command: {0}'.format(' '.join(args_list)))
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        return s_output.decode('utf-8')

#centroid, list of batsman_1
cluster_batsman_1 = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bat.csv').split("\n")

#centroid, list of bowler_1
cluster_bowler_1 = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bowl.csv').split("\n")

#batsman_1^bowler_1, [probabilities of runs 0,1,2,3,4,5,6,out,ball], [cumulative probabilities]
player_player = run_cmd('hdfs', 'dfs', '-cat', '/clusters/player_prob.csv').split("\n")

#cluster1^cluster2, [probabilities of runs 0,1,2,3,4,5,6,out,ball], [cumulative_probabilities]
cluster_cluster = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_prob.csv').split("\n")

#gets the probability
def compute_probability(bat, bowl, ran):
    key = bat + '^' + bowl
    #check in the player_player_prob
    #return random.randint(0,8)
    for data in player_player:
        if (key in data):
            ls = data.split(",")[3]
            for i in ls[:-2]:
                if (i >= ran):
                    return ls.index(i)
    #check in the cluster_cluster_prob

    for data_cluster in cluster_cluster:
        if (key in data_cluster):
            ls = data.split(",")[3]
            for j in ls[:-2]:
                if (j >= ran):
                    return ls.index(j)

overs=0
runs=0
wickets=0
balls=0
b1=0
b2=1
s=batsman_1[b1]
ns=batsman_1[b2]
bw=0
bname=bowler_1[bw]


while(overs < 20 and wickets < 10):
	ran_num=random.uniform(0,1)

	curr_run=compute_probability(s,bname,ran_num)
	print("run this ball",curr_run)
	if(curr_run==7):
		temp = batsman_1.index(s)
		if(temp != b1):
			b2 = max(b1, b2) + 1	
		else:
			b1 = max(b1, b2) + 1
		wickets=wickets+1
	else:
		runs=runs+curr_run
	if (balls == 5 and curr_run % 2 == 1):
		s,ns=swap(s,ns)
	elif(curr_run%2 ==1 ):
		s,ns=swap(s,ns)
	
	balls=balls+1	
	if(balls==6):
		overs=overs+1
		balls=0
		bw=bw+1
		if(bw > 19):
		 	break
		bname=bowler_1[bw]
	
first_innings_run=runs
first_innings_wickets=wickets

#print("runs ",runs)
#print("wickets",wickets)
overs=0
runs=0
wickets=0
balls=0
b1=0
b2=1
s=batsman_2[b1]
ns=batsman_2[b2]
bw=0
bname=bowler_2[bw]

while(overs <20 and wickets<10):
	ran_num=random.uniform(0,1)

	curr_run=compute_probability(s,bname,ran_num)
	
	if(curr_run==7):
		temp = batsman_2.index(s)
		if (temp != b1):
			b2 = max(b1, b2) + 1	
		else:
			b1 = max(b1, b2) + 1
		
		wickets=wickets+1
	else:
		runs=runs+curr_run

	if (balls == 5 and curr_run % 2 == 1):
		s,ns=swap(s,ns)
	elif(curr_run%2 ==1 ):
		s,ns=swap(s,ns)

	balls=balls+1
	
	if(balls==6):
		overs=overs+1
		balls=0
		bw=bw+1
		if(bw>19):
			break			
		bname=bowler_2[bw]


second_innings_runs = runs
second_innings_wickets = wickets

# one team can have one order of batting and another team can have another order
# so i think we need to have 4 different files


