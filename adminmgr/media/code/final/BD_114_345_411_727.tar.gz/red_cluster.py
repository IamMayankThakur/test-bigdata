#!/usr/bin/python3

import sys

key = ''
ls = []
def add_list(a,b):
	new=[]
	for i in range(len(a)):
		new.append(a[i]+b[i])
	return new

for record in sys.stdin:
	key_new, val = record.split(":")

	val = [int(k) for k in val.split(" ")]
	
	if(key_new != key):
		ls.append([key_new,val])
		key = key_new
	else:
		ls[len(ls)-1][1] = add_list(ls[len(ls)-1][1], val)

def div(a):
	last=a[len(a)-1]
	#print("last", last)
	for i in range(len(a)):
		if(a[i]==0):
			a[i]=0
		else:
			a[i]=a[i]/last
	return a	


def cumulative(a):
	#print(a)
	for i in range(1, len(a)):
		a[i]=a[i]+a[i-1]
		#print("ss",a[i])
	return a
'''

ls=[ ['nishi,durga',[0,1,2,3,6]],
	['srisha',[1,1,1,2,5]]
]

'''


#print("before",ls)
#print(ls)
for x in ls:
	#print(len(x))
	x[1]=div(x[1])
	#print(x[1])
	b = list()
	for i in x[1]:
		b.append(i)

	#x[1].append(cumulative(a))
	#print("sllklklk",cumulative(a))
	ret = cumulative(b)
	x.append(ret)
	#print("x",x)
	#print(len(x))


#print("after",ls)
import pandas as pd
df=pd.DataFrame(ls)
#print("df",df)
df.to_csv("cluster_prob.csv")
print(df)




