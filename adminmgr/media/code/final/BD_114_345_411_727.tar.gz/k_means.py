'''
from __future__ import print_function

import re
import sys
from operator import add
from pyspark.sql import SparkSession
import math

centroids_list = []

def dist(p1, p2):
    dist = 0;
    for i in range(len(p1)):
        dist+= (p1[i]-p2[i])**2

    dist = (dist)**(1/2)

    return dist

def cluser_belongs_to(players_list):

    min = math.inf
    min_cluster = -1

    for i in players_list:
        for j in centroids_list:
            if(dist(i, j) < min):
                min = dist(i, j)
                min_cluster = j
        yeild (min_cluster, i)
        min = math.inf
        min_cluster = -1

def k_means(max_iterations):
    for i in max_iterations:
        cluser_belongs_to(players_list, centroids_list).reduceByKey(lambda a, b: [a[i] + b[i] for i in range(len(a))])

spark = SparkSession\
        .builder\
        .appName("PythonPageRank")\
        .getOrCreate()

players = spark.read.option("header", "true").option("delimiter", '\n').csv(sys.argv[1]).rdd.map(lambda r:r[0])

centroids = spark.read.text(sys.argv[2]).rdd.map(lambda r:r[0])

print(players.collect())

#doing further preprocessing
players = players.map(lambda x: [int(i) for i in x.split(',')]).filter(lambda x:[x[0], x[1], x[2]])
centroids = centroids.map(lambda x: [int(i) for i in x.split(',')])

print(players.collect())
print(centroids.collect())

spark.stop()
'''

import sys
from pyspark.sql import SparkSession
import math

spark = SparkSession\
        .builder\
        .appName("k_means")\
        .getOrCreate()

def dist(p1, p2):
    dist = 0;
    for i in range(len(p1)):
        dist+= (p1[i]-p2[i])**2

    dist = (dist)**(1/2)

    return dist


def cluster_belongs_to(player, centroids):

    min = math.inf
    min_cluster = -1

    for i in centroids_list:
        if(dist(player[1:], i) < min):
            min = dist(player[1:], j)
            min_cluster = j

    return (min_cluster, player[1:])

'''
def k_means(max_iterations):
    for i in max_iterations:
        cluser_belongs_to(players_list, centroids_list).reduceByKey(lambda a, b: [a[i] + b[i] for i in range(len(a))])
'''

#assuming we have the player and the centroid rdds
players = spark.read.text(sys.argv[1]).rdd.map(lambda r: r[0])
centroids = spark.read.text(sys.argv[2]).rdd.map(lambda r: r[0])

players.map(lambda x: [int(x) for x in x.split(',')[1:]])
centroids.map(lambda x: [int(x) for x in x.split(',')[1:]])


max_iterations = 3

centroids.cache()

for i in range(max_iterations):
    a = players.map(lambda x: cluster_belongs_to(x, list(centroids.collect())))
    print(a.collect())


    centroids.unpersist()


    centroids.cache()

print(centroids.collect())
