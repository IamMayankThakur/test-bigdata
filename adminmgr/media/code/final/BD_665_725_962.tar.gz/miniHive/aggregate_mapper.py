import sys
import re


if __name__ == "__main__":
	
	f = open('log.txt','r')
	lines = f.read().splitlines()
	query = lines[-1].strip()
	f.close()

	query = query.split(" ")
	table = query[0].split(".")[0]
	f = open(table,'r')
	schema = f.read()
	f.close()
	
	columns = []
	if(query[1] == "max" or query[1] == 'min' or query[1] == "count"):
		if(query[1] == "max"):
			column = query[2]
			schema1 = schema.split(',')
			for i in schema1:
				column1 = i.split(':')[0]
				columns.append(column1)
			#no column in schema
			if column not in columns:
					print('Invalid column')
			
			else:
				index = columns.index(column)
			for line in sys.stdin:
				l = line.split(',')
				print(l[index].strip())
		elif(query[1] == "min"):
			column = query[2]
			schema1 = schema.split(',')
			for i in schema1:
				column1 = i.split(':')[0]
				columns.append(column1)
			#no column in schema
			if column not in columns:
				print('Invalid column')
			
			else:
				index = columns.index(column)
			for line in sys.stdin:
				l = line.split(',')
				print(l[index].strip())
		else:
			column = query[2]

			schema1 = schema.split(',')
			for i in schema1:
				column1 = i.split(':')[0]
				columns.append(column1)
				#no column in schema
			if(column != '*'):
				if column not in columns:
					print('Invalid column')
			
				else:
					index = columns.index(column)
				for line in sys.stdin:
					l = line.split(',')
					print((l[index],1))
			else:
				for line in sys.stdin:
					l = line.split(',')
					print((1,1))

	else:
		print("THESE AGGRIGATION FUNCTIONS DOES NOT SUPPORT :-)")

					
