#!/usr/bin/env python3

import sys
import re


if __name__ == "__main__":
	
	f = open('log.txt','r')
	lines = f.read().splitlines()
	query = lines[-1].strip()
	f.close()

	query = query.split(" ")
	
	#no where clause
	if(len(query) == 2):	
		table = query[0].split(".")[0]
		colums= query[1]

		if(re.findall('\A\*',colums)):
			 for line in sys.stdin:
			 	line = line.strip()
			 	print(line)
		else:
			colums = colums.split(',')
			
			f = open(table,'r')
			schema = f.read()
			f.close()
			
			schema = schema.split(',')
			
			#more no of columns than in schema
			if len(schema) < len(colums):
				print('Invalid columns')
				
			else:
				index = []
				
				for i in range(len(colums)):
					for j in range(len(schema)):
						if colums[i] == schema[j].split(':')[0]:
							index.append(j)
							
				if len(index) != len(colums):
					print('Invalid columns')
					
				else:
					
					 for line in sys.stdin:
					 	line = line.strip().split(',')
					 	for i in index:
					 		print(line[i],end=",")
					 	print()
				
	#has a where condition
	if(len(query) == 5):
	
		where_column = query[2]
		operator = query[3]
		val = query[4]
		
		table = query[0].split(".")[0]
		colums= query[1]


		f = open(table,'r')
		schema = f.read()
		f.close()
		schema = schema.split(',')
		
		#find the corresponding index of the where_colum in schema
		index = 0
		col_index = -1
		for col in schema:
			if(where_column == col.split(':')[0]):
				col_index = index
				break
			index += 1
			
		if(col_index == -1):
			print("column could not be found")
		if(re.findall('\A\*',colums)):
			 for line in sys.stdin:
			 	line = line.strip().split(',')
			 	if(str.isdigit(val)):
			 		string = line[col_index]+' '+operator+' '+val
			 		if(eval(string)):
			 			print(line)
			 	else:
			 		if(line[col_index] == val):
			 			print(line)
			 	
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
