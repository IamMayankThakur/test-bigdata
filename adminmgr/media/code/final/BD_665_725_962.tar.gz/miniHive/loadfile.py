
import sys
import re
import subprocess

dictonary = {}

def load_data(file_name):
	f = open(file_name,"r")
	
	flag = 1
	for line in f:
		line = line.split(",")
		
		#raise exception when length don't match
		if len(line) != len(dictonary[file_name].split(',')):
			flag = 0
			break
	
	if flag:
		
		#first create /database/tables/ directory in terminal ..		
		string = 'hadoop fs -put '+ file +' /database/tables/'
		p1 = subprocess.run(string,shell=True,stdout=subprocess.PIPE)
		
		if p1.returncode:
			print(p1.stdout.decode())
		
		
		schema_file = file_name.split('.')[0]
		f = open(schema_file,'w+')
		string = str(dictonary[file_name])
		f.write(string)
		f.close()
		
	else:
		print("table entries don't match with schema")
	
	

while True:
	req = input(">>")
	
	req = req.strip()
	
	x = re.findall("\Aload",req)

	if(x):
	
		file = re.findall("[\w]+.csv",req)	
		schema = re.findall("as(.+)",req)
		
		#remove the brackets.
		schema = schema[0][1:len(schema[0])-1]
		
		file = file[0];
		
		dictonary[file] = schema
		load_data(file)
			
	elif(re.findall("\Aexit",req)):
		break
	
	
	
	elif(re.findall("min",req) or re.findall("max",req) or re.findall("count",req)):
		req = req.split(' ')
		req_len = len(req)
		
		#select count(col) from table order by desc
		if(req_len == 7):
			s = req[1]
			col = s[s.find("(")+1:s.find(")")]
			 
			#table.csv count col order desc
			string = req[3]+' '+'count'+' '+col+' '+req[4]+' '+req[6]+'\n'
			f = open('log.txt','a+')
			f.write(string)
			f.close()
			
		#select max(col) from table	
		else:
		
			s = req[1]
			op = s[0:s.find("(")]
			col = s[s.find("(")+1:s.find(")")]
			
			#table.csv max col
			string = req[3]+' '+op+' '+col+'\n'
			f = open('log.txt','a+')
			f.write(string)
			f.close()
		
			p1 = subprocess.run('''hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -file aggregate_mapper.py -mapper aggregate_mapper.py -file agregation.py -reducer agregation.py -input /database/tables -output /database/output''',shell=True,stdout=subprocess.PIPE)
			if p1.returncode:
				print(p1.stdout.decode())	
			else:
				p2 = subprocess.run('hdfs dfs -cat /database/output/part-00000',shell=True,stdout=subprocess.PIPE)
				print(p2.stdout.decode())
				p3 = subprocess.run('hdfs dfs -rm -r /database/output',shell=True,stdout=subprocess.PIPE)
				if p3.returncode:
					print(p3.stdout.decode())			
		
		
	# a plain select query
	elif(re.findall("\Aselect",req)):

		# select colum_1,colum_2 from table.csv where colum_4 <= 100
		req = req.split(' ')
		req_len = len(req)
		
		#a valid command
		if(req_len >= 4):
			#has a where clause
			if(req_len > 6):
				
				
				#table_name colums_to_project where_colum operator compared_with(value of column)
				string = req[3]+' '+req[1]+' '+req[5]+' '+req[6]+' '+req[7]+'\n'
				f = open('log.txt','a+')
				f.write(string)
				f.close()
				
			#no where clause
			else:
				#table_name colum_name(s)
				string = req[3]+' '+req[1]+'\n'
				
				#commiting query to a log file
				f = open('log.txt','a+')
				f.write(string)
				f.close()
			
			
			p1 = subprocess.run('''hadoop jar /usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -file project.py -mapper project.py -file project_rd.py -reducer project_rd.py -input /database/tables -output /database/output''',shell=True,stdout=subprocess.PIPE)
			if p1.returncode:
				print(p1.stdout.decode())	
			else:
				p2 = subprocess.run('hdfs dfs -cat /database/output/part-00000',shell=True,stdout=subprocess.PIPE)
				print(p2.stdout.decode())
				p3 = subprocess.run('hdfs dfs -rm -r /database/output',shell=True,stdout=subprocess.PIPE)
				if p3.returncode:
					print(p3.stdout.decode())			
		
	elif(re.findall("\Adelete",req)):
		req = req.split(' ')
		string = 'hdfs dfs -rm /database/tables/'+req[1]
		p1 = subprocess.run(string,shell=True,stdout=subprocess.PIPE)
			
		if p1.returncode:
			print(p1.stdout.decode())
		string2 = 'rm '+req[1].split('.')[0]
		p2 = subprocess.run(string2,shell=True,stdout=subprocess.PIPE)
		if p1.returncode:
			print(p1.stdout.decode())
	else:
		print("invalid command")
			
		
		
		
	
		
		
