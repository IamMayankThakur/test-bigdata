import sys
#print(sys.stdin)
values=[]

for row in sys.stdin:
	values.append(row.split('\n')[0])

f = open('log.txt','r')
lines = f.read().splitlines()
query = lines[-1].strip()
f.close()

query = query.split(" ")

f = open('test','r')
schema = f.read()
f.close()
operation= query[1]

if(operation=="max"):
	arr=0
	for l in values:
		try:
			grt=int(l)
		except:
			print("COLUMN TYPE IS INVALID")
			break
		if(grt>arr):
			arr=grt
		#if(arr<int(line)):
		#	arr=line
	if(arr > 0):
		maximum=arr
		print("MAXIMUM >>"+str(maximum))
elif(operation=="min"):
	arr=999999
	for l in values:
		#print(line)
		try:
			sml=int(l)
		except:
			print("COLUMN TYPE IS INVALID")
			break
		if(sml<arr):
			arr=sml
	if(arr < 999999):
		minimum=arr
		print("MIN VALUE >>"+str(minimum))


elif(operation=="count"):
	value=dict()
	count = 0
	for l in values:
		l = l.split(',')
		key = l[0]
		count += 1
		"""
		if key in value:
			value[key] += 1
		else:
			value[key] = 1"""
	#select count (col)	from table order by desc 
	#in qurey table
	#table.csv count col order desc
	if(len(query) >= 5):
		if(operation=="count" and query[3]=="order" and query[4] == "desc"):
			for i in sorted(value.items() , key = lambda x : (-x[1],x[0])):
				#print("%s,%d" % (i[0],i[1]))
				#print(i)
				print(i[0],i[1])
		elif(operation=="count" and query[3]=="order" and query[4] == "asc"):
			for i in sorted(value.items() , key = lambda x : (x[1],x[0])):
				print(i[0],i[1])
	#select count (col) from table
	#table.csv count col
	elif(len(query) >= 3):
		#print(value)
		#for i,v in value.items():
		#	print(i,v) 
		print("count >> ",count)


