import sys
inline = sys.stdin
for line in inline:
	line = line.strip()
	print(line)