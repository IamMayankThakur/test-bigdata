from __future__ import print_function

import re
import sys
from operator import add

from pyspark.sql import SparkSession

import math
import gc
from pyspark.sql import *
import numpy as np



def getValueByKey(rddx, key):
    try:
        d = dict(rddx.collect())
        if(key in d.keys()):
            return d[key]
        else:
            raise("Key Error")
    except:
        raise("rdd should be in <key, value> format")







def random_centroid(k,x):
    a =  x.takeSample(False, k, 1)
    v = []
    for i in a:
        v.append(i[1])
    return v
    
def split_to_array(ko1):
    return np.array([float(ko) for ko in ko1.split(' ')])

def find_distance(x,c):
    dist=0
    for i in range(len(x)):
        dist=dist+math.pow((float(x[i])-float(c[i])),2)
    return dist

def nearest_cluster(x,c):
    bi = 0
    clo = float("+inf")
    for i in range(len(c)):
        #tempDist = np.sum((p - centers[i]) ** 2)
        dio=find_distance(x,c[i])
        if dio < clo:
            clo = dio
            bi = i
    return bi

def selectScoreWicket(x):
    if len(str(x[18]))>1 :
        return x[8],x[6],x[15],1
    else:
        return x[8],x[6],x[15],0






def divide(x):
    a = [0 if i!=int(x[2]) else 1 for i in range(7)]
    return (x[0],x[1],a,x[3])



def findbatsum(x_y):
    x = x_y[1]
    a = []
    w = 0
    for i in range(len(x)):
        w = w + x[i][1]
    for i in range(len(x[0][0])):
        sums = 0
        for j in range(len(x)):
            sums = sums + x[j][0][i]
        a.append(sums)
    return (x_y[0],(a,w))




def findbatprob(kv):
    k = kv[0]
    v = list(kv[1][0])
    s = sum(v)
    sr = float((s - v[0]))/float(s)
    v = [float(i)/float(s) for i in v]
    w = float(kv[1][1])/max(float(s),float(20))
    if w == 0:
        w = 0.034
    v.append(sr)
    v.append(w)
    return k,v




def findbatcprob(kv):
    k = kv[0]
    v = kv[1]
    sr = kv[2]
    for i in range(1,len(v)):
        v[i] = v[i] + v[i-1]

    return k,v,sr



def findbatprob2(kv):
    k = kv[0]
    v = kv[1][0]
    s = sum(v)
    v = [float(i)/float(s) for i in v]
    w = float(kv[1][1])/max(float(s),float(20))
    if w == 0:
        w = 0.034
    return k,(v,w)




def findbatcprob2(kv):
    k = kv[0]
    v = list(kv[1][0])
    for i in range(1,len(v)):
        v[i] = v[i] + v[i-1]

    return k,(kv[1][0],v,kv[1][1])





def summer(x,y):
    v = []
    for i in range(len(x[0])):
        v.append(x[0][i]+y[0][i])
    return v,x[1]+y[1]



def averageFinder(x):
    v = list(x[1][0])
    v = [i/x[1][1] for i in v]
    return x[0],v




def findProbCprobW(x, y):
    a = list(x[0:7])
    b = list(y[0:7])
    w1 = x[-1]
    w2 = y[-1]
    w = 2*w1*w2/(w1+w2)
    v = []
    for i in range(7):
        try:
            v.append(max((a[i]*b[i]*2/(a[i]+b[i])), 0.01))
        except:
            v.append(0.01)
    s = sum(v)
    v = [i/s for i in v]
    cv = list(v)
    for i in range(1,7):
        cv[i] = cv[i] + cv[i-1]
    return (v,cv,w)





spark = SparkSession\
    .builder\
    .appName("PythonPageRank")\
    .getOrCreate()


#train till 2016
lines = spark.read.text("/projects/deliveries.csv").rdd.map(lambda x:x[0]).map(lambda x : x.split(',')).filter(lambda x: len(x)>=21).filter(lambda x : len(x[0])>=3)


#train till 2019
#lines = spark.read.text("/projects/deliveries.csv").rdd.map(lambda x:x[0]).map(lambda x : x.split(',')).filter(lambda x: len(x)>=21)


scores = lines.filter(lambda x : int(x[16])==0).filter(lambda x : int(x[15])<7).map(selectScoreWicket)
scores = scores.map(divide)
'''
wicket = lines.filter(lambda x: len(str(x[18]))>1).map(lambda x : ((x[8], x[18]), 1)).groupByKey().mapValues(sum)


probofbowl = scores.map(lambda x : (x[0],x[2])).groupByKey().mapValues(list).map(findbatsum).map(findbatprob)
probofbat = scores.map(lambda x : (x[1],x[2])).groupByKey().mapValues(list).map(findbatsum).map(findbatprob)
rdd_to_be_passed_to_cf = probofbat.map(lambda x : (x[0], [x[1],x[2]]))
cprobofbat = probofbat.map(findbatcprob)
'''
probofbat = scores.map(lambda x : (x[1],(x[2],x[3]))).groupByKey().mapValues(list).map(findbatsum).map(findbatprob)
probofbowl = scores.map(lambda x : (x[0],(x[2],x[3]))).groupByKey().mapValues(list).map(findbatsum).map(findbatprob)

probofbalbat = scores.map(lambda x : ((x[0],x[1]),(x[2], x[3]))).groupByKey().mapValues(list).map(findbatsum).map(findbatprob2)
cprobofbalbat = probofbalbat.map(findbatcprob2)


baltobatcprob = cprobofbalbat.map(lambda x : (x[0][0], [x[0][1], x[1]])).groupByKey().mapValues(dict)

battobalcprob = cprobofbalbat.map(lambda x : (x[0][1], [x[0][0], x[1]])).groupByKey().mapValues(dict)
baltobatprob = probofbalbat.map(lambda x : (x[0][0], [x[0][1], x[1]])).groupByKey().mapValues(dict)

battobalprob = probofbalbat.map(lambda x : (x[0][1], [x[0][0], x[1]])).groupByKey().mapValues(dict)




# print(probofbat.collect()[0])

# print("\n\n\n\n")

k=50
cd=0.00000001

cenbat=random_centroid(k,probofbat)
dio= 1.0
# print(cenbat)

# print("\n\n\n\n")

while dio>cd:
    clo = probofbat.map(lambda x: (nearest_cluster(x[1],cenbat),(x[1],1)))
    ps=clo.reduceByKey(summer)
    #print(ps.collect())
    hosa=ps.map(averageFinder).collect()
    dio=sum(find_distance(cenbat[iK],p) for (iK, p) in hosa)
    for (a,b) in hosa:
        cenbat[a] = b
#print(clo.collect())
# print(cenbat)
# print("\n\n\n\n")
# #print("Final centers: " + str(kPoints))
# print(probofbowl.collect()[0])

# print("\n\n\n\n")

k=50
cd=0.00000001

cenbowl=random_centroid(k,probofbowl)
dio= 1.0
# print(cenbowl)

# print("\n\n\n\n")

while dio>cd:
    clo = probofbowl.map(lambda x: (nearest_cluster(x[1],cenbowl),(x[1],1)))
    ps=clo.reduceByKey(summer)
    #print(ps.collect())
    hosa=ps.map(averageFinder).collect()
    dio=sum(find_distance(cenbowl[iK],p) for (iK, p) in hosa)
    for (a,b) in hosa:
        cenbowl[a] = b
#print(clo.collect())
# print(cenbowl)
# print("\n\n\n\n")



firstbat = spark.read.text("/projects/firstbat.txt").rdd.map(lambda x:x[0]).collect()
secondbat = spark.read.text("/projects/secondbat.txt").rdd.map(lambda x:x[0]).collect()
firstbowl = spark.read.text("/projects/firstbowl.txt").rdd.map(lambda x:x[0]).collect()
secondbowl = spark.read.text("/projects/secondbowl.txt").rdd.map(lambda x:x[0]).collect()



temp = dict(baltobatcprob.collect())

bowl = dict()
bat = dict()

for i in firstbowl:
    bowl[i] = temp[i]



for i in secondbowl:
    bowl[i] = temp[i]


temp = dict(probofbat.collect())
temp2 = dict(probofbowl.collect())


for i in firstbowl:
    for j in firstbat:
        if(j not in bowl[i].keys()):
            try:
                cbowl = cenbowl[nearest_cluster(temp2[i],cenbowl)]
            except:
                cbowl = [1/7,1/7,1/7,1/7,1/7,1/7,1/7,1,0.034]
            try:
                cbat = cenbat[nearest_cluster(temp[j],cenbat)]
            except:
                cbat = [1/7,1/7,1/7,1/7,1/7,1/7,1/7,1,0.034]
            probs = findProbCprobW(cbat, cbowl)
            bowl[i][j] = probs


for i in secondbowl:
    for j in secondbat:
        if(j not in bowl[i].keys()):
            try:
                cbowl = cenbowl[nearest_cluster(temp2[i],cenbowl)]
            except:
                cbowl = [1/7,1/7,1/7,1/7,1/7,1/7,1/7,1,0.034]
            try:
                cbat = cenbat[nearest_cluster(temp[j],cenbat)]
            except:
                cbat = [1/7,1/7,1/7,1/7,1/7,1/7,1/7,1,0.034]
            probs = findProbCprobW(cbat, cbowl)
            bowl[i][j] = probs




#print(bowl)
temp = 0
temp2 = 0
gc.collect()




'''

FIRST INNINGS


'''
import random

batting = dict()
bat_index = 2
batting[firstbat[0]] = 1
batting[firstbat[1]] = 1

striker = firstbat[0]
nonStriker = firstbat[1]

bowling = {i:0 for i in firstbowl}
over = 0
pervBowlindex = 0
#print(bowl[bowling.keys()[0]][striker])

firstInnScore = 0
noOfWickets = 0
matchNotDone = True
while matchNotDone:
    presBowlindex = random.randint(0,len(bowling.keys())-1)
    if(len(bowling.keys())>1 and presBowlindex == pervBowlindex):
        presBowlindex = (presBowlindex + 1)%len(bowling.keys())
    pervBowlindex = presBowlindex
    bowler = bowling.keys()[presBowlindex]
    for balls in range(6):
        lb = balls
        run = 0
        p = random.random()
        for i in range(7):
            if bowl[bowler][striker][1][i] >= p :
                if(i!=0):
                    i = i - 1
                if(i==5 or i == 6):
                    run = 6
                else:
                    run = i
                break
        batting[striker] = batting[striker]*(1-bowl[bowler][striker][2])
        firstInnScore = firstInnScore + run
        print("bowler = ",bowler,"nonStriker = ", nonStriker,", striker = ", striker, ", run = ", run, ", Total = ", firstInnScore, ", wicket = ", noOfWickets , ", over = ", over,"-",balls)
        if(batting[striker]<0.5):
            batting.pop(striker)
            noOfWickets = noOfWickets + 1
            print(striker,"is out!!!!", ", Total = ", firstInnScore, ", wicket = ", noOfWickets , ", over = ", over,"-",balls)
            if(noOfWickets == 10):
                matchNotDone = False
                break
            striker = firstbat[bat_index]
            batting[striker] = 1
            bat_index += 1
        if(run == 1 or run == 3):
            swap = striker
            striker = nonStriker
            nonStriker = swap
    swap = striker
    striker = nonStriker
    nonStriker = swap
    bowling[bowler] += 1
    if bowling[bowler] == 4:
        bowling.pop(bowler)
    over = over + 1
        
    if(over == 20):
        matchNotDone = False

if(lb==5):
    print("\n\nFirst Innings Done with score/wicket = "+str(firstInnScore)+"/"+str(noOfWickets), " and over = "+str(over) ,"\n\n\n\n\n")
else:
    print("\n\nFirst Innings Done with score/wicket = "+str(firstInnScore)+"/"+str(noOfWickets), " and over = "+str(over-1)+"-"+str(lb+1) ,"\n\n\n\n\n")





'''

SECOND INNINGS


'''




batting = dict()
bat_index = 2
batting[secondbat[0]] = 1
batting[secondbat[1]] = 1

striker = secondbat[0]
nonStriker = secondbat[1]

bowling = {i:0 for i in secondbowl}
over = 0
pervBowlindex = 0


secondInnScore = 0
noOfWickets = 0
matchNotDone = True
lb = 0
while matchNotDone:
    presBowlindex = random.randint(0,len(bowling)-1)
    if(len(bowling)>1 and presBowlindex == pervBowlindex):
        presBowlindex = (presBowlindex + 1)%len(bowling)
    pervBowlindex = presBowlindex
    bowler = bowling.keys()[presBowlindex]
    for balls in range(6):
        lb = balls
        run = 0
        p = random.random()
        for i in range(7):
            if bowl[bowler][striker][1][i] >= p :
                if(i!=0):
                    i = i - 1
                if(i==5 or i == 6):
                    run = 6
                else:
                    run = i
                break
        #print(batting)
        batting[striker] = batting[striker]*(1-bowl[bowler][striker][2])
        #print(batting)
        secondInnScore = secondInnScore + run
        print("bowler = ",bowler,", nonStriker = ", nonStriker,", striker = ", striker, ", run = ", run, ", Total = ", secondInnScore, ", wicket = ", noOfWickets , ", over = ", over,"-",balls)
        if(secondInnScore > firstInnScore):
            matchNotDone = False
            break
        if(batting[striker]<0.5):
            batting.pop(striker)
            noOfWickets = noOfWickets + 1
            print(striker,"is out!!!!", ", Total = ", secondInnScore, ", wicket = ", noOfWickets , ", over = ", over,"-",balls)
            if(noOfWickets == 10):
                lb = balls
                matchNotDone = False
                break
            striker = secondbat[bat_index]
            bat_index += 1
            batting[striker] = 1
        if(run == 1 or run == 3):
            swap = striker
            striker = nonStriker
            nonStriker = swap
    swap = striker
    striker = nonStriker
    nonStriker = swap
    bowling[bowler] += 1
    if bowling[bowler] == 4:
        bowling.pop(bowler)
    over = over + 1
        
    if(over == 20):
        matchNotDone = False


if(lb==5):
    print("\n\nSecond Innings Done with score/wicket = "+str(secondInnScore)+"/"+str(noOfWickets), " and over = "+str(over) ,"\n\n\n\n\n")
else:
    print("\n\nSecond Innings Done with score/wicket = "+str(secondInnScore)+"/"+str(noOfWickets), " and over = "+str(over-1)+"-"+str(lb+1) ,"\n\n\n\n\n")

spark.stop()
