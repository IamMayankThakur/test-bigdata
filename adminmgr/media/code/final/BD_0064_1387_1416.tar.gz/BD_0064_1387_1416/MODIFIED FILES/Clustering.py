
# coding: utf-8

# In[2]:


import pandas as pd
import matplotlib.pyplot as plt
import random
import math
import csv
file = pd.read_csv("batting.csv")
f2 = pd.read_csv("bowling.csv")


# In[38]:


''''for col in file.columns:
    print(col,end=" ")'''
for col in f2.columns:
    print(col,end=" ")


# In[39]:


plt.scatter(f2['St'],f2['Ct'])
plt.scatter(f2['Econ'],f2['Ct'])


# In[10]:


df = pd.DataFrame(file)
df["6s"] = df["6s"].astype(float).fillna(0.0)
df["4s"] = df["4s"].astype(float).fillna(0.0)
df["SR"] = df["SR"].astype(float).fillna(0.0)
df["Runs"] = df["Runs"].astype(float).fillna(0.0)
df["BF"] = df["BF"].astype(float).fillna(0.0)

df["6s"].fillna(0.0, inplace = True) 
df["4s"].fillna(0.0, inplace = True) 
df["SR"].fillna(0.0, inplace = True) 
df["Runs"].fillna(0.0, inplace = True) 
df["BF"].fillna(0.0, inplace = True) 
l=list()
for i in df.index:
    if(not(df['BF'][i]==0.0)):
        l.append(df['Runs'][i]/df['BF'][i])
    else:
        l.append(0.0)
df['RR']=l
means={}
done=[]
count=0
result={}
def distance(row1,row2):
    d=0
    for i in range(len(row1)):
        d+=(row1[i]-row2[i])**2
    return math.sqrt(d)
while count<6:
    x = random.randrange(530)
    if x not in done:
        done.append(x)
        means[(df["RR"][x],df["4s"][x],df["6s"][x])]=[]
        count+=1
for i in df.index:
    point = (df["RR"][i],df["4s"][i],df["6s"][i])
    result[point]=[]
    for v in means:
        d=distance(point , v)
        result[point].append((d,v))
#for v in result:
 #   print(v,end="----")
  #  print(result[v])
    


# In[11]:


#reducer

for pt in result:
    r = sorted(result[pt],key=lambda x:x[0])[0]
    means[r[1]].append((r[0],pt))
#print(len(means))
final_mean=[]
for value in means:
    x=value[0]
    y=value[1]
    z=value[2]
    r = means[value]
    if len(r):
        for val in r:
            x+=val[1][0]
            y+=val[1][1]
            z+=val[1][2]
        x = x/len(r)
        y = y/len(r)
        z = z/len(r)
        final_mean.append((x,y,z))
    else:
        final_mean.append(value)
for v in final_mean:
    print(v,end=" ")
#df.plot(kind='scatter',x='BF',y='Runs') 
#print(len(df))


# In[12]:


#actual clustering
r=[]
cluster=[]
a=df[['Runs','BF','4s','6s','Player']]
for ind in a.index:
    r=a.loc[ind]
    dt=[]
    #print(r[0])
    ll=[]
    if r[1]!=0.0:
        ll.append(r[0]/r[1])
    else:
        ll.append(0.0)
    ll.append(r[2])
    ll.append(r[3])
    for row1 in final_mean:
        x=[]
        x.append(row1[0])
        x.append(row1[1])
        x.append(row1[2])
        dt.append(distance(ll,x))
    #print(dt)
    min_val=dt.index(min(dt))
    cluster.append([r[4],min_val])
    #print(cluster,end="\t")
    #break
with open('cluster_batsmen', 'w',newline='') as csvfile: 
    # creating a csv writer object 
    csvwriter = csv.writer(csvfile)
    csvwriter.writerows(cluster)


# In[43]:


#BOWLING 
#for col in f2.columns:
    #print(col,end=" ")


# In[44]:


df = pd.DataFrame(f2)
#df["6s"] = df["6s"].astype(float).fillna(0.0)
df["St"] = df["St"].astype(float).fillna(0.0)
df["Ct"] = df["Ct"].astype(float).fillna(0.0)
df["Econ"] = df["Econ"].astype(float).fillna(0.0)
#df["BF"] = df["BF"].astype(float).fillna(0.0)

#df["6s"].fillna(0.0, inplace = True) 
df["St"].fillna(0.0, inplace = True) 
df["Ct"].fillna(0.0, inplace = True) 
df["Econ"].fillna(0.0, inplace = True) 
 


# In[45]:


means={}
done=[]
count=0
result={}
def distance(row1,row2):
    d=0
    for i in range(len(row1)):
        d+=(row1[i]-row2[i])**2
    return math.sqrt(d)
while count<5:
    x = random.randrange(531)
    if x not in done:
        done.append(x)
        means[(df["St"][x],df["Ct"][x],df["Econ"][x])]=[]
        count+=1
#print(means)
for i in df.index:
    point = (df["St"][i],df["Ct"][i],df["Econ"][i])
    result[point]=[]
    for v in means:
        #print(v)
        d=distance(point , v)
        result[point].append((d,v))


# In[46]:


#reducer

for pt in result:
    r = sorted(result[pt],key=lambda x:x[0])[0]
    means[r[1]].append((r[0],pt))
#print(len(means))
final_mean=[]
for value in means:
    x=value[0]
    y=value[1]
    z=value[2]
    r = means[value]
    if len(r):
        for val in r:
            x+=val[1][0]
            y+=val[1][1]
            z+=val[1][2]
        x = x/len(r)
        y = y/len(r)
        z = z/len(r)
        final_mean.append((x,y,z))
    else:
        final_mean.append(value)
print(final_mean[0])


# In[47]:


#actual clustering
r=[]
cluster=[]
a=df[['St','Ct','Econ','Player']]
for ind in a.index:
    r=a.loc[ind]
    dt=[]
    #print(r[0])
    ll=[]
    ll.append(r[0])
    ll.append(r[1])
    ll.append(r[2])
    for row1 in final_mean:
        x=[]
        x.append(row1[0])
        x.append(row1[1])
        x.append(row1[2])
        dt.append(distance(ll,x))
    min_val=dt.index(min(dt))
    cluster.append([r[3],min_val])
    #print(cluster,end="\t")
    #break
with open('cluster_bowlers', 'w',newline='') as csvfile: 
    # creating a csv writer object 
    csvwriter = csv.writer(csvfile)
    csvwriter.writerows(cluster)


# In[ ]:




