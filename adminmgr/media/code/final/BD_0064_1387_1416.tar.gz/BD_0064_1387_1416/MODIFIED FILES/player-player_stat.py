
# coding: utf-8

# In[56]:


import pandas as pd
f = pd.read_csv("ipl_names.csv")
df=pd.DataFrame(f)
print(df.columns)


# In[59]:


csvfile = open('player_player_new_stats.csv','w',newline='')
fieldnames = ['batsman', 'bowler', '0','1','2','3','4','6','out','batclustno','bowlclustno','balls']
writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
writer.writeheader()


# In[60]:


stats={}
i=0
for i in df.index:
    bat , bowl = df["Batsman"][i],df["Bowler"][i]
    runs =  df["Runs"][i]
    wicket = df["Wicket"][i]
    if (bat,bowl) not in stats:
        stats[(bat,bowl)] = {} 
        stats[(bat,bowl)]["occ"]=0
        stats[(bat,bowl)]["0"]=0
        stats[(bat,bowl)]["1"]=0
        stats[(bat,bowl)]["2"]=0
        stats[(bat,bowl)]["3"]=0
        stats[(bat,bowl)]["4"]=0
        stats[(bat,bowl)]["5"]=0
        stats[(bat,bowl)]["6"]=0
        stats[(bat,bowl)]["bat_cluster"]="10"
        stats[(bat,bowl)]["bowl_cluster"]="10"
        stats[(bat,bowl)]["wicket"]=0
    stats[(bat,bowl)]["occ"]+=1
    stats[(bat,bowl)][str(runs)]+=1
    if wicket:
        stats[(bat,bowl)]["wicket"]+=1
    balls=stats[(bat,bowl)]["occ"]
    batclustno = 0
    bowlclusrno = 0
    #break
''''with open('cluster_batsmen.csv') as file1:
        read = csv.reader(file1)
        for row in read:
            print(type(row[1]))
            break'''
for pair in stats:
    with open('cluster_batsmen.csv') as file1:
        read = csv.reader(file1)
        for row in read:
            if row[0] == pair[0]:
                stats[pair]["bat_cluster"] = row[1]
                break
    with open('cluster_bowlers.csv') as file2:
        read = csv.reader(file2)
        for row in read:
            if row[0] == pair[1]:
                stats[pair]["bowl_cluster"] = row[1]
                break
    i+=1
    #print(pair,end=":")
    #print(stats[pair])
    balls=stats[pair]["occ"]
    #writer.writeheader()
    writer.writerow({'batsman':pair[0],'bowler':pair[1],'0':stats[pair]["0"]/balls,'1':stats[pair]["1"]/balls,'2':stats[pair]["2"]/balls,'3':stats[pair]["3"]/balls,'4':stats[pair]["4"]/balls,'6':stats[pair]["6"]/balls,'out':stats[pair]["wicket"]/balls,'batclustno':stats[pair]["bat_cluster"],'bowlclustno':stats[pair]["bowl_cluster"],'balls':balls})
print(i)


# In[ ]:




