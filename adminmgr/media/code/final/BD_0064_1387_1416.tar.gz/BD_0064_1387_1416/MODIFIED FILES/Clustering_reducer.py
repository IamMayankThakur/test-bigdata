import pandas as pd
#import matplotlib.pyplot as plt
import random
import sys
import math
import csv
#reader=sys.stdin
#result={}
#reader=sys.stdin
#print(reader)
f = open("out.txt","r")
ip={}
cluster={}
for row in f:
	#print(row)
	l=[]
	c=[]
	pt , info = row.split(':')
	pt=list(pt.split("-"))
	pt[0]=float(pt[0])
	pt[1]=float(pt[1])
	pt[2]=float(pt[2])
	pt=tuple(pt)
	#print(pt)
	l = list(info.split(';'))
	ip[pt]=[]
	#print(l)
	for i in range(len(l)):
		l[i]=l[i].split("=")
		l[i][1]=l[i][1].split("-")
		l[i][1][0]=float(l[i][1][0])
		l[i][1][1]=float(l[i][1][1])
		l[i][1][2]=float(l[i][1][2])
		l[i][0]=float(l[i][0])
		#print(l[i][0])
		#print(l[i][1])
		l[i][1]=tuple(l[i][1])
		l[i]=tuple(l[i])
		ip[pt].append(l[i])
		#print(l[i])	
	#print(l)
	#print(ip[pt])
	ip[pt].sort(key=lambda x : x[0])
	c=ip[pt][0]
	#break
	cluster[pt]=l.index(c)

	
#print(ip)
'''for row in reader:
    row=row.strip()
    
    #print(row.split('\n'))
    #print(key)
    #print(val)
    p=tuple(key.split(","))
    n=list(val.split(","))
    result[p]=n'''
'''for pt in result:
    r = sorted(result[pt],key=lambda x:x[0])[0]
    means[r[1]].append((r[0],pt))

final_mean=[]
for value in means:
    x=value[0]
    y=value[1]
    z=value[2]
    r = means[value]
    if len(r):
        for val in r:
            x+=val[1][0]
            y+=val[1][1]
            z+=val[1][2]
        x = x/len(r)
        y = y/len(r)
        z = z/len(r)
        final_mean.append((x,y,z))
    else:
        final_mean.append(value)'''




'''for v in final_mean:
    print(v,end=" ")'''


'''
#actual clustering
r=[]
cluster=[]
a=df[['Runs','BF','4s','6s','Player']]
for ind in a.index:
    r=a.loc[ind]
    dt=[]
    #print(r[0])
    ll=[]
    if r[1]!=0.0:
        ll.append(r[0]/r[1])
    else:
        ll.append(0.0)
    ll.append(r[2])
    ll.append(r[3])
    for row1 in final_mean:
        x=[]
        x.append(row1[0])
        x.append(row1[1])
        x.append(row1[2])
        dt.append(distance(ll,x))
    min_val=dt.index(min(dt))
    cluster.append([r[4],min_val])
    #print(cluster,end="\t")
    #break
with open('cluster_batsmen', 'w',newline='') as csvfile: 
    # creating a csv writer object 
    csvwriter = csv.writer(csvfile)
    csvwriter.writerows(cluster)'''

