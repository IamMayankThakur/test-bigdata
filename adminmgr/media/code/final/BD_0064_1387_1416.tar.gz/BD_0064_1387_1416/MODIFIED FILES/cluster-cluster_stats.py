
# coding: utf-8

# In[4]:


import pandas as pd
pairs = pd.read_csv('player-stats.csv')
del pairs['batsman']
del pairs['bowler']

final = cpairs.groupby(['batclustno','bowlclustno']).mean()
final.to_csv('check.csv')

