#!/usr/bin/python

"""
#!/usr/bin/env python
0.    Ball
1.    Innings
2.    Over.Ball of the over
3.    Batting Team
4.    Batsman on strike
5.    Batsman on non-striker's end
6.    Bowler
7.    Runs scored on that ball
8.    Extra
9.    Nature of dismissal
10.   Batsman dismissal

"""
'''
def run_cmd(args_list):
	"""
	run linux commands
	"""
	# import subprocess
	print('Running system command: {0}'.format(' '.join(args_list)))
	proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	s_output, s_err = proc.communicate()
	s_return =  proc.returncode
	return s_output.decode('utf-8')
'''

import sys

#cluster_batsman = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bat.csv').split("\n")

f1_bat=open("/home/durga/codetillnow/centroids_batting.txt","r")
data1_bat=f1_bat.read()
lines1_bat=data1_bat.split('\n')

#cluster_bowler = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bowl.csv').split("\n")

f1_bowl=open("/home/durga/codetillnow/centroids_bowling.txt","r")
data1_bowl=f1_bowl.read()
lines1_bowl=data1_bowl.split('\n')


def cluster_bat(player):
	for i in range(len(lines1_bat)):
		players = lines1_bat[i].split(",")[1:]
		if(player in players):
			return i
	return -1

def cluster_bowl(player):
	for j in range(len(lines1_bowl)):
		players = lines1_bowl[j].split(",")[1:]
		#print("bowwwwwl", players)
		if(player in players):
			return j
	return -11

for record in sys.stdin:
	record = record.strip()
	values = record.split(",")
	if(values[0] == 'ball'):
		#print(str(values) + '\t' + str(len(values)));
		#print(values[4])
		#print(values[6])
		bat_c = cluster_bat(values[4])
		bowl_c = cluster_bowl(values[6])+10
		runs = int(values[7])

		if (values[9] == ""):
			if(runs==0):
				print("%s^%s:1 0 0 0 0 0 0 0 1 " %(bat_c,bowl_c))
			elif(runs==1):
				print("%s^%s:0 1 0 0 0 0 0 0 1 " %(bat_c,bowl_c))
			elif(runs==2):
				print("%s^%s:0 0 1 0 0 0 0 0 1 " %(bat_c,bowl_c))
			elif(runs==3):
				print("%s^%s:0 0 0 1 0 0 0 0 1 " %(bat_c,bowl_c))
			elif(runs==4):
				print("%s^%s:0 0 0 0 1 0 0 0 1 " %(bat_c,bowl_c))
			elif(runs==5):
				print("%s^%s:0 0 0 0 0 1 0 0 1 " %(bat_c,bowl_c))
			elif(runs==6):
				print("%s^%s:0 0 0 0 0 0 1 0 1 " %(bat_c,bowl_c))
		else:
			if (values[9] == 'run out'):
				if(runs==0):
					print("%s^%s:1 0 0 0 0 0 0 1 1 " %(bat_c,bowl_c))
				elif(runs==1):
					print("%s^%s:0 1 0 0 0 0 0 1 1 " %(bat_c,bowl_c))
				elif(runs==2):
					print("%s^%s:0 0 1 0 0 0 0 1 1 " %(bat_c,bowl_c))
				elif(runs==3):
					print("%s^%s:0 0 0 1 0 0 0 1 1 " %(bat_c,bowl_c))
				elif(runs==4):
					print("%s^%s:0 0 0 0 1 0 0 1 1 " %(bat_c,bowl_c))
				elif(runs==5):
					print("%s^%s:0 0 0 0 0 1 0 1 1 " %(bat_c,bowl_c))
				elif(runs==6):
					print("%s^%s:0 0 0 0 0 0 1 1 1 " %(bat_c,bowl_c))
			else:
					print("%s^%s:0 0 0 0 0 0 0 1 1" %(bat_c,bowl_c))
