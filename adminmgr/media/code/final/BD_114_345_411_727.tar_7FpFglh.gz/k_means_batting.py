import sys
from pyspark.sql import SparkSession
import math
import random

spark = SparkSession\
        .builder\
        .appName("k_means")\
        .getOrCreate()

def dist(p1, p2):
    dist = 0;
    for i in range(len(p1)):
        dist+= (p1[i]-p2[i])**2

    dist = (dist)**(1/2)

    return dist

def add_vectors(a, b):
    c = []
    for i in range(len(a)):
        c.append(a[i]+ b[i])
    return c

def scalar_mult(a, k):
    c = []
    for i in range(len(a)):
        c.append(a[i]*k)

    return c

def belongs_to_cluser(player, centroids):

    min = math.inf
    min_cluster = -1

    for i in range(len(centroids)):
        if(dist(player, centroids[i]) < min):
            min = dist(player, centroids[i])
            min_cluster = i

    return (min_cluster, (player, 1))

players = spark.read.option("header", "true").option("delimiter", '\n').csv(sys.argv[1])\
        .rdd.map(lambda r: r[0])\
        .filter(lambda x: len(x)>0)\
        .map(lambda x: x.split(','))\
        .map(lambda x: [float(x[6].strip('*')), float(x[7].strip('*')), float(x[9].strip('*'))])


centroids = [[random.randrange(5,200, 8 ) for i in range(3)] for j in range(int(sys.argv[2]))]

max_iterations = int(sys.argv[3])

for i in range(max_iterations):

    x = players.map(lambda x: belongs_to_cluster(x, centroids))
    y = x.reduceByKey(lambda a,b: (add_vectors(a[0], b[0]), a[1]+b[1]))
    z = y.map(lambda x: scalar_mult(x[1][0], 1/x[1][1]))
    centroids = z.collect()


for i in range(len(centroids)):
    print(centroids[i])


spark.stop()
