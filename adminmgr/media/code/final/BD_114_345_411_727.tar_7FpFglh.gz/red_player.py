#!/usr/bin/python

import sys


#import subprocess

'''
def run_cmd(args_list):
	"""
	run linux commands
	"""

	#print('Running system command: {0}'.format(' '.join(args_list)))
	proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	s_output, s_err = proc.communicate()
	s_return =  proc.returncode
	return s_output.decode('utf-8')
'''

key = ''
ls = []
def add_list(a,b):
	new=[]
	#print("/////////////")
	#print(a, b)
	for i in range(len(a)):
		#print("before", new)
		new.append(a[i]+b[i])
		#print("after", new)
	return new


#input=run_cmd('cat', 'dfs', '-put', 'player_prob.csv','/clusters/').split('\n')


for record in sys.stdin:
	#print(record)
	key_new, val = record.split(":")
	#print("valll",val.split())
	val=val.strip()
	val = [int(k) for k in val.split(" ")]

	if(key_new != key):
		ls.append([key_new,val])
		key = key_new
	else:
		#print("before",ls[len(ls)-1][1])
		ls[len(ls)-1][1] = add_list(ls[len(ls)-1][1], val)
		#print("after",ls[len(ls)-1][1])


def div(a):
	last=a[len(a)-1]
	#print("before", a)
	#print("last", last)
	if (last != 0):
		#print(last)
		#print(type(last))
		for i in range(len(a)):
			#print("value", a[i])
			if(a[i]==0):
				a[i]=0
			else:
				a[i]=float((float(a[i])/float(last)))
	#print("after", a)
	return a

def cumulative(a):
	for i in range(1,len(a)-1):
		a[i]=a[i]+a[i-1]
		#print("ss",a[i])
	return a

#print("before",ls)

for x in ls:
	x[1]=div(x[1])
	b = list()
	for i in x[1]:
		b.append(i)
	#print("before",x)
	x.append(cumulative(b))
	#print(x)
	#print("afete ",x)
#print(x)
for i in ls:
	print(i)

'''
import pandas as pd
df=pd.DataFrame(ls)
#print(df)
#print("df",df)
df.to_csv("player_prob.csv")
#player =run_cmd('hdfs', 'dfs', '-put', 'player_prob.csv','/clusters/').split('\n')
'''
