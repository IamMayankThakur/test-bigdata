#!/usr/bin/python

import sys

key = ''
ls = []
def add_list(a,b):
	new=[]
	for i in range(len(a)):
		new.append(a[i]+b[i])
	return new

for record in sys.stdin:
	key_new, val = record.split(":")
	val = val.strip()
	val = [int(k) for k in val.split(" ")]

	if(key_new != key):
		ls.append([key_new,val])
		key = key_new
	else:
		#print("before", ls[len(ls)-1][1])
		ls[len(ls)-1][1] = add_list(ls[len(ls)-1][1], val)
		#print("after", ls[len(ls)-1][1])
def div(a):
	last=a[len(a)-1]
	#print("last", last)
	for i in range(len(a)):
		if(a[i]==0):
			a[i]=0
		else:
			a[i]=float(float(a[i])/float(last))
	return a


def cumulative(a):
	#print(a)
	for i in range(1, len(a)-1):
		a[i]=a[i]+a[i-1]
		#print("ss",a[i])
	return a
'''

ls=[ ['nishi,durga',[0,1,2,3,6]],
	['srisha',[1,1,1,2,5]]
]

'''

for x in ls:
	x[1]=div(x[1])
	b = list()
	for i in x[1]:
		b.append(i)
	ret = cumulative(b)
	x.append(ret)
	#print("x",x)
	#print(len(x))
for i in ls:
	print(i)
'''
#print("after",ls)
import pandas as pd
df=pd.DataFrame(ls)
#print("df",df)
df.to_csv("cluster_prob.csv")
print(df)
'''
