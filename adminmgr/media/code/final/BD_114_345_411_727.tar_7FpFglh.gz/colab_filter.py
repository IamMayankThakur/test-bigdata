import findspark
findspark.init()
from __future__ import print_function
from pyspark import SparkContext
from pyspark.sql import SparkSession
from collections import defaultdict 
import csv
from pyspark.ml.recommendation import ALS
from pyspark.sql import Row
from pyspark.ml.feature import StringIndexer
from pyspark.sql import functions as F
from pyspark.sql.functions import udf
from pyspark.sql.types import IntegerType
import math
spark = SparkSession\
		.builder\
		.appName("PredictUnseenPairs")\
		.getOrCreate()

f1=open("ipl.csv", 'r')
lines = csv.reader(f1)
f2=open('ipl1.csv','w', newline='')
writer = csv.writer(f2)

for line in lines:
  line[0]=line[0].strip()
  if(line[0]=='ball'):
    line[9]=line[9].strip()
    if(line[9]=='run out'):
      wick=1
    else:
      wick=0
      print(list1)
    list1=[line[4].strip(),line[6].strip(),line[7].strip(),wick]
    writer.writerow(list1)
bat_bowl_pairs=spark.read.csv("ipl1.csv")

headers = ['batsman', 'bowler', 'dot_balls','ones','twos','threes','fours','sixes','wickets','balls']
dict1 = defaultdict(list) 

with open("ipl1.csv", 'r') as f1:
    lines = csv.reader(f1)
    for line in lines:
    	val = [line[2],line[3]]
    	dict1[line[0],line[1]].append(val)

with open('PvP.csv','w', newline='') as f2:
    writer = csv.writer(f2)
    writer.writerow(headers)
    for k,v in dict1.items():
        dot_balls =0
        ones =0
        twos =0
        threes =0
        fours =0
        sixes =0
        wickets =0
        balls =0
        for i in v:
            if i[0] == '0':
                dot_balls =dot_balls+1
            elif i[0] == '1':
                ones =ones+1
            elif i[0] == '2':
                twos =twos+1
            elif i[0] == '3':
                threes = threes+1
            elif i[0] == '4':
                fours =fours+1
            elif i[0] == '6':
                sixes =sixes+1
            if i[1]=='1':
                wickets=wickets+1
            balls = balls+1
        list1=[k[0], k[1], dot_balls, ones, twos, threes, fours, sixes, wickets, balls]
        writer.writerow(list1)

df = spark.read.csv("PvP.csv",inferSchema=True,header=True)

new_df=df.select(df['batsman'],df['bowler'],df['dot_balls'],df['ones'],df['twos'],df['threes'],df['fours'],df['sixes'],df['wickets'])

indexer_batsman = StringIndexer(inputCol="batsman", outputCol="batsman_index")
indexer_bowler = StringIndexer(inputCol="bowler", outputCol="bowler_index")
after_indexing = indexer_batsman.fit(new_df).transform(new_df)
labels_indexed = indexer_bowler.fit(after_indexing).transform(after_indexing)

(labels_indexed,test)=labels_indexed.randomSplit([0.98,0.02])

batsman=df.select('batsman').distinct()

bowler=df.select('bowler').distinct()

cart_prod=batsman.crossJoin(bowler)

bat_bowl_seen_pairs=df.select(df['batsman'],df['bowler']).dropDuplicates()
unseen_pairs=cart_prod.subtract(bat_bowl_seen_pairs)
test=unseen_pairs
after_indexing = indexer_batsman.fit(test).transform(test)
test = indexer_bowler.fit(after_indexing).transform(after_indexing)

als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="dot_balls",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)

predictions_dot = model.transform(test)
predictions_dot=predictions_dot.withColumn("prediction", F.ceil(predictions_dot["prediction"]))


als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="ones",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_ones = model.transform(test)
predictions_ones=predictions_ones.withColumn("prediction", F.ceil(predictions_ones["prediction"]))

als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="twos",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_twos = model.transform(test)
predictions_twos=predictions_twos.withColumn("prediction", F.ceil(predictions_twos["prediction"]))
als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="threes",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_threes = model.transform(test)
predictions_threes=predictions_threes.withColumn("prediction", F.ceil(predictions_threes["prediction"]))
als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="fours",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_fours = model.transform(test)
predictions_fours=predictions_fours.withColumn("prediction", F.ceil(predictions_fours["prediction"]))
als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="sixes",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_sixes = model.transform(test)
def round_sixes(six):
  if six<1:
    if six>0.5:
      return 1
    else:
      return 0
  else:
    return math.ceil(six)
myUdf1 = udf(round_sixes, IntegerType())
predictions_sixes=predictions_sixes.withColumn("prediction", myUdf1(predictions_sixes["prediction"]))
als = ALS(maxIter=15,regParam=0.35,rank=2, userCol="batsman_index", itemCol="bowler_index", ratingCol="wickets",
          coldStartStrategy="drop",nonnegative=True)
model = als.fit(labels_indexed)
predictions_wickets = model.transform(test)

def round_wicket(wick):
  if wick>0.5:
    return 1
  else:
    return 0
myUdf2 = udf(round_wicket, IntegerType())

predictions_wickets=predictions_wickets.withColumn("prediction", myUdf2(predictions_wickets["prediction"]))
test=test.withColumn('row_index', F.monotonically_increasing_id())
predictions_dot=predictions_dot.withColumn('row_index', F.monotonically_increasing_id())
predictions_ones=predictions_ones.withColumn('row_index', F.monotonically_increasing_id())
predictions_twos=predictions_twos.withColumn('row_index', F.monotonically_increasing_id())
predictions_threes=predictions_threes.withColumn('row_index', F.monotonically_increasing_id())
predictions_fours=predictions_fours.withColumn('row_index', F.monotonically_increasing_id())
predictions_sixes=predictions_sixes.withColumn('row_index', F.monotonically_increasing_id())
predictions_wickets=predictions_wickets.withColumn('row_index', F.monotonically_increasing_id())

df1 = test.join(predictions_dot["row_index","prediction"], on=["row_index"])
df1 = df1.withColumnRenamed("prediction", "dot_balls")

df1 = df1.join(predictions_ones["row_index","prediction"], on=["row_index"])

df1 = df1.withColumnRenamed("prediction", "ones")
df1 = df1.join(predictions_twos["row_index","prediction"], on=["row_index"])
df1 = df1.withColumnRenamed("prediction", "twos")
df1 = df1.join(predictions_threes["row_index","prediction"], on=["row_index"])
df1 = df1.withColumnRenamed("prediction", "threes")
df1 = df1.join(predictions_fours["row_index","prediction"], on=["row_index"])
df1 = df1.withColumnRenamed("prediction", "fours")
df1 = df1.join(predictions_sixes["row_index","prediction"], on=["row_index"])
df1 = df1.withColumnRenamed("prediction", "sixes")
df1 = df1.join(predictions_wickets["row_index","prediction"], on=["row_index"]).drop('row_index').drop("batsman_index").drop("bowler_index")
df1 = df1.withColumnRenamed("prediction", "wickets")
df = df1.withColumn('balls', sum(df1[col] for col in ["dot_balls","ones","twos","threes","fours","sixes","wickets"]))
new_df=df.select(df['batsman'],df['bowler'],df['dot_balls']/df['balls'],df['ones']/df['balls'],df['twos']/df['balls'],df['threes']/df['balls'],df['fours']/df['balls'],df['sixes']/df['balls'],df['wickets']/df['balls'],df['balls'])

new_df.repartition(1).write.format("csv").option("header", "true").save('unseen_pairs.csv')

