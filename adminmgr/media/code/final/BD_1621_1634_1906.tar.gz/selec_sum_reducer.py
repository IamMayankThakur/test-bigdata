#!/usr/bin/python3
import sys


i=0
output=""
key=""
for line in sys.stdin:

	key,value=line.split(sep="\t")
	
	if not(i):
		try:
			value=float(value)
		except:
			print("column is non-numeric")
			exit(0)
		output=value
		i+=1
		continue
	
	
	output+=float(value)
	
	

print("SUM of ",key," = ",output)
