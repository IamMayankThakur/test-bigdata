#!/usr/bin/python3
import sys

arg_input=""

for i in range(1,len(sys.argv)):
	if not(i==1):
		arg_input=arg_input+" "+ sys.argv[i]
	else:
		arg_input=sys.argv[i]
	
#colname1,colname2,...:colname=value

i=0
meta_columns=[]
metadata=[]

temp_split=arg_input.split(sep=":")
#required_columns,condition_with_column=arg_input.split(sep=":")

#con_col,con_value=condition_with_column.split(sep="=")

required_columns=temp_split[0]
con_col=temp_split[1]
con_value=temp_split[3]

tester=temp_split[2]




for line in sys.stdin:
	key="a"
	value=""
	
	if not(i):
		metadatas=line.split(sep=",")
		
		for a in metadatas:
			metadata.append(a.split(sep=":")[0])
		
		meta_columns=metadata;
		#meta_types.append(a2)
		i+=1
		
		#compute required columns
		if(required_columns=="*"):
			required_columns=metadata
		else:
			required_columns=required_columns.split(sep=",")
		
		continue
	
	tuple_values=line.split(sep=",")
	
	for c in required_columns:
		
		value=value+tuple_values[metadata.index(c)]+","
		
	if(con_col=="*"):
		print("%s\t%s"%(key,value))
	
	else:
		if(eval(con_value+tester+tuple_values[metadata.index(con_col)])):
			print("%s\t%s"%(key,value))		
	
	
	
