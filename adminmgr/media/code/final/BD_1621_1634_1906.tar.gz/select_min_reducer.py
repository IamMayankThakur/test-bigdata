#!/usr/bin/python3
import sys


i=0
output=""
key=""
for line in sys.stdin:

	key,value=line.split(sep="\t")
	
	if not(i):
		
		output=value
		i+=1
		continue
	
	if(value<output):
		output=value
	

print("MIN of ",key," = ",output)
