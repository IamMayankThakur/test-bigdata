#!/usr/bin/python3
import sys

arg_input=""

for i in range(1,len(sys.argv)):
	if not(i==1):
		arg_input=arg_input+" "+ sys.argv[i]
	else:
		arg_input=sys.argv[i]
	
#colname:colname:==:value

aggr_col_con_col=arg_input.split(sep=":")

aggr_col=aggr_col_con_col[0]

#con_col,con_value=aggr_col_con_col[1].split(sep="=")
con_col=aggr_col_con_col[1]
con_value=aggr_col_con_col[3]
tester=aggr_col_con_col[2]

metadata=[]

i=0
meta_columns=[]
meta_types=[]
key=aggr_col
value=""

for line in sys.stdin:
	if not(i):
		metadata=line.split(sep=",")
		
		for a in metadata:
			a1,a2=a.split(sep=":")
			meta_columns.append(a1)
			meta_types.append(a2)
		i+=1
		continue


	tuple_values=line.split(sep=",")	
	
	aggr_col_index=meta_columns.index(aggr_col)
	value=tuple_values[aggr_col_index]
	
	#con_col_index=meta_columns.index(con_col)
	if(con_value=="*"):
		print("%s\t%s"%(key,value))

	else:
		
		con_col_index=meta_columns.index(con_col)
		
		if(eval(tuple_values[con_col_index]+tester+con_value)):
			
			print("%s\t%s"%(key,value))
		
		
		
	
	
	
	
	
	
