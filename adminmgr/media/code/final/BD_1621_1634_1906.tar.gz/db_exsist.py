import os

a = os.system('hdfs dfs -du -s /user > tmp')
if a:
	print('fail')
else:
	print('present')

print(a)