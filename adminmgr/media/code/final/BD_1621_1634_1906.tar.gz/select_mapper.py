import sys

arg1 = sys.argv[1]
arg2 = sys.argv[2]
'''
pass string as arg1 : col1,col3,col4
'''

list_of_columns=list()
list_of_columns.append(arg1)
list_of_columns.append(arg2)
metadata=sys.stdin[0]
required_column_indexes=[metadata.index(a) for a in list_of_columns]




for line in sys.stdin:
    line=line.strip()
    row_values=line.split(sep=",")
    
    value_str=''
    for i in required_column_indexes:
        str+=row_values[i]

    key=line
    value=value_str

    print ('%s\t%s' % (key, value))

