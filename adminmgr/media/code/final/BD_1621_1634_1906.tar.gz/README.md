# big-data-miniHIVE
Big data project: Implementation of miniHIVE

This project aims at implementing a simple HIVE client.
Usuage:
  Run the sql_client.py file
