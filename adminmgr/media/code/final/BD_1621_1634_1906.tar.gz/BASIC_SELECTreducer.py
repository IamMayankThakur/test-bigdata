#!/usr/bin/python3
import sys
import csv

for line in sys.stdin:
	printr=""
	
	
	my_list=line.split('\t')
	for i in range(0,len(my_list)):
		if not(my_list[i]==" " or my_list[i]==","  or my_list[i]==""):
			printr=printr+","+str(my_list[i])
	print(printr.strip(","))
	
	
	
	


