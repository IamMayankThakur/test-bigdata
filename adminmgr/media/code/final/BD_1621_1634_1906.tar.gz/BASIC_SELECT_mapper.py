#!/usr/bin/python3
import sys
import csv

#next(infile)
val=0
p1=sys.argv[1]

p=p1.split(',')
index=list()
count=0

#fuel column index 8
for line in sys.stdin:
	printr=""
	if(p1=="*"):
		mylist=line.split(',')
		if(count==0):
			k1=9
		elif(count>0):
			for i in range(0,len(mylist)):
				if not(mylist[i]==" "):
					printr=printr+"\t"+str(mylist[i])
	else:
			
	
		mylist=line.split(',')
		if(count==0):
			for i in range(0,len(mylist)):
				for j in range(0,len(p)):
					
					if(p[j]==(mylist[i].split(":"))[0]):
						index.append(i)
			
			
			
						
				
	
		if(count>0):
			for i in range(0,len(index)):
				printr=printr+"\t"+str(mylist[index[i]])
	print("%s"%(printr))
	count=count+1
	
	
	
	
	
	

			
		
			
		
