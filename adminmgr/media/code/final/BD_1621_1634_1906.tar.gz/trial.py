import os
import sys
os.system('cat trial.csv')
os.system('ls')
print(sys.stdin)