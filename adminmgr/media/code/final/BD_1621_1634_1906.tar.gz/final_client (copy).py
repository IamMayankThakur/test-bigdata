from __future__ import print_function
import sys
import os

if sys.version_info.major > 2:
	# support for compatibility
	raw_input = input

def prepend_line_to_file(filename, line):
	try:
		with open(filename, 'r+') as f:
			content = f.read()
			f.seek(0,0)
			f.write(line.rstrip('\r\n') + \
				'\n' + content)
		return 0
	except:
		print('[ERROR] Unable to access',\
			filename)
		return 1

def file_in_hdfs(path):
	ret = os.system('hdfs dfs -ls ' + str(path))
	return 1 if ret == 0 else 0

def folder_empty_hdfs(path):
	os.system("hdfs dfs -du -s " + path + " > .hdfs_file_size")
	with open(".hdfs_file_size", "r") as f:
		ret = f.readline().split(' ')[0]
		ret = int(ret)
	#os.system("rm .hdfs_file_size")
	return 1 if ret == 0 else 0

def delete_folder_hdfs(path):
	os.system("hdfs dfs -rmdir " + path)
	pass

def delete_file_hdfs(path):
	os.system("hdfs dfs -rm " + path)
	pass

def make_folder_in_hdfs(path):
	os.system("hdfs dfs -mkdir " + path)
	pass

def make_file_in_hdfs(file, path):
	os.system("hdfs dfs -put " + file + " " + path)
	pass

def help_handler():
	print("Supported Operations are: ")
	print("1.EXIT: \
		\n  Close the application")
	print("2.LOAD <database>/<table>.csv \
		AS (<column_name>:<column_type> [, <column_name>:<column_type>, ...]) \
		\n  Load the database and table \
		along with schema")
	print("3.DELETE <database>/<table>.csv \
		\n  Delete the table")
	print("4.SELECT <column_name>[, <column_name>, ...] \
		FROM <database_name>/<table>.csv \
		WHERE <column_name>=<value>\
		\n Select the columns from the database satisfying conditions in WHERE")

def exit_handler():
	print("Session closed")
	print("Exit")

def load_handler(client_query):
	client_query = client_query.split(' ')
	db_name, tb_name = client_query[1].split('/')
	db_name, tb_name = db_name.rstrip(' '), tb_name.rstrip(' ')
	if db_name == '' or tb_name == '' or client_query[2].upper() != "AS":
		print("Invalid Sytanx")
		return 1
	db_name, tb_name = str(db_name), str(tb_name)

	path = '/data'
	db_path = path + '/' + db_name
	tb_path = path + '/' + db_name + '/' + tb_name

	schema = ''.join(client_query[3:])
	schema = schema.lstrip('(').rstrip(')')
	schema = ';'.join(schema.split(','))

	prepend_line_to_file(tb_name, schema)

	if not file_in_hdfs(db_path):
		make_folder_in_hdfs(db_path)
	if not file_in_hdfs(tb_path):
		make_file_in_hdfs(tb_name, db_path)
	else:
		print('Previous Table will be used')
	return 0

def delete_handler(client_query):
	client_query = client_query.split(' ')
	db_name, tb_name = client_query[1].split('/')
	if db_name == '' or tb_name == '':
		print('Invalid Sytanx')
		return 1
	db_name, tb_name = str(db_name), str(tb_name)

	path = '/data'
	db_path = path + '/' + db_name
	tb_path = path + '/' + db_name + '/' + tb_name

	delete_file_hdfs(tb_path)
	if folder_empty_hdfs(db_path):
		delete_folder_hdfs(db_path)

def select_handler(client_query):
	pass

def select_where_handler(client_query):
	pass

def select_where_aggregate_handler(client_query):
	pass

def client_handler():
	client_query = raw_input('>> ')
	query_type = client_query.split(' ')[0].upper()

	if query_type == 'HELP':
		help_handler()
	elif query_type == 'EXIT':
		exit_handler()
	elif query_type == 'LOAD':
		load_handler(client_query)
	elif query_type == 'DELETE':
		delete_handler(client_query)
	elif query_type == 'SELECT':
		select_handler(client_query)
	else:
		return 1

	return 0

if __name__ == "__main__":
	print('START')
	if not file_in_hdfs('/data'):
		make_folder_in_hdfs('/data')
	try:
		while True:
			success = client_handler()
	except KeyboardInterrupt:
		pass
	print('END')