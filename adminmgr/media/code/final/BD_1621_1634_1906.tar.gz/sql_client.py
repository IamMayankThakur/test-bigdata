from __future__ import print_function
import sys
import os

if sys.version_info.major > 2:
	raw_input = input

def add_schema(filename, line):
	with open(filename, 'r+') as f:
		content = f.read()
		f.seek(0, 0)
		f.write(line.rstrip('\r\n') + '\n' + content)

def main():
	global db_name
	client_query = raw_input('>> ')
	client_query = client_query.split(' ')
	query_type = client_query[0].upper()
	first_time = 1
	try:
		if query_type == 'LOAD':
			print('LOAD')
			db_name, tb_name = client_query[1].split('/')
			if db_name == '' or tb_name == '':
				print('error empty database name or table name')
				return 1
			query_schema = ''.join(client_query[3:])
			query_schema = query_schema.lstrip('(').rstrip(')')
			query_schema = ';'.join(query_schema.split(','))
			# TODO: Use regex to check schema
			print('\n\tdb_name', db_name, '\n\ttb_name', tb_name, '\n\tquery_schema', query_schema)
			try:
				if first_time:
					add_schema(tb_name, query_schema)
			except:
				print('File not found')
				return 1
			try:
				if raw_input('continue ? ').upper()[0] == 'Y':
					if first_time:
						os.system('hdfs dfs -mkdir /data/' + str(db_name))
						os.system('hdfs dfs -put ' + str(tb_name) + ' /data/' + str(db_name))
						first_time = 0
					os.system('hdfs dfs -ls /data/' + str(db_name))
					os.system('hdfs dfs -cat /data/' +str(db_name) + '/' + str(tb_name))
					print(first_time)
			except:
				print('File aldready exists in hdfs')
				return 1
		elif query_type == 'DELETE':
			print('DELETE')
			db_name, tb_name = client_query[1].split('/')
		elif query_type == 'SELECT':
			print('SELECT')
		elif query_type == '':
			pass
		else:
			print('Invalid Syntax')
			print('Supported Operations are:')
			print('\tLOAD: Load the database and the table with the schema')
			print('\tDELETE: Delete the database and all the tables within it')
			print('\tSELECT: Select particular columns from the table loaded')
	except:
		print('Invalid Syntax')
		print('Contact Administrator')
	return 0

if __name__ == '__main__':
	print('start')
	try:
		while True:
			main()
	except (IOError, IndexError):
		print('Wrong Input')
	except KeyboardInterrupt:
		print()
	finally:
		print('end')
