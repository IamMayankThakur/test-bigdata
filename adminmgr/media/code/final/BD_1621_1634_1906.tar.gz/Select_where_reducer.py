#!/usr/bin/python3
import sys

for line in sys.stdin:
	
	key,value=line.split(sep="\t")

	values=value.split(sep=",")
	
	for a in values:
		print(a,end="\t")
	print()
