import os


dbtextname='mtcars.csv.txt'

from collections import OrderedDict

#####################
maxflag=1
minflag=2
sumflag=3


#############


fp1=open('/home/hadoop/'+dbtextname,'r')
listcolumn=fp1.readlines()[0]


columndict=OrderedDict()
listcolumn=listcolumn.split(',')

index=0
for i in listcolumn:
	x=i.split(':')
	
	columndict[x[0]]=[x[1],index]
	index+=1
	
#print(columndict)

def execvp(args):
	pid=Popen(args,stdout=PIPE,stderr=PIPE)
	(result,err)=pid.communicate()
	if not err:
		return (err)


for i in range(0,len(query_list)):
	x=query_list[i]
	x.lower()
	query_list[i]=x





fp=open('/home/hadoop/'+dbtextname,'r')




if 'sum' in query_list or 'max' in query_list or 'min' in query_list:
	
	if query_list[1] in columndict and query_list[-1] in columndict:	
		
		flag=-1
			
		if 'sum' in query_list:
			flag=3
		elif 'max' in query_list:
			flag=1
		else:
			flag=2

		colcheck=columndict[query_list[1]]
		if colcheck[0]=='int' or colcheck[0]=='float':
			cond=query_list[-3]
			#print(cond)
			if '=' in cond:
				p=cond.split('=')
				info1=columndict[p[0]]	
				for i in fp:
					x=i.split(',')
					for j in range(0,len(x)):
						temp=x[j]
						temp=temp.strip()
						temp=temp[1:-1]
						x[j]=temp
					if p[1]== x[info1[1]] :

						print(x[info1[1]],flag)
			
						
			
					

			else: #no condition
				info1=columndict[query_list[-1]]
				ccheck=0
				for i in fp:
					x=i.split(',')
					for j in range(0,len(x)):
						temp=x[j]
						temp=temp.strip()
						temp=temp[1:-1]
						x[j]=temp
					if ccheck!=0:
						print(x[info1[1]],flag)
					ccheck+=1
						
					
									
		



	else:
		print("INVALID COLUMN",0)
	
	











else:
	flag=0
	#print("in else")
	if (query_list[1] in columndict or query_list[1]=='*') and 'where' in query_list:	
	
		#print("found")
		cond=query_list[-1]
		
		p=cond.split('=')
	
		
		if query_list[1]=='*':
			info1=columndict[cond[0]]
			for i in fp:
				x=i.split(',')	
				
				for j in range(0,len(x)):
					temp=x[j]
					temp=temp.strip()
					temp=temp[1:-1]
					x[j]=temp
				if(x[info1[1]]==str(p[1])):
					print(x,flag)

		else:
			info1=columndict[cond[0]]
			colcheck=columndict[query_list[1]]
			for i in fp:
				x=i.split(',')	
				
				for j in range(0,len(x)):
					temp=x[j]
					temp=temp.strip()
					temp=temp[1:-1]
					x[j]=temp

				if(x[info1[1]]==str(p[1])):
					print(x[colcheck[1]],flag)
			
						
				
				
		
		
		
		
		
	else:
		
		if query_list[1]=='*':
			dodo=0
			for i in fp:	
				if dodo!=0:
					print(i,0)
				dodo+=1
		else:
			z=query_list[1]
			#print(z,columndict[z])
			
			if z in columndict:
				info=columndict[z]
				dodo=0
				for i in fp:
					x=i.split(',')	

					for j in range(0,len(x)):
						temp=x[j]
						temp=temp.strip()
						temp=temp[1:-1]
						x[j]=temp					

					
					if dodo!=0:
						print(x[info[1]],0)
					dodo+=1

			else:
				print("Invalid column",0)
					
		
						
				
				
			
	

