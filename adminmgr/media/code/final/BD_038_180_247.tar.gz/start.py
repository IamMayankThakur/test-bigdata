#import pydoop.hdfs as hdfs
from collections import OrderedDict
from subprocess import *
import sys
import threading
from threading import Thread
import csv
import os

#result output
#run_cmd execvp
#args_list args
#
global cont
cont=1

def space(x):
	for i in range(0,x):
		print()

def change(t):
	global cont
	if t==1:
		cont=1
	else:
		cont=0



def entry():
	print("select option")
	print("1. Load a new database")
	print("2. Query ")
	space(2)
	

def ask():
	print("Enter Y if u want to continue")
	print("Else enter N")
	x=input()
	x.lower()
	if(x=='y'):
		change(1)
		space(4)
	else:
		change(0)
		
	


	
	
def intro():
	for i in range(0,10):
		print("*",end="")

	print("SQL Engine",end="")


	for i in range(0,10):
		print("*",end="")
	space(3)





def execvp(args):
	pid=Popen(args,stdout=PIPE,stderr=PIPE)
	(result,err)=pid.communicate()
	if not err:
		return (err)




intro()

while(cont):
	entry()
	choice=int(input())
	if choice==1:
		
		

		print("Enter load command")
		command=input().split()
		com=command[1].split('/')
		schema=command[3]   #schema
		dbname=com[0]
		csvname=com[1]

		createdb=['hdfs','dfs','-mkdir']
		dbstring='/'+str(dbname)
		createdb.append(dbstring)
		execvp(createdb)
		print("dir created")

		
		args=['hdfs','dfs','-put','/home/hadoop/bigdata/']
		args.append(csvname)
		s='/'+dbname+'/'
		args.append(s)
		execvp(args)
			
		print("done")


	
		schema=schema[1:-1]
		#schemalist=[]
		#schemalist.append(schema)
		fp=open(str(csvname)+'.txt','w')
		fp.write(schema)
		fp.write("\n")
		with open(csvname,'r') as f:
			data=csv.reader(f)
			for r in data:
				x=str(r)
				x=x[1:-1]
				fp.write(x)
				fp.write("\n")
				

		args_schema = ['hdfs','dfs','-copyFromLocal']
		args_schema.append('/home/hadoop/'+ str(csvname)+'.txt')
		args_schema.append('/'+str(dbname))
		execvp(args_schema)
		print("schema created")

		args1=['hdfs','dfs','-put','/home/hadoop/bigdata/']
		args1.append(str(csvname)+'.txt')
		s1='/'+dbname+'/'
		args1.append(s1)
		execvp(args1)
		
		print("final hadoop")
		
	
		
	
		
				


	elif choice==2:
		print("Enter the database name")
		dbname=input() #bigdata
		#print("Enter table name")
		#csvname=input()
		print("Enter query")
		query=input().split()
		
		with open("/home/hadoop/selectmapper.py") as f:
			lines=f.readlines()
		#print(lines)
		lines[1]='query_list = '+ str(query) + '\n'
		#dbtxtname=str(csvname)+'.txt'
		#lines[2]='dbtextname=' +' +'\n'
		
		with open("/home/hadoop/selectmapper.py",'w') as f:
			f.writelines(lines)
		
				
		#args2=['python3','/home/hadoop/selectmapper.py']
		#execvp(args2)
		os.system('python3 /home/hadoop/selectmapper.py | python3 /home/hadoop/selectreducer.py')


	else:
		print("Wrong Option")
	ask()
		

	
	



	



