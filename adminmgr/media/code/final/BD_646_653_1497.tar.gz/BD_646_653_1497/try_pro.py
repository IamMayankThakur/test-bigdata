import subprocess
import sys
import fileinput
import pydoop.hdfs as hdfs
from collections import OrderedDict
def run_cmd(args_list):
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (output, errors) = proc.communicate()
    if errors:
    	serr = str(errors).split(':')
    return (serr)




print("------------------Welcome to TRP engine-----------------")
print("1.Load the database\n2.Query the database\n\nEnter your option: ")
ch = int(input())

if(ch == 1):
    print('>',end = " ")
    loadst = input().split()
    if loadst[0] == 'LOAD':
        if loadst[1] and loadst[3]:
            arglist = ['hdfs','dfs','-copyFromLocal']
            database_name = loadst[1].split('/')
            create_db = ['hdfs','dfs','-mkdir']
            create_db.append('/'+str(database_name[0]))
            run_cmd(create_db)
            arglist.append('/home/hadoop/'+str(database_name[1])) #table name(bigdata.csv)
            arglist.append('/'+str(database_name[0])+'/') #database name(/project)

            o = run_cmd(arglist)
            #print(o) 

            fp = open(str(database_name[1])+'.txt','w')
            fp.write(loadst[3])
            fp.close()
            arglist_schema = ['hdfs','dfs','-copyFromLocal']
            arglist_schema.append('/home/hadoop/'+ str(database_name[1])+'.txt')
            arglist_schema.append('/'+str(database_name[0]))
            s = run_cmd(arglist_schema)
            if(len(s) <= 4):
                print("Database Loaded successfully !")
            else:
                print("ERROR:Database couldn't be loaded :( ")
            
            
#	
elif ch == 2:
    print("Please Enter Database name : ")
    db_name = input()

    print("Please Enter the query : ")
    qry = input().split()
    read_list = ['hdfs','dfs','-cat']
    read_list.append(qry[3])
    if qry[0] == 'select' and qry[2] == 'from':
        
        d = OrderedDict()
        with open('/home/hadoop/bigdata.csv.txt') as f:
            for line in f:
                l1 = line.split(',')
                for i in l1:
                    (key,val) = i.split(':')
                    d[key] = val
        col=1               
        if( qry[1]!='*' and not qry[1].startswith('SUM') and not qry[1].startswith('AVG') and not qry[1].startswith('COUNT')):
            a = qry[1].split(',') 
            for i in a:
                l = i.split('(')
                if len(l)==1:
                    if (i not in d.keys()):
                        print("Column not found")
                        col=0
                else:
                    print("Cannot apply aggregate function " + l[0])
                    col=0

        if(col):
            with open("/home/hadoop/try_mapper.py") as f:
                lines = f.readlines()
            lines[1] = 'query_list = ' + str(qry) + '\n'
            with open("/home/hadoop/try_mapper.py", "w") as f:
                f.writelines(lines)
            inp = '/' + str(db_name) + '/' + qry[3]
            #print(inp)
        
        
        if qry[1].startswith('SUM'):
            col = qry[1].split('(')[1].split(')')[0]
            l = list(d.keys())
            if col in l:
                if d[col] != 'integer':
                    print('ERROR : Cannot apply aggregate function SUM : Can be applied only to Columns with datatype Integer')
                    exit(0)
                else:
                    sum_flag = 1
                    avg_flag = 0
                    cnt_flag = 0
        
        elif qry[1].startswith('AVG'):
            col = qry[1].split('(')[1].split(')')[0]
            l = list(d.keys())
            if col in l:
                if d[col] != 'integer':
                    print('ERROR : Cannot apply aggregate function AVG : Can be applied only to Columns with datatype Integer')
                    exit(0)
                else:
                    sum_flag = 0
                    avg_flag = 1
                    cnt_flag = 0
                    
        elif qry[1].startswith('COUNT'):
            cnt_flag = 1
            sum_flag = 0
            avg_flag = 0
            
        else:
            sum_flag = 0
            avg_flag = 0
            cnt_flag = 0
        with open("/home/hadoop/try_reduce.py") as f:
            lines = f.readlines()
            lines[1] = 'sum_flag = '+str(sum_flag) + '\n'
            lines[2] = 'avg_flag = '+str(avg_flag) + '\n'
            lines[3] = 'cnt_flag = '+str(cnt_flag) + '\n'
        with open("/home/hadoop/try_reduce.py", "w") as f:
            f.writelines(lines)
            
        cmd = ['hadoop', 'jar', '/home/hadoop/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar'
        , '-file' ,'/home/hadoop/try_mapper.py' ,'-mapper' ,'\"python try_mapper.py\"',
         '-file','/home/hadoop/try_reduce.py','-reducer' ,'\"python try_reduce.py\"', '-output',
          '/outputs/1', '-input']
        cmd.append(inp)
        o= run_cmd(cmd)
        with hdfs.open('/outputs/1/part-00000') as f:
            for line in f:
                print(line.decode('utf-8'))
        
        del_cmd = ['hdfs','dfs','-rm','/outputs/1/*']
        frm = run_cmd(del_cmd)

        del_dir = ['hdfs','dfs','-rmdir','/outputs/1']
        drm = run_cmd(del_dir)







			
						
			




   
