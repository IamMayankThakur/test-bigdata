from __future__ import print_function
query_list = ['select', 'ID', 'from', 'results.csv']
agg_ind = []

sum_agg = 0
import sys
from collections import OrderedDict
def return_index_agg(i,l):
    col = i.split('(')[1].split(')')[0]
    if col in l:
        if l[col] == 'integer':
            agg_ind.append(list(l.keys()).index(col))
        
            
    
def return_index(l1,l2,d):
    f_l = []
    global sum_flag 
    global avg_flag    
    for i in l1.split(','):
        if(i in l2):
            avg_flag = 0
            sum_flag = 0
            cnt_flag = 0
            f_l.append(l2.index(i))
            
        elif i.startswith('SUM'):
            sum_flag = 1
            avg_flag = 0
            cnt_flag = 0
            return_index_agg(i,d)
            
        elif i.startswith('AVG'):
            avg_flag = 1
            sum_flag = 0
            cnt_flag = 0
            return_index_agg(i,d)
        
    return f_l 

d = OrderedDict()
with open('/home/hadoop/results.csv.txt') as f:
    for line in f:
        l1 = line.split(',')
        for i in l1:
            (key,val) = i.split(':')
            d[key] = val
indexes = []

#for where condition
if len(query_list) > 5:
    cond,val = query_list[5].split('=')
    ind_cond = return_index(cond,list(d.keys()),d)

#for select *
if query_list[1] == '*' or (query_list[1].startswith('COUNT') and query_list[1].split('(')[1].split(')')[0]) :
    sum_flag = 0
    avg_flag = 0
    for i in range(len(list(d.keys()))-1):
        indexes.append(i)
else: #for column selection
    
    indexes = return_index(query_list[1],list(d.keys()),d)

r = sys.stdin
for i in r:
    rows = i.split(',')
    str1 = '' 
    #without where condition
    if len(query_list) < 5:
        if sum_flag or avg_flag:
            print((agg_ind,rows[agg_ind[0]]))
        else:
            for j in indexes:
                str1 = str1 + str(rows[j]) + '|'
            if(len(indexes)):
                print((str1[:-1],str1))
            
    
    else:   #with where condition
        if rows[ind_cond[0]] == val:
            if sum_flag or avg_flag:
                print((agg_ind,rows[agg_ind[0]]))
                
            else:
                for j in indexes:
                    str1 = str1 + str(rows[j]) + '|'
                print((str1[:-1],str1))
    
       
    
    
    

