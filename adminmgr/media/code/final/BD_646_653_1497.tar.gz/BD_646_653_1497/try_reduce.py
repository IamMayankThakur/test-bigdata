from __future__ import print_function
sum_flag = 0
avg_flag = 0
cnt_flag = 0
import sys
from ast import literal_eval
sum_agg = 0
cnt = 0
cnt_agg = 0
for i in sys.stdin:
    if sum_flag or avg_flag:
        sum_agg += int(literal_eval(i)[1])
        cnt += 1
    elif cnt_flag:
        cnt_agg += 1
    else:
        print(literal_eval(i)[0])
if sum_flag:
    print(sum_agg)
elif avg_flag:
    print(float(sum_agg) / float(cnt))
elif cnt_flag:
    print(cnt_agg)










