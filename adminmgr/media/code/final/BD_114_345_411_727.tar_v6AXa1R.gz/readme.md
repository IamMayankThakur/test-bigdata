First we need to create a clusters using batting.csv and bowling.csv for batsman and bowler separately
Commands to follow :
	spark-submit k_means_batting.py /<hdfs-path>/batting.csv <no_of_clusters> <no_of_iterations>
	spark-submit k_means_bowling.py /<hdfs-path>/bowling.csv <no_of_clusters> <no_of_iteration>

Second we need to find the player-player and cluster-cluster probabilities using the ipl.csv and centroids_batting.txt and centroids_bowling.txt
Commands to follow :
    #for player-player
	hadoop jar $HADOOP_STREAM -D mapred.map.tasks=1 -mapper $MAP_SCRIPTS/map_player.py -reducer $REDUCE_SCRIPTS/red_player.py -input  <hdfs-path>/ipl.csv -output /player
    #for cluster-cluster
	hadoop jar $HADOOP_STREAM -D mapred.map.tasks=1 -mapper $MAP_SCRIPTS/map_cluster.py -reducer $REDUCE_SCRIPTS/red_cluster.py -input <hdfs-path>/ipl.csv -output /cluster

Finally we need to simulate the new match, while we the batsman ans bowler order for both the innings using clustering and collaborative filtering
Commands to follow :
  #Prediction using clustering
    #Assuming the player-player probability is in /player/part-00000 and cluster-cluster probability is in /cluster/part-00000
    # having the cluster values of both batsman ans bowler in centroids_batting.txt and centroids_bowling.txt
    #batsman and bowler orders are in batsman_order_1.txt, bowler_order_1.txt, batsman_order_2.txt and bowler_order_2.txt for first and second innings respectively
	python3 score_prediction.py

  #Prediction using collaborative filtering
	spark-submit collab_filter.py /<hdfs-path>/ipl.csv
