#!/usr/bin/python

import sys
import random
import subprocess

#file contains the order of batsman_1
fd_bat_1 = open("./batsman_order_1.txt", "r")
lines_bat_1 = fd_bat_1.read()
batsman_1= lines_bat_1.split("\n")

#file contains the order of bowler_1
fd_bowl_1 = open("./Bowler_order_1.txt", "r")
lines_bowl_1 = fd_bowl_1.read()
bowler_1 = lines_bowl_1.split("\n")

#file contains the order of batsman_1

fd_bat_2 = open("batsman_order_1.txt", "r")
lines_bat_2 = fd_bat_2.read()
batsman_2= lines_bat_2.split("\n")
#batsman_2 contains list of batsman_2 in order

#file contains the order of bowler_2
fd_bowl_2 = open("Bowler_order_2.txt", "r")
lines_bowl_2 = fd_bowl_2.read()
bowler_2= lines_bowl_1.split("\n")
#bowler_2 contains list of bowler_1s in order


def swap(a, b):
	return b,a

def cluster_bat(player):
	for i in range(len(lines1_bat)):
		players = lines1_bat[i].split(",")[1:]
		if(player in players):
			return i
	return -1

def cluster_bowl(player):
	for j in range(len(lines1_bowl)):
		players = lines1_bowl[j].split(",")[1:]
		if(player in players):
			return j
	return -11

#operations on HDFS
def run_cmd(args_list):
        #import subprocess
        proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        s_output, s_err = proc.communicate()
        s_return =  proc.returncode
        return s_output.decode('utf-8')

#centroid, list of batsman_1
#cluster_batsman_1 = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bat.csv').split("\n")

#centroid, list of bowler_1
#cluster_bowler_1 = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bowl.csv').split("\n")

#batsman_1^bowler_1, [probabilities of runs 0,1,2,3,4,5,6,out,ball], [cumulative probabilities]
player_player = run_cmd(['hdfs', 'dfs', '-cat', '/player/part-00000']).split("\n")
cluster_cluster = run_cmd(['hdfs', 'dfs', '-cat', '/cluster/part-00000']).split("\n")
f1_bat=open("./centroids_batting.txt","r")
data1_bat=f1_bat.read()
lines1_bat=data1_bat.split('\n')

#cluster_bowler = run_cmd('hdfs', 'dfs', '-cat', '/clusters/cluster_bowl.csv').split("\n")

f1_bowl=open("./centroids_bowling.txt","r")
data1_bowl=f1_bowl.read()
lines1_bowl=data1_bowl.split('\n')

bad_character = ['[', ']']

prob = list()
for i in range(len(batsman_1)):
	prob.append(1)

def compute_out(batman, bowler):
	key = str(batman) + '^' + str(bowler)
	for data in player_player:
		if (key in data):
			data = ''.join(i for i in data if not i in bad_character)
			data = data.split(",")
			return (1 - float(data[8]))

	for data_cluster in cluster_cluster:
		bat_c = cluster_bat(batman)
		bowl_c = int(cluster_bowl(bowler))+10
		key = str(bat_c) + "^" + str(bowl_c)
		if (key in data_cluster):
			data_cluster = ''.join(i for i in data_cluster if not i in bad_character)
			data_cluster = data_cluster.split(",")
			return (1 - float(data_cluster[8]))
	return 1 #random.randint(0, 8)

#gets the runs
def compute_runs(bat, bowl, ran):
	key = str(bat) + '^' + str(bowl)
	#check in the player_player_prob
	for data in player_player:
		if (key in data):
			data = ''.join(i for i in data if not i in bad_character)
			data = data.split(",")
			print("player")
			for i in data[10:-2]:
				if (float(i) >= ran):
					return (data[10:-2].index(i))
	#check in the cluster_cluster_prob
	#print(key)
	for data_cluster in cluster_cluster:
		bat_c = cluster_bat(bat)
		bowl_c = int(cluster_bowl(bowl))+10
		key = str(bat_c) + "^" + str(bowl_c)
		if (key in data_cluster):
			data_cluster = ''.join(i for i in data_cluster if not i in bad_character)
			data_cluster = data_cluster.split(",")
			print("cluster")
			for j in data_cluster[10:-2]:
				if (float(j) >= ran):
					return (data_cluster[10:-2].index(j))
	print("jjjj")
	#print(key)
	return 0 #random.randint(0, 8)

overs=0
runs=0
wickets=0
balls=0
b1=0
b2=1
s=batsman_1[b1]
ns=batsman_1[b2]
bw=0
bname=bowler_1[bw]

prob[b1] = compute_out(s, bname)
prob[b2] = compute_out(ns, bname)
#print("INTIAL,,,,,,,,,,,,,,,", prob)
while(overs < 20 and wickets < 10):
	ran_num=random.uniform(0,1)
	curr_run=compute_runs(s,bname,ran_num)
	print("run this ball",curr_run)
	#print("bbbbbb", b1, b2)
	prob[b1] = prob[b1] * compute_out(s, bname)
	#print("p111111111", prob)

	if(prob[b1] < 0.5):
		temp = batsman_1.index(s)
		'''
		if(temp != b1):
			b2 = max(b1, b2) + 1
			s = batsman_1[b2]
		else:
			b1 = max(b1, b2) + 1
			s = batsman_1[b1]
		'''
		print("Outttttt Bats", b1)
		b1 = max(b1, b2) + 1
		s = batsman_1[b1]
		wickets=wickets+1
		#prob.append(compute_out(s, bname))
		#print("New Prob", prob)
	else:
		runs=runs+curr_run
	if (balls == 5 and curr_run % 2 == 1):
		s, ns = swap(s,ns)
		b1, b2 = swap(b1, b2)
		#p1, p2 = swap(p1, p2)
	elif(curr_run%2 ==1 ):
		s,ns=swap(s,ns)
		b1, b2 = swap(b1, b2)
		#p1, p2 = swap(p1, p2)

	balls=balls+1
	if(balls==6):
		overs=overs+1
		balls=0
		bw=bw+1
		if(bw > 19):
		 	break
		bname=bowler_1[bw]

first_innings_run=runs
first_innings_wickets=wickets

print("first innings runs ",first_innings_run)
print("first innings wickets",first_innings_wickets)

overs=0
runs=0
wickets=0
balls=0
b1=0
b2=1
s=batsman_2[b1]
ns=batsman_2[b2]
bw=0
bname=bowler_2[bw]
prob = list()

for i in range(len(batsman_2)):
	prob.append(1)

prob[b1] = compute_out(s, bname)
prob[b2] = compute_out(ns, bname)

while(overs <20 and wickets<10):
	ran_num=random.uniform(0,1)

	curr_run=compute_runs(s,bname,ran_num)
	print("run this ball", curr_run)
	prob[b2] = prob[b1] * compute_out(s, bname)
	if(prob[b1] < 0.5):
		temp = batsman_2.index(s)
		'''
		if (temp != b1):
			b2 = max(b1, b2) + 1
		else:
			b1 = max(b1, b2) + 1
		'''
		print("outttt bats", b1)
		b1 = max(b1, b2) + 1
		s = batsman_2[b1]
		wickets=wickets+1
	else:
		runs=runs+curr_run
		if (runs > first_innings_run):
			break

	if (balls == 5 and curr_run % 2 == 1):
		s,ns=swap(s,ns)
		b1, b2 = swap(b1, b2)
	elif(curr_run%2 ==1 ):
		s,ns=swap(s,ns)
		b1, b2 = swap(b1, b2)
	balls=balls+1

	if(balls==6):
		overs=overs+1
		balls=0
		bw=bw+1
		if(bw>19):
			break
		bname=bowler_2[bw]


second_innings_runs = runs
second_innings_wickets = wickets

print("first_innings_runs", first_innings_run)
print("first_innings_wickets", first_innings_wickets)

print("second_innings_runs", second_innings_runs)
print("second_innings_wickets", second_innings_wickets)
# one team can have one order of batting and another team can have another order
# so i think we need to have 4 different files
