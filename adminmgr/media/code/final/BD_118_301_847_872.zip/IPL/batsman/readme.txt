1. Randomly initialize clusters.csv
2. clustering_map.py - assigns cluster id to each player -euclidian dis
3. clustering_reducer.py - computes new centroids for each cluster
4. check_conv.py - checks if old cluster centroids(present in clusters.csv) ~ new cluster centroids(present in reducer_out.csv)
	if yes - return 0
	else - return 1

5. sample.sh - runs a while loop (map, reduce, check_conv) until check_conv returns 0

6. mapper_out - contains player with cluster ID assigned to them
