#!/usr/bin/python3
import csv
import sys
import math
# seed the pseudorandom number generator
from random import seed
from random import random
# seed random number generator
#seed(1)
results={}
cluster_list=[1,2,3,4,5,6,7,8,9,10]
#reducer_in= open("mapper_out.csv",'r')
with open('mapper_out.csv') as csv_file:
	csv_reader = csv.reader(csv_file, delimiter=',')
	for info in csv_reader:
		#print(line_det)
	#line = line.strip()
	#info = line.split(":")
		cluster_id=int(info[0])
		cluster_center_x=info[1]
		cluster_center_y=info[2]
		#points=info[1].split(",")
		x,y=float(info[3]),float(info[4])
		cluster_center = cluster_id
		if cluster_center in results:
				results[cluster_center]["x"]+=x
				results[cluster_center]["y"]+=y
				results[cluster_center]["n"]+=1

		else:
				#print(info[0])
				new=cluster_center
				#print(new)
				#cx,cy=float(new[0]),float(new[1])
				cx, cy = float(cluster_center_x),float(cluster_center_y)
				#print (cx,cy)

				results[cluster_center]={"x":cx,"y":cy,"n":1}
				results[cluster_center]["x"]+=x
				results[cluster_center]["y"]+=y
				results[cluster_center]["n"]+=1
			#print(results)
#print(results)
reducer_out = open("reducer_out.csv",'w')
for r in results:
	if(r in cluster_list):
		cluster_list.remove(r)
#print("final ",cluster_list)
for c in cluster_list:
	#print(c)
	results[c]={"x":(random()*10), "y":(random()*100), "n":1}
#print(results)

for r in results:
#	print(results[r])
	#print(r)
	new_x=float(float(results[r]["x"])/float(results[r]["n"]))
	new_y=float(float(results[r]["y"])/float(results[r]["n"]))
	print(r,new_x,new_y)
	reducer_out.write(str(r)+","+str(new_x)+","+str(new_y)+"\n")


reducer_out.close()
