#!/bin/sh 
CONVERGE=1
while [ "$CONVERGE" -ne 0 ]
do
	python clustering_map.py
	python clustering_reducer.py
	#((CONVERGE=CONVERGE-1))
	#CONVERGE=$((CONVERGE-1))
	CONVERGE=$(python check_conv.py >&1)
	echo $CONVERGE

	#CONVERGE = $(python check_conv.py)
	#echo $CONVERGE
done