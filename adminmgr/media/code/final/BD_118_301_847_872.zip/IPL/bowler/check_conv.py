#red_out=open("reducer_out.csv","r")
#og_clust=open("clusters.csv","r")
import shutil
import os
count=0
n=0
def replace_clusters():
	os.remove("/home/anagha/Documents/Sem_5/BD/Project/trial/bowler/clusters.csv")

	source = "/home/anagha/Documents/Sem_5/BD/Project/trial/bowler/reducer_out.csv"
	destination = "/home/anagha/Documents/Sem_5/BD/Project/trial/bowler/clusters.csv"
	dest = shutil.copyfile(source, destination) 



  
with open("reducer_out.csv") as file1, open("clusters.csv") as file2:
	for line1, line2 in zip(file1, file2):
		count+=1
		x=float(line1.split(",")[1])
		y=float(line1.split(",")[2])
		cx=float(line2.split(",")[1])
		cy=float(line2.split(",")[2])
		#print(x,y,cx,cy)
		if(abs(cx-x) < 0.1 and abs(cy-y) < 0.1):
			n+=1

	if(n==count):
		print(0)
	else:
		replace_clusters()
		print(1)

    	#print(line2.split(",")[1])
	
