#!/usr/bin/python3
import csv
import sys
import math
cluster_centres=[]
with open('clusters.csv', 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for line in csv_reader:
        cid = int(line[0])
        cx = float(line[1])
        cy = float(line[2])
        t = (cid,cx,cy)
        cluster_centres.append(t)
print(cluster_centres)

def euclidean(cx,cy,x,y):
    #distance = 0
    
    distance =(cx - float(x))*(cx-float(x))+(cy - float(y))*(cy-float(y))
    return math.sqrt(distance)

def find_nearest_cluster(x,y):
    closest=1000000000000
    for cluster in cluster_centres:
        dist=euclidean(cluster[1],cluster[2],x,y)
        if (dist<closest):
            closest=dist
            #closest_clust=cluster[0]
            closest_clust=(cluster[0],cluster[1],cluster[2])
    return closest_clust
count=0
#for line in sys.stdin:
#with open('mapper_out.csv', mode ='w') as mapper_out:
mapper_out = open("mapper_out.csv",'w')
    #
    #csv_writer= csv.writer(mapper_out, delimiter =',')
with open('bowling.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for line_det in csv_reader:
        count = count+1
        if(count==1):
            continue
        #print(line)
        #line = line.strip()
        #line_det=line.split(",")
        x,y=line_det[7],line_det[10]
        player_name=line_det[0]
    # x = wickets
    # y = economy
  
        
        cluster_id= find_nearest_cluster(x, y)
        #x_y = (x,y)
        #print(cluster_id[0],cluster_id[1],cluster_id[2],x,y)
        mapper_out.write(str(cluster_id[0])+","+str(cluster_id[1])+","+str(cluster_id[2])+","+str(x)+","+str(y)+","+str(player_name)+"\n")
        #csv_writer.writerow([cluster_id[0],cluster_id[1],cluster_id[2],x,y]) 
        #print("%s,%s:%s,%s"%(cluster_id[0],cluster_id[1],x,y))
        #print(player_name,cluster_id)
mapper_out.close()





