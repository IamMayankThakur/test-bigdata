"""
Collaborative Filtering Classification Example.
"""
from __future__ import print_function

from pyspark import SparkContext
import pprint
import csv
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating
#from pyspark.ml.recommendation import ALS, ALSModel
#Rating = inbuilt class which takes "user,product,rating"


if __name__ == "__main__":
    sc = SparkContext(appName="PythonCollaborativeFilteringExample")

    # Load and parse the data
    data = sc.textFile("/home/anagha/Desktop/replaced_by_id.data")
    test_data = sc.textFile("/home/anagha/PROJECT/test_final.data")
    testdata1 = test_data.map(lambda l: l.split(','))
    #print(testdata1.collect())
    split_data = data.map(lambda l: l.split(','))
    '''ratings = data.map(lambda l: l.split(','))\
        .map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))'''
    #ratings is an RDD!
    ratings1 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))
    ratings2 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[3])))
    ratings3 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[4])))
    ratings4 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[5])))
    ratings5 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[6])))
    ratings6 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[7])))
    ratings7 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[8])))
    ratings8 = split_data.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[9])))
    #print(ratings1.collect())



    # Build the recommendation model using Alternating Least Squares
    #(training1,test1) =  ratings1.randomSplit([0.8,0.2])
    '''(training2,test2) =  ratings2.randomSplit([0.8,0.2])
    (training3,test3) =  ratings3.randomSplit([0.8,0.2])
    (training4,test4) =  ratings4.randomSplit([0.8,0.2])
    (training5,test5) =  ratings5.randomSplit([0.8,0.2])
    (training6,test6) =  ratings6.randomSplit([0.8,0.2])
    (training7,test7) =  ratings7.randomSplit([0.8,0.2])
    (training8,test8) =  ratings8.randomSplit([0.8,0.2])'''
    #(training9,test9) =  ratings9.randomSplit([0.8,0.2])
    rank = 10
    numIterations = 10
    '''als = ALS(rank=10, maxIter=2, regParam=0.01, userCol="Batsman", itemCol="Bowler", ratingCol="prob_0",
          coldStartStrategy="drop",
          implicitPrefs=False)
    model = als.fit(training)'''
    model1 = ALS.train(ratings1, rank, numIterations)
    model2 = ALS.train(ratings2, rank, numIterations)
    model3 = ALS.train(ratings3, rank, numIterations)
    model4 = ALS.train(ratings4, rank, numIterations)
    model5 = ALS.train(ratings5, rank, numIterations)
    model6 = ALS.train(ratings6, rank, numIterations)
    model7 = ALS.train(ratings7, rank, numIterations)
    model8 = ALS.train(ratings8, rank, numIterations)
    #model9 = ALS.train(training9, rank, numIterations)
    #als = ALS(training,rank,numIterations)
    #model = als.fit(training)

    # Evaluate the model on training data
    #testdata1 = test1.map(lambda p: (p[0], p[1]))
    '''testdata2 = test2.map(lambda p: (p[0], p[1]))
    testdata3 = test3.map(lambda p: (p[0], p[1]))
    testdata4 = test4.map(lambda p: (p[0], p[1]))
    testdata5 = test5.map(lambda p: (p[0], p[1]))
    testdata6 = test6.map(lambda p: (p[0], p[1]))
    testdata7 = test7.map(lambda p: (p[0], p[1]))
    testdata8 = test8.map(lambda p: (p[0], p[1]))
    #testdata9 = test9.map(lambda p: (p[0], p[1]))'''

    #print(testdata1.collect())


    
    predictions1 = model1.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions2 = model2.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions3 = model3.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions4 = model4.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions5 = model5.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions6 = model6.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions7 = model7.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    predictions8 = model8.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))

    #joinedRDD = (predictions1.join(predictions2)).join(predictions3)
    #print(joinedRDD.collect())
    with open("result.csv", "w") as csv_file:
        writer = csv.writer(csv_file, delimiter = ',')
        for i,j,k,l,m,n,o,p in zip(predictions1.collect(),predictions2.collect(),predictions3.collect(),predictions4.collect(),predictions5.collect(),predictions6.collect(),predictions7.collect(),predictions8.collect()):
           #print(i[0][0],i[0][1],max(0,i[1]),max(0,j[1]),max(0,k[1]),max(0,l[1]),max(0,m[1]),max(0,n[1]),max(0,o[1]),max(0,p[1]))
           writer.writerow([i[0][0],i[0][1],max(0,i[1]),max(0,j[1]),max(0,k[1]),max(0,l[1]),max(0,m[1]),max(0,n[1]),max(0,o[1]),max(0,p[1])])
        
    '''ratesAndPreds1 = ratings1.map(lambda r: ((r[0], r[1]), r[2])).join(predictions1)
    ratesAndPreds2 = ratings2.map(lambda r: ((r[0], r[1]), r[2])).join(predictions2)
    ratesAndPreds3 = ratings3.map(lambda r: ((r[0], r[1]), r[2])).join(predictions3)
    ratesAndPreds4 = ratings4.map(lambda r: ((r[0], r[1]), r[2])).join(predictions4)
    ratesAndPreds5 = ratings5.map(lambda r: ((r[0], r[1]), r[2])).join(predictions5)
    ratesAndPreds6 = ratings6.map(lambda r: ((r[0], r[1]), r[2])).join(predictions6)
    ratesAndPreds7 = ratings7.map(lambda r: ((r[0], r[1]), r[2])).join(predictions7)
    ratesAndPreds8 = ratings8.map(lambda r: ((r[0], r[1]), r[2])).join(predictions8)'''
    #print(ratesAndPreds1.collect())
    #MSE = ratesAndPreds1.map(lambda r: (r[1][0] - r[1][1])**2).mean()

    #print("Mean Squared Error = " + str(MSE))
    #print(predictions1.collect())
    

    # Save and load model
    #model.save(sc, "tmp/myCollaborativeFilter")
    #sameModel = MatrixFactorizationModel.load(sc, "tmp/myCollaborativeFilter")
    # $example off$
