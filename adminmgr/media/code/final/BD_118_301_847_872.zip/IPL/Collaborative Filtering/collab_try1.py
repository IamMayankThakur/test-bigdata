import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import findspark
import os
import gc
import pyspark.sql.functions as sql_func
from pyspark.sql.types import *
from pyspark.ml.recommendation import ALS, ALSModel
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.mllib.evaluation import RegressionMetrics, RankingMetrics
from pyspark.ml.evaluation import RegressionEvaluator

sc = SparkContext('local') #https://stackoverflow.com/questions/30763951/spark-context-sc-not-defined
spark = SparkSession(sc)


df = pd.read_csv('prob_playervplayer.csv')
data_schema = StructType([
    StructField('Batsman',IntegerType(), False),
    StructField('Bowler',IntegerType(), False),
    StructField('prob_0',FloatType(), False),
    StructField('prob_1',FloatType(), False),
    StructField('prob_2',FloatType(), False),
    StructField('prob_3',FloatType(), False),
    StructField('prob_4',FloatType(), False),
    StructField('prob_5',FloatType(), False),
    StructField('prob_6',FloatType(), False),
    StructField('prob_wicket',FloatType(), False),
    StructField('TotBalls',IntegerType(), False)
])
final_stat = spark.read.csv(
    'prob_playervplayer.csv', header=True, schema=data_schema
).cache()


ratings = (final_stat
    .select(
        'Batsman',
        'Bowler',
        'prob_0',
    )
).cache()
(training, test) = ratings.randomSplit([0.8, 0.2])

als = ALS(rank=10,
          maxIter=2, regParam=0.01,
          userCol="Batsman", itemCol="Bowler", ratingCol="prob_0",
          coldStartStrategy="drop",
          implicitPrefs=False)
model = als.fit(training)

# Evaluate the model by computing the RMSE on the test data
predictions = model.transform(test)
evaluator = RegressionEvaluator(metricName="rmse", labelCol="prob_0",
                                predictionCol="prediction")

rmse = evaluator.evaluate(predictions)
print("Root-mean-square error = " + str(rmse))

























