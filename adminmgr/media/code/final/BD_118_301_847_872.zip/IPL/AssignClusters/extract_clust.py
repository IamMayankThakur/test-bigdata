
bats_clust=open("clust.csv","w")
with open("/home/anagha/Documents/Sem_5/BD/Project/trial/batsman/mapper_out.csv","r") as file1, open("/home/anagha/Documents/Sem_5/BD/Project/trial/bowler/mapper_out.csv","r") as file2:
	for line1,line2 in zip(file1,file2):
		player=line1.split(',')[5].strip()
		bat_cid=line1.split(',')[0]
		bowl_cid=line2.split(',')[0]
		bats_clust.write(str(player)+","+str(bat_cid)+","+str(bowl_cid)+"\n")
		#print(player)

#clust.csv has player name, corr batsman cluster, corr bowler cluster