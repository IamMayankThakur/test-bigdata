#!/usr/bin/python3
import csv
from operator import itemgetter
import sys
import pprint

results = dict()
for line in sys.stdin:
    line = line.strip()
    info = line.split(":")
    #deliv = info[1]
    pair = info[0].split(",")
    key_pair= (pair[0],pair[1])
    info_new=info[1].split(",")
    runs = int(info_new[0]) 
    wicket=info_new[1]
    
    if key_pair in results:

        results[key_pair]["no_of_delivs"]+= 1
        if(runs==0):
            results[key_pair]["0"]+=1

        elif(runs==1):

                results[key_pair]["1"]+=1
        elif(runs==2):
                results[key_pair]["2"]+=1
        elif(runs==3):

                results[key_pair]["3"]+=1
        elif(runs==4):
                results[key_pair]["4"]+=1
        elif(runs==5):

                results[key_pair]["5"]+=1
        elif(runs==6):
                results[key_pair]["6"]+=1
        if(wicket!="xyz"):
            results[key_pair]["wickets"]+=1
        


    else:
        results[key_pair]={"no_of_delivs":1,"0":0,"1": 0, "2":0, "3":0,"4":0, "5":0, "6":0,"wickets":0}
        if(runs==0):
            results[key_pair]["0"]+=1
        elif(runs==1):

                results[key_pair]["1"]+=1
        elif(runs==2):
                results[key_pair]["2"]+=1
        elif(runs==3):

                results[key_pair]["3"]+=1
        elif(runs==4):
                results[key_pair]["4"]+=1
        elif(runs==5):

                results[key_pair]["5"]+=1
        elif(runs==6):
                results[key_pair]["6"]+=1
        if(wicket!="xyz"):
            results[key_pair]["wickets"]+=1



for key in list(results):
    if results[key]["no_of_delivs"] <= 5:
        del results[key]
#open=('rand.csv', mode='w') as rand:
with open('prob_playervplayer.csv', mode='w') as employee_file:
        employee_writer = csv.writer(employee_file, delimiter=',')
        
#print(results[('WP Saha', 'KH Pandya')])   
#sorted_result = sorted(sorted(sorted(results.items()), key = lambda x: x[1]["no_of_delivs"]), key = lambda x: x[1]["no_of_runs"], reverse = True)
#results=sorted(results.items(), key = lambda x : x[1])
        for pairs in results:
                balls=results[pairs]["no_of_delivs"]
                prob0=float(results[pairs]["0"]/balls)
                prob1=float(results[pairs]["1"]/balls)
                prob2=float(results[pairs]["2"]/balls)
                prob3=float(results[pairs]["3"]/balls)
                prob4=float(results[pairs]["4"]/balls)
                prob5=float(results[pairs]["5"]/balls)
                prob6=float(results[pairs]["6"]/balls)
                prob_w=float(results[pairs]["wickets"]/balls)
                #prob1=float(results[pairs]["0"]/balls)
                
    
                employee_writer.writerow([str(pairs[0]),str(pairs[1]),prob0,prob1,prob2,prob3,prob4,prob5,prob6,prob_w,balls])
                #print(results[pairs])
        #print("\n")
                #employee_writer.writerow([str(pairs[0]),str(pairs[1]),str(results[pairs]["no_of_delivs"]),str(results[pairs]["0"]),str(results[pairs]["1"]),str(results[pairs]["2"]),str(results[pairs]["3"]),str(results[pairs]["4"]),str(results[pairs]["5"]),str(results[pairs]["6"])])
                #print('%s,%s,%s,%s,%s,%s,%s,%s,%s,%s' %(str(pairs[0]),str(pairs[1]),str(results[pairs]["no_of_delivs"]),str(results[pairs]["0"]),str(results[pairs]["1"]),str(results[pairs]["2"]),str(results[pairs]["3"]),str(results[pairs]["4"]),str(results[pairs]["5"]),str(results[pairs]["6"])))
