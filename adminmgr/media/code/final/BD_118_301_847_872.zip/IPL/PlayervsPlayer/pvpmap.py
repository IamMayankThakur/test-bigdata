#!/usr/bin/python3
import csv
from operator import itemgetter
import sys
import pprint


pairs=dict()
for line in sys.stdin:
	line = line.strip()
	line_det = line.split(',')
	if(line_det[3]==""):
		line_det[3]="xyz"
		
	pair_info=line_det[0] + ','+line_det[1]
	print('%s:%s,%s' % (pair_info,line_det[2],line_det[3])) 
	#if(line_det[0] == 'ball'):
	#	pair_info = line_det[6]+','+line_det[4]+','+str(int(line_det[7])+int(line_det[8]))
	#	print('%s:%s' % (pair_info,'1')) 