import sys
import os
from colored import fg, bg, attr
color = fg('red')
reset = attr('reset')
create_query=os.system("hdfs dfs -cat /query_database2/file2.txt > file2.txt")
fd1=open("file2.txt",'r')
create_query=fd1.read()
print(create_query)
fd2=open("file3.txt",'r')
query_select=fd2.read()

attribute_list=[]
line_temp=create_query.split(" ")
if(line_temp[0]=="CREATE" and line_temp[1]=="TABLE"):
	for i in range(3,len(line_temp)):
		attribute_list.append(line_temp[i].strip("\n"))
#print(attribute_list)
flag_select=0
flag_agg=0

line_temp_1=query_select.split(" ")
if(len(line_temp_1)==4 and line_temp_1[1]!='*'):
	flag_select=1
	k=line_temp_1[1]
	flag_k_1=0
	for i in range(0,len(attribute_list)):
		if(attribute_list[i] == k):
			index1=i
			flag_k_1=1
	if(flag_k_1==0):
		print(color +"ERROR 105:ATTRIBUTE DOES NOT EXIST"+reset)
		sys.exit()

if(flag_select==0 and len(line_temp_1)==8):
	if(line_temp_1[0]=="SELECT" and line_temp_1[2]=="FROM" and line_temp_1[4]=="WHERE"):
		select=line_temp_1[1]	# select column
		where=line_temp_1[5]	
		symbol=line_temp_1[6]
		condition=line_temp_1[-1]
	flag_k_2=0
	for i in range(0,len(attribute_list)):
		if(attribute_list[i] == select):
			index1=i
			flag_k_2=1
	if(flag_k_2==0):
		print(color +"ERROR 105:ATTRIBUTE DOES NOT EXIST"+reset)
		sys.exit()
	
if(flag_select==0 and len(line_temp_1)==10):
	if(line_temp_1[0]=="SELECT" and line_temp_1[2]=="FROM" and line_temp_1[4]=="WHERE"):
		select=line_temp_1[1]	# select column
		where=line_temp_1[5]	
		symbol=line_temp_1[6]
		condition=line_temp_1[7]
	flag_k_3=0
	for i in range(0,len(attribute_list)):
		if(attribute_list[i] == select):
			index1=i
			flag_k_3=1
	if(flag_k_3==0):
		print(color +"ERROR 105:ATTRIBUTE DOES NOT EXIST"+reset)	
		sys.exit()
	flag_agg=1
	#aggr=line_temp_1[9].strip("\n")
	a=line_temp_1[9].split("\n")
	aggr=a[0]

for line in sys.stdin:
	line=line.split(" ")
	print(line_temp_1)
	if(flag_select==0 and len(line_temp_1)==8 and flag_agg==0):
		flag_k_4=0
		for i in range(0,len(attribute_list)):
			if(attribute_list[i] == where):
				index=i
				flag_k_4=1
		if(flag_k_4==0):
			print(color +"ERROR 105:ATTRIBUTE DOES NOT EXIST"+reset)	
			sys.exit()	
		elif(symbol=="="):
			if(int(line[index])==int(condition)):	
				print(int(line[index1]))	
		
		elif(symbol=="<"):
			if(int(line[index]) < int(condition)):	
				print(int(line[index1]))	
		elif(symbol==">"):
			if(int(line[index]) > int(condition)):	
				print(int(line[index1]))
	
	elif(flag_select==1 and flag_agg==0):
		print(int(line[index1]))

	elif(flag_agg==1):
		flag_k_5=0
		for i in range(0,len(attribute_list)):
			if(attribute_list[i] == where):
				index=i
				flag_k_5=1
		if(flag_k_5==0):
			print(color +"ERROR 105:ATTRIBUTE DOES NOT EXIST"+reset)	
			sys.exit()	
		if(symbol=="="):
			if(int(line[index])==int(condition)):	
				print(int(line[index1]),aggr)
		elif(symbol=="<"):
			if(int(line[index]) < int(condition)):	
				print(int(line[index1]),aggr)	
		elif(symbol==">"):
	#		print(line[index] ,int(condition))
			if(int(line[index]) > int(condition)):	
				print(int(line[index1]),aggr)
	else:
		print(line)

