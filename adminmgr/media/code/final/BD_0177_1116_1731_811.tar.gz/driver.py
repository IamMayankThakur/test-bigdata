import os
import time
from colored import fg, bg, attr
color = fg('red')
color1 = fg('#90EE90')
reset = attr('reset')
flag_dataabase=0
os.system("hdfs dfs -mkdir -p /query_database2")
while(flag_dataabase==0):
	database=input(color1+"MiniHIVE $"+reset)
	database=database.split(" ")
	if(len(database)==3):
		if(database[0]=='CREATE' and database[1]=='DATABASE'):
			a=database[2]
			os.system("hdfs dfs -mkdir /query_database2/"+a)
			flag_dataabase=1
		else:
			print(color+"ERROR 101: CREATE DATABASE FIRST OR USE SHOW DATABASE "+reset)
	elif(len(database)==2):
		if(database[0]=='SHOW' and database[1]=='DATABASE'):
			os.system("hdfs dfs -ls /query_database2/")
			flag_dataabase=1
		else:
			print(color +"ERROR 101: CREATE DATABASE FIRST OR USE SHOW DATABASE"+reset)	
	else:
		print(color+"ERROR 101: CREATE DATABASE FIRST OR USE SHOW DATABASE"+reset)



flag_use=0
while(flag_use==0):
	use_query=input(color1+"MiniHIVE $"+reset)
	use_query=use_query.split(" ")
	if(len(use_query)==2 and use_query[0]=='USE'):
		store=use_query[1]
		print("OK")
		flag_use=1
	else:
		print(color+"ERROR 102:DATABASE NOT SELECTED"+reset)



create_query_flag=0
while(create_query_flag==0):
	create_query=input(color1+"MiniHIVE $"+reset)
	create=create_query.split(" ")
	if(create[0]=="CREATE" and create[1]=="TABLE"):
		os.system("echo "+create_query+" > file2.txt")
		os.system("hdfs dfs -put file2.txt /query_database2/")
		os.remove("file2.txt")
		create_query_flag=1
		table_name=create[2]
	else:
		print(color+"ERROR 103:TABLE SCHEMA NOT DEFINED"+reset)



load_query_flag=0
while(load_query_flag==0):
	load_query=input(color1+"MiniHIVE $"+reset)
	load_query=load_query.split(" ")
	if(load_query[0]=="LOAD" and load_query[1]=="DATA" and load_query[2]=="INPATH"):
		store1=load_query[3]
		os.system("hdfs dfs -put "+store1+ " /query_database2/"+store)
		load_query_flag=1
	else:
		print(color+"ERROR 104:LOAD DATA ERROR"+reset)
		

flag=1
flag_h=0
k=0
while(flag==1):	
	flag_k=0
	inter_query=input(color1+"MiniHIVE $"+reset)
	if(inter_query=="DROP "+store):
		os.system("hdfs dfs -rm -r /query_database2/"+store)
		exit()
	elif(inter_query=="SHOW "+ table_name):
		#os.system("hdfs dfs -cat /query_database2/file2.txt ")
		#print(create_query)
		create_query_Y=create_query.split(" ")
		for i in range(3,len(create_query_Y)):
			print(create_query_Y[i], sep=" ", end=" ")
		time.sleep(1)
		flag_h=1
		print()
		while(flag_h==0):
			k=k+1
		os.system("hdfs dfs -cat /query_database2/"+store+"/"+store1)
	elif(inter_query=='exit()'):
		flag=0	
		exit()

	t_split=inter_query.split(" ")
	if(len(t_split)>3):
		if(t_split[3]!=table_name):
			print(color+"ERROR 106:TABLE NAME ERROR"+reset)
			flag_k=1
		
		elif(flag_k==0):
			inter_query=inter_query.replace("<","'<'")
			inter_query=inter_query.replace(">","'>'")
			os.system("echo "+inter_query+" > file3.txt")
#		os.system("hdfs dfs -put file3.txt /query_database2/")

			os.system("hadoop jar Apache/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -file mapper1.py -mapper 'python mapper1.py' -file reducer1.py -reducer 'python reducer1.py' -input /query_database2/"+store+"/"+store1 +" -output q2")

			os.system("hdfs dfs -cat q2/part-00000")
			os.system("hdfs dfs -rm -r q2")
			
os.system("hdfs dfs -rm -r /query_database2/"+store+"/"+store1)
os.system("hdfs dfs -rm /query_database2/file3.txt")
os.system("hdfs dfs -rm /query_database2/file2.txt")
