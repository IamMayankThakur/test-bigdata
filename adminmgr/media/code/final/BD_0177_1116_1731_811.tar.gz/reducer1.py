import sys
#from operator import itemgetter
# using a dictionary to map words to their counts
current_word = None
current_count = 0
word = None
count=0
count_flg=0
min_flg=0
max_flg=0
min_value=None
max_value=None
# input comes from STDIN
for line in sys.stdin:
	if("ERROR"in line):
		print(line)
		sys.exit()

	line=line.split(" ")
	if(len(line)>1):
		line[1]=line[1].strip()
		if(line[1]=="COUNT"):
			count=count+1
			count_flg=1
		if(line[1]=="MIN"):
			if(min_value==None):
				min_value=line[0]
			elif(line[0]<min_value):
				min_value=line[0]
			min_flg=1
	
		if(line[1]=="MAX"):
			if(max_value==None):
				max_value=line[0]
			elif(line[0]>max_value):
				max_value=line[0]
			max_flg=1
	else:
		print(line[0])
if(count_flg==1):
	print(count)
if(min_flg==1):
	print(min_value)
if(max_flg==1):
		
	print(max_value)
	
