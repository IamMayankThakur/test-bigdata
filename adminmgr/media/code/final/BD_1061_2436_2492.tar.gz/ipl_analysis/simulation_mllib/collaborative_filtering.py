from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.sql import Row
from pyspark.sql import SparkSession
import pandas as pd

clust_to_clust=pd.read_csv("group_vs_group_statistics/clust_to_clust.csv")
clust_to_clust.to_csv('simulation_mllib/filtered_cluster_data.csv',header=False,index=False)
spark = SparkSession.builder.appName('pandasToSparkDF').getOrCreate()
lines = spark.read.text("simulation_mllib/filtered_cluster_data.csv").rdd
#lines = spark.read.text("D:/Learnings/IPLANALYSIS/dataset/ratings.csv").rdd

for i in range(2,9):
    new_column=[]
    parts = lines.map(lambda row: row.value.split(","))
    ratingsRDD = parts.map(lambda p: Row(bat=int(p[0]), bowl=int(p[1]),zeroRun=float(p[i])))
    ratings = spark.createDataFrame(ratingsRDD)
    (training, test) = ratings.randomSplit([0.8, 0.2])

    # Build the recommendation model using ALS on the training data
    # Note we set cold start strategy to 'drop' to ensure we don't get NaN evaluation metrics
    als = ALS(maxIter=5, regParam=0.01, userCol="bat", itemCol="bowl", ratingCol="zeroRun",
              coldStartStrategy="drop")
    model = als.fit(training)
    #best_model = model.bestModel
    # Evaluate the model by computing the RMSE on the test data
    predictions = model.transform(test)
    #print(predictions)
    evaluator = RegressionEvaluator(metricName="rmse", labelCol="zeroRun",
                                    predictionCol="prediction")
    rmse = evaluator.evaluate(predictions)
    print("Root-mean-square error = " + str(rmse))

    # Generate top 10 movie recommendations for each user
    userRecs = model.recommendForAllUsers(10)
    print("____________________________________Recommendation for All Users____________________________________")
    print(userRecs.show(10))
    #userRecs.to_csv("D:/Learnings/IPLANALYSIS/dataset/one.csv")
    # Generate top 10 user recommendations for each movie
    movieRecs = model.recommendForAllItems(10)
    print("____________________________________Recommendation for All Items____________________________________")
    print(movieRecs.show(10))
    #data=[row.recommendations for row in movieRecs.collect()]
    #pdf = movieRecs.select("*").toPandas()
    #print(pdf)
    #print(pdf.head)

    # Generate top 10 movie recommendations for a specified set of users
    users = ratings.select(als.getUserCol()).distinct().limit(3)
    userSubsetRecs = model.recommendForUserSubset(users, 10)
    #print(userSubsetRecs.collect(10))
    # Generate top 10 user recommendations for a specified set of movies
    movies = ratings.select(als.getItemCol()).distinct().limit(3)
    movieSubSetRecs = model.recommendForItemSubset(movies, 10)
    #print(movieSubSetRecs.collect(10))
import random
import csv
import pandas as pd

batsmen_cluster = dict()
bowler_cluster = dict()
ipl_team_1 = []
ipl_team_2 = []

pp_data = pd.read_csv('group_vs_group_statistics/player_to_player.csv')
for i in range(len(pp_data)):
	batsmen_name = pp_data.loc[i].batsman.strip()
	batsmen_cluster[batsmen_name] = pp_data.loc[i].batclustno
	bowler_name = pp_data.loc[i].bowler.strip()
	bowler_cluster[bowler_name] = pp_data.loc[i].bowlclustno

#IPL teams to simulate
with open('group_vs_group_statistics/squad.csv') as ipl_team_data:
	ipl_teams = csv.reader(ipl_team_data)
	next(ipl_teams)
	for players in ipl_teams:
		ipl_team_1.append(players[0])
		ipl_team_2.append(players[1])
ipl_team_data.close()

c_to_c = pd.read_csv('group_vs_group_statistics/clust_to_clust.csv')
cluster_prob = pd.DataFrame(columns=['batclustno','bowlclustno','0', '1', '2', '3', '4',  '6','notout'])
for i in range(len(c_to_c)):
	cluster_prob.at[i] = [None for n in range(9)]
	cluster_prob.at[i,'batclustno'] = c_to_c.at[i,'batclustno']
	cluster_prob.at[i,'bowlclustno'] = c_to_c.at[i,'bowlclustno']
	cluster_prob.at[i,'0'] = float(c_to_c.at[i,'0'])
	cluster_prob.at[i,'1'] = float(c_to_c.at[i,'1']) + float(c_to_c.at[i,'0'])
	cluster_prob.at[i,'2'] = float(c_to_c.at[i,'2']) + float(cluster_prob.at[i,'1'])
	cluster_prob.at[i,'3'] = float(c_to_c.at[i,'3']) + float(cluster_prob.at[i,'2'])
	cluster_prob.at[i,'4'] = float(c_to_c.at[i,'4']) + float(cluster_prob.at[i,'3'])
	cluster_prob.at[i,'6'] = float(c_to_c.at[i,'6']) + float(cluster_prob.at[i,'4'])
	cluster_prob.at[i,'notout'] = 1 - float(c_to_c.at[i,'out'])
#cluster_prob.to_csv('group_vs_group_statistics/cluster_prob.csv')

p_to_p = pd.read_csv('group_vs_group_statistics/player_to_player.csv')
p_prob = pd.DataFrame(columns=['batsman','bowler','0','1','2','3','4','6','notout','balls'])
for i in range(len(p_to_p)):
	p_prob.at[i] = [None for n in range(10)]
	p_prob.at[i,'batsman'] = p_to_p.at[i,'batsman']
	p_prob.at[i,'bowler'] = p_to_p.at[i,'bowler']
	p_prob.at[i,'0'] = float(p_to_p.at[i,'0'])
	p_prob.at[i,'1'] = float(p_to_p.at[i,'1']) + float(p_to_p.at[i,'0'])
	p_prob.at[i,'2'] = float(p_to_p.at[i,'2']) + float(p_prob.at[i,'1'])
	p_prob.at[i,'3'] = float(p_to_p.at[i,'3']) + float(p_prob.at[i,'2'])
	p_prob.at[i,'4'] = float(p_to_p.at[i,'4']) + float(p_prob.at[i,'3'])
	p_prob.at[i,'6'] = float(p_to_p.at[i,'6']) + float(p_prob.at[i,'4'])
	p_prob.at[i,'notout'] = 1 - float(p_to_p.at[i,'out'])
	p_prob.at[i,'balls'] = p_to_p.at[i,'balls']
#p_prob.to_csv('group_vs_group_statistics/player_prob.csv')

def computePlayerProb(batsman,bowler):
	player_data_row = player_prob.loc[player_prob['batsman'] == batsman].loc[player_prob['bowler'] == bowler]
	rnd_num = random.random()
	if rnd_num <= float(player_data_row['0']):
		return 0
	elif  rnd_num <= float(player_data_row['1']):
		return 1
	elif rnd_num <= float(player_data_row['2']):
		return 2
	elif rnd_num <= float(player_data_row['3']):
		return 3
	elif  rnd_num <= float(player_data_row['4']):
		return 4
	elif rnd_num <= float(player_data_row['6']):
		return 6

def computeClusterProb(bat_clust_no,bowl_clust_no):
	cluster_data_row = cluster_prob.loc[cluster_prob['batclustno'] == bat_clust_no].loc[cluster_prob['bowlclustno'] == bowl_clust_no]
	rnd_num = random.random()
	if rnd_num <= float(cluster_data_row['0']):
		return 0
	elif  rnd_num <= float(cluster_data_row['1']):
		return 1
	elif rnd_num <= float(cluster_data_row['2']):
		return 2
	elif rnd_num <= float(cluster_data_row['3']):
		return 3
	elif  rnd_num <= float(cluster_data_row['4']):
		return 4
	elif rnd_num <= float(cluster_data_row['6']):
		return 6

def firstInnings(ipl_team_1, ipl_team_2):
	striker_bat = ipl_team_1[0]
	non_striker = ipl_team_1[1]
	bowler = ipl_team_2[len(ipl_team_2)-1]
	nxt_bat = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	processing_dict = {}
	processing_dict[striker_bat] = 1
	processing_dict[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		cl = 0
		while(balls<6 and wick <10):
			try:
				row = player_prob.loc[player_prob['batsman'] == striker_bat].loc[player_prob['bowler'] == bowler]
				if (row['balls'] >= 15):
					prob = float(row['notout'])
				else:
					row = cluster_prob.loc[cluster_prob['batclustno'] == batsmen_cluster[striker_bat]].loc[cluster_prob['bowlclustno'] == bowler_cluster[bowler]]
					prob = float(row['notout'])
					cl = 1
			except:
				row = cluster_prob.loc[cluster_prob['batclustno'] == batsmen_cluster[striker_bat]].loc[cluster_prob['bowlclustno'] == bowler_cluster[bowler]]
				prob = float(row['notout'])
				cl = 1

			score = 0
			flag = 0
			nprob = nprob*prob
			processing_dict[striker_bat] = processing_dict[striker_bat]*prob
			if (processing_dict[striker_bat] > 0.5):
				if cl==0:
					if (int(row['balls'])>=15):
						score = computePlayerProb(striker_bat,bowler)
					else:
						score = computeClusterProb(batsmen_cluster[striker_bat],bowler_cluster[bowler])
				else:
					score = computeClusterProb(batsmen_cluster[striker_bat],bowler_cluster[bowler])
			elif processing_dict[striker_bat] < 0.5:
				wick = wick+1
				striker_bat = ipl_team_1[nxt_bat]
				nxt_bat = (nxt_bat+1)%11
				flag = 1
				processing_dict[striker_bat] = 1
			if(flag==0):
				try:
					runs = runs+int(score)
				except:
					pass
				if (score==1 or score == 3):
					striker_bat,non_striker = non_striker,striker_bat
			balls = balls+1
		striker_bat,non_striker = non_striker,striker_bat
		bowler = ipl_team_2[len(ipl_team_2)-count]
		count = (count+1)%5 + 1
		overs = overs+1
		print("{0:10d} {1:10d}".format(overs, runs))
	return runs,wick


def secondInnings(ipl_team_1, ipl_team_2,team_1_runs):
	striker_bat = ipl_team_1[0]
	non_striker = ipl_team_1[1]
	bowler = ipl_team_2[len(ipl_team_2)-1]
	nxt_bat = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	processing_dict = {}
	processing_dict[striker_bat] = 1
	processing_dict[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		cl = 0
		while(balls<6 and runs<=team_1_runs and wick <10):
			try:
				row = player_prob.loc[player_prob['batsman'] == striker_bat].loc[player_prob['bowler'] == bowler]
				if (row['balls'] >= 15):
					prob = float(row['notout'])
				else:
					row = cluster_prob.loc[cluster_prob['batclustno'] == batsmen_cluster[striker_bat]].loc[cluster_prob['bowlclustno'] == bowler_cluster[bowler]]
					prob = float(row['notout'])
					cl = 1
			except:
				if bowler in bowler_cluster:
					row = cluster_prob.loc[cluster_prob['batclustno'] == batsmen_cluster[striker_bat]].loc[cluster_prob['bowlclustno'] == bowler_cluster[bowler]]
					prob = float(row['notout'])
					cl = 1
				else:
					bowler = ipl_team_2[len(ipl_team_2) - count]
					continue
			score = 0
			flag = 0
			nprob = nprob*prob
			processing_dict[striker_bat] = processing_dict[striker_bat]*prob
			if (processing_dict[striker_bat] > 0.5):
				if cl==0:
					if (int(row['balls'])>=15):
						score = computePlayerProb(striker_bat,bowler)
					else:
						score = computeClusterProb(batsmen_cluster[striker_bat],bowler_cluster[bowler])
				else:

					score = computeClusterProb(batsmen_cluster[striker_bat],bowler_cluster[bowler])
			elif processing_dict[striker_bat] < 0.5:
				wick = wick+1
				striker_bat = ipl_team_1[nxt_bat]
				nxt_bat = (nxt_bat+1)%11
				flag = 1
				processing_dict[striker_bat] = 1
			if(flag==0):
				try:
					runs = runs+int(score)
				except:
					pass
				if (score==1 or score == 3):
					striker_bat,non_striker = non_striker,striker_bat
			balls = balls+1
		striker_bat,non_striker = non_striker,striker_bat
		bowler = ipl_team_2[len(ipl_team_2)-count]
		count = (count+1)%5 + 1
		overs = overs+1
		print("{0:10d}|{1:10d}".format(overs, runs))
		if (runs>team_1_runs):
			break
	return runs,wick

print("---------------First Innings-----------------------")
print("Overs{:10d}|{:10d}Runs")
team_1_runs ,team_1_wickets = firstInnings(ipl_team_1,ipl_team_2)
print("\n-------------Second Innings----------------------")
print("Overs{:10d}|{:10d}Runs")
team_2_runs ,team_2_wickets = secondInnings(ipl_team_2,ipl_team_1,team_1_runs)
print("\nIPL Team one Scores and Wickets are: ", team_1_runs, team_1_wickets)
print("IPL Team two Scores and Wickets are : ", team_2_runs, team_2_wickets)
if(team_1_runs > team_2_runs):
	print("Team 1 Won!!!\n")
elif(team_1_runs < team_2_runs):
	print("Team 2 Won!!!\n")
else:
	print("Match Tie")
