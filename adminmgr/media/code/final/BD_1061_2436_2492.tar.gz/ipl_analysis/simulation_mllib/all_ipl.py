import csv
import glob

ipl_matches_data = glob.glob('simulation_mllib/ipl_csv/*.csv')
with open('ball-by-ball.csv', 'w', newline='') as file_dat:
	file_dat.close()
for ipl_match in ipl_matches_data:
	with open(ipl_match, 'r') as csvfile:
		csvreader = csv.reader(csvfile)
		with open('simulation_mllib/ball-by-ball.csv', 'a', newline='') as file_dat:
			data_writer = csv.writer(file_dat)

			for ipl_match_row in csvreader:
				if(len(ipl_match_row) >= 8):
					data_writer.writerow([ipl_match_row[4], ipl_match_row[6], ipl_match_row[2], ipl_match_row[1], int(ipl_match_row[7])])
	csvfile.close()
file_dat.close()
print("data written to ball_by_ball file")