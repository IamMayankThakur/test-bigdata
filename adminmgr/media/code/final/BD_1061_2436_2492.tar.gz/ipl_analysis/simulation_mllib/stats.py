import csv
from hdfs import InsecureClient
import socket
import pandas as pd

host_ip_address= socket.gethostbyname(socket.gethostname())
cli_HDFS = InsecureClient('http://' + host_ip_address + ':9870')

with cli_HDFS.read('IPL/batting.csv', encoding='utf-8') as bat_file_data:
	batsmen_df = pd.read_csv(bat_file_data)
batsmen_df.to_csv('simulation_mllib/batting.csv', index=False)

with cli_HDFS.read('IPL/bowling.csv', encoding='utf-8') as bowl_file_data:
	bowler_df = pd.read_csv(bowl_file_data)
bowler_df.to_csv('simulation_mllib/bowling.csv', index=False)

with open('simulation_mllib/player-stat.csv', 'w', newline='') as plr_st_data:
	data_writer = csv.writer(plr_st_data)
	with open('simulation_mllib/ball-by-ball.csv', 'r', newline='') as file_data:
		data_reader = csv.reader(file_data)
		for b_b_row in data_reader:
			with open('simulation_mllib/batting.csv', 'r', newline='') as csc:
				data_from_file = csv.reader(csc)
				for col in data_from_file:
					if(col[0]==b_b_row[0]):
						b_b_row.insert(2, col[7])
						b_b_row.insert(3, col[9])
						break
			csc.close()
			with open('simulation_mllib/bowling.csv', 'r', newline='') as cs:
				data_from_file = csv.reader(cs)
				for col in data_from_file:
					if(col[0]==b_b_row[1]):
						b_b_row.insert(4, col[9])
						b_b_row.insert(5, col[10])
						b_b_row.insert(6, col[11])
						data_writer.writerow(b_b_row)
						break
			cs.close()
	file_data.close()
plr_st_data.close()

print("data written to player-stat file")
