import sys
import csv
import pandas as pd
from hdfs import InsecureClient
import socket
from collections import defaultdict

data_dictionary = defaultdict(list)
host_ip_address= socket.gethostbyname(socket.gethostname())
client_hdfs = InsecureClient('http://' + host_ip_address + ':9870')

def readFileFromHDFS(filename):
	with client_hdfs.read('IPL/'+filename, encoding='utf-8') as data:
		return pd.read_csv(data)
	
with open('group_vs_group_statistics/ipl.csv', 'r') as ipl_file:
	ipl_file_data = csv.reader(ipl_file)
	for data_row in ipl_file_data:
		DV = [data_row[2],data_row[3]]
		data_dictionary[data_row[0],data_row[1]].append(DV)
ipl_file.close()

pp_file = open('group_vs_group_statistics/player_to_player.csv','w',newline='')
pp_header = ['batsman', 'bowler', '0','1','2','3','4','6','out','batclustno','bowlclustno','balls']
data_writer = csv.DictWriter(pp_file, fieldnames=pp_header)
data_writer.writeheader()

#player data for clusters
bat_clus_data = readFileFromHDFS('bat_clusters.csv')
bowl_clus_data = readFileFromHDFS('bowl_clusters.csv')

print("writing data to player_to_player file...")
for bat_bow,values in data_dictionary.items():
	no_of_0, no_of_1, no_of_2, no_of_3, no_of_4, no_of_6, wick,	balls = 0,0,0,0,0,0,0,0
	for obj in values:
		RS = obj[0]
		if RS == '0':
			no_of_0 = no_of_0+1
		elif RS == '1':
			no_of_1 = no_of_1+1
		elif RS == '2':
			no_of_2 = no_of_2+1
		elif RS == '3':
			no_of_3 = no_of_3+1
		elif RS == '4':
			no_of_4 = no_of_4+1
		elif RS == '6':
			no_of_6 = no_of_6+1
		if obj[1] == '1':
			wick = wick +1
		balls = balls +1
	batclustno = 0
	bowlclusrno = 0
	bat_row_from_df=bat_clus_data.loc[bat_clus_data['player_name'] == bat_bow[0]]
	if not bat_row_from_df.empty:
		if bat_row_from_df.iloc[0]['player_name'] == bat_bow[0]:
			batclustno = bat_row_from_df.iloc[0]['cluster_number']
	bowl_row_from_df = bowl_clus_data.loc[bat_clus_data['player_name'] == bat_bow[1]]

	if not bowl_row_from_df.empty:
		if bowl_row_from_df.iloc[0]['player_name'] == bat_bow[1]:
			bowlclustno = bowl_row_from_df.iloc[0]['cluster_number']
	data_writer.writerow({'batsman':bat_bow[0],'bowler':bat_bow[1],'0':(no_of_0+1)/balls,'1':(no_of_1+1)/balls,'2':(no_of_2+1)/balls,'3':(no_of_3+1)/balls,'4':(no_of_4+1)/balls,'6':(no_of_6+1)/balls,'out':wick/balls,'batclustno':batclustno,'bowlclustno':bowlclustno,'balls':balls})

cluster_pairs = pd.read_csv('group_vs_group_statistics/player_to_player.csv')
del cluster_pairs['batsman']
del cluster_pairs['bowler']
final = cluster_pairs.groupby(['batclustno','bowlclustno']).mean()
print("writing clustor_to_cluster file")
final.to_csv('group_vs_group_statistics/clust_to_clust.csv')
print("completed.")