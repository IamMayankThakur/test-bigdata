from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
import pandas as pd
from hdfs import InsecureClient
import socket

host_ip_address= socket.gethostbyname(socket.gethostname())
cli_HDFS = InsecureClient('http://' + host_ip_address + ':9870')
spark_obj = SparkSession.builder.appName('cricket').getOrCreate()

with cli_HDFS.read('IPL/batting.csv', encoding='utf-8') as bat_file_data:
	batsmen_df = pd.read_csv(bat_file_data)

with cli_HDFS.read('IPL/bowling.csv', encoding='utf-8') as bowl_file_data:
	bowler_df = pd.read_csv(bowl_file_data)

batsmen_df=spark_obj.createDataFrame(batsmen_df)
bowler_df=spark_obj.createDataFrame(bowler_df)

batting_header = ['Ave','SR']
bowling_header = ['Econ', 'SR']

def preProcessingClustering(fp, cols):
	data_assembler = VectorAssembler(inputCols=cols, outputCol='features')
	asb_data = data_assembler.transform(fp)
	scaler = StandardScaler(inputCol='features', outputCol='scaledFeatures')
	sc_model = scaler.fit(asb_data)
	scaled_data = sc_model.transform(asb_data)
	K_means_obj = KMeans(featuresCol='scaledFeatures', k=10)
	trained_KM = K_means_obj.fit(scaled_data)
	trained_KM_data = trained_KM.transform(scaled_data)
	return trained_KM_data

bat_clus_data = preProcessingClustering(batsmen_df, batting_header)
bowl_clus_data = preProcessingClustering(bowler_df, bowling_header)

print("\n------------- BATSMEN CLUSTER Details --------------\n")
bat_clus_data.groupBy('prediction').count().show()
bat_clus_data.show(10)

bat_det_clust=bat_clus_data.select('Player','prediction').toPandas()
with cli_HDFS.write('IPL/bat_clusters.csv',overwrite=True, encoding='utf-8') as writer:
	bat_det_clust.to_csv(writer,index=False,header=['player_name','cluster_number'])

print("\n----------------- BOWLER CLUSTER Details------------------\n")
bowl_clus_data.groupBy('prediction').count().show()
bowl_clus_data.show(10)

bowl_det_clust=bowl_clus_data.select('Player','prediction').toPandas()
with cli_HDFS.write('IPL/bowl_clusters.csv',overwrite=True, encoding='utf-8') as writer:
	bowl_det_clust.to_csv(writer,index=False,header=['player_name','cluster_number'])