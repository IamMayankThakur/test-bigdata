import csv
import pandas as pd
import os
from bs4 import BeautifulSoup as soup
from hdfs import InsecureClient
import socket

host_ip_address= socket.gethostbyname(socket.gethostname())
cli_HDFS = InsecureClient('http://' + host_ip_address + ':9870')
cwd=os.getcwd()

batsmen_header = [['Player', 'Span', 'Mat', 'Inns', 'NO', 'Runs', 'HS', 'Ave', 'BF', 'SR', '100', '50', '0', '4s', '6s']]
bowler_header = [['Player', 'Span', 'Mat', 'Inns', 'Overs', 'Mdns', 'Runs', 'Wkts', 'BBI', 'Ave', 'Econ', 'SR', '4', '5', 'Ct', 'St']]

def findDuplicateRows(name_of_file, result_dataset, dataset_header):
    temp_df = pd.DataFrame(dataset_header)
    for dup_row in result_dataset:
        if((name_of_file == 'batting.csv' and len(dup_row) != 15) or (name_of_file == 'bowling.csv' and len(dup_row) != 16)) :
            dup_row.insert(1, '-')
        if(dup_row[0] not in temp_df[0].values.tolist()):
            dataset_header.append(dup_row)
            temp_df = pd.DataFrame(dataset_header)
        else:
            for header_item in dataset_header:
                if(dup_row[0] == header_item[0]):
                    if(name_of_file == 'batting.csv'):
                        for c in [2, 3, 4, 5, 8, 10, 11, 12, 13, 14]:
                            header_item[c] = str(int(header_item[c]) + int(dup_row[c]))
                        header_item[7] = str((float(header_item[7]) + float(dup_row[7])) / 2)
                        header_item[9] = str((float(header_item[9]) + float(dup_row[9])) / 2)
                    if(name_of_file == 'bowling.csv'):
                        for c in [2, 3, 5, 6, 7, 12, 13, 14, 15]:
                            header_item[c] = str(int(header_item[c]) + int(dup_row[c]))
                        header_item[4] = str(float(header_item[4]) + float(dup_row[4]))
                        header_item[9] = str((float(header_item[9]) + float(dup_row[9])) / 2)
                        header_item[10] = str((float(header_item[10]) + float(dup_row[10])) / 2)
                        header_item[11] = str((float(header_item[11]) + float(dup_row[11])) / 2)
                    temp_df = pd.DataFrame(dataset_header)

def webOfflineScraping(url_link, name_of_file, dataset_header):
    web_page = soup(open(url_link, 'rb').read(), "html.parser")
    ipl_data_rows=web_page.find_all('tr')
    result_dataset=[]
    rows_to_remove=[]
    for ipl_row in ipl_data_rows:
        data_column=ipl_row.find_all('td')
        data_column=[x.text.strip().replace('-', '0') for x in data_column]
        result_dataset.append(data_column)
    for r in result_dataset:
        if len(r)<14:
            rows_to_remove.append(r)
    for r in rows_to_remove:
        result_dataset.remove(r)
    findDuplicateRows(name_of_file, result_dataset, dataset_header)

batsmen_filename = 'batting.csv'
for url_number in range(1, 14):
    url_link_ipl = os.path.join(cwd,'WebPages/Batsmen/') + str(url_number) + '.html'
    webOfflineScraping(url_link_ipl, batsmen_filename, batsmen_header)

batsmen_data=pd.DataFrame(data=batsmen_header)
with cli_HDFS.write('IPL/batting.csv',overwrite=True, encoding='utf-8') as file_data:
    batsmen_data.to_csv(file_data,index=False,header=None)

bowler_filename = 'bowling.csv'
for url_number in range(1, 14):
    url_link_ipl = os.path.join(cwd,'WebPages/Bowler/') + str(url_number) + '.html'
    webOfflineScraping(url_link_ipl, bowler_filename, bowler_header)
bowler_data=pd.DataFrame(data=bowler_header)

with cli_HDFS.write('IPL/bowling.csv',overwrite=True, encoding='utf-8') as file_data:
    bowler_data.to_csv(file_data,index=False,header=None)

print("data written to batting.csv and bowling.csv")
