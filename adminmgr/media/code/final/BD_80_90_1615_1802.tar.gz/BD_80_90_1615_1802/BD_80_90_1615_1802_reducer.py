#!/usr/bin/python3
import sys
final_set=set()
imp_flag=-9999
maximum=-9999999999999999
counter=0
summ=0
max_flag=0
avg_flag=0
count_flag=0
for line in sys.stdin:
	line=line.strip()
	imp_flag=line[-1]#Get the last bit which is an indicator
	if(imp_flag=='0'): #Simple Project
		line=line.split()
		ret=line.pop()
		line=' '.join(line)
		final_set.add(line)#Remove Duplicates



	elif(imp_flag=='1'):#Agg Fucntions[max:0,avg:1,count:2]
		line=line.split(",")
		ret=line.pop()
		for i in line:
			temp=i.split(":")
			if(temp[1]=='0'):#We need to compute max for this column
				max_flag=1
				if(int(temp[0])>maximum):
					maximum=int(temp[0])
			elif(temp[1]=='1'):#We need to compute avg for this column
				avg_flag=1
				summ+=int(temp[0])
				counter+=1
			else:
				count_flag=1
				counter+=1
				
		
if(imp_flag=='0'):
	final=list(final_set)
	for i in final:
		print(i)#DONE!!

elif(imp_flag=='1'):
	if(max_flag==1):
		print("MAXIMUM = " , maximum)
	if(avg_flag==1):
		print("AVERAGE = " , summ/counter)
	if(count_flag==1):
		print("COUNT = " ,counter)
	
	
	
