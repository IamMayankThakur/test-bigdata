#!/usr/bin/python3
import sys
import subprocess
sent = ['SELECT', 'COUNT(matches)', 'FROM', 'task3.csv']


#Read the Schema & Store it as Dict
from collections import OrderedDict
schema=OrderedDict()
agg_flag=0
with open("/home/hadoop/Desktop/schema_file.txt") as fptr:
	given_schema = fptr.readlines()[0]#Get schema as a string
	given_schema=given_schema[1:len(given_schema)-1]#Remove ()
	given_schema=given_schema.split(",")#Split on , to get individual colname
	for i in given_schema:
		temp=i.split(":")
		schema[temp[0]]=temp[1]#dictionary of schema format={colname:datatype}

indexes=list()
keys=list(schema.keys())#List of all cols
if(len(sent)==4): #Just projection (Select <cols> from table format)
	cols=sent[1]
	if(cols=='*'):#Select everything
		for i in range(len(keys)):
			indexes.append(i)#append all the indexes..
		infile=sys.stdin
		for line in infile:
			line=line.strip()
			line=line.split(",")
			post=""
			for index in indexes:
				post=post+str(line[index])+" "
			post+='0'#Reducer would know it only has to print
			print(post)
	

	else:
		cols=sent[1]
		cols=cols.split(",")
		if(cols[0].startswith('MAX') or cols[0].startswith('AVG') or cols[0].startswith('COUNT')):#if aggregate are used, all must be aggregate only
			for i in cols:
				if(i.startswith('MAX')):
					agg_flag=0
				elif(i.startswith('AVG')):
					agg_flag=1
				else:
					agg_flag=2
				col_name=i.split('(')[1][0:-1]#Extract the column name
				for j in range(len(keys)):
					if(col_name==keys[j]):
						indexes.append((j,agg_flag))
						break
			infile=sys.stdin
			for line in infile:
				line=line.strip()
				line=line.split(",")
				post=""
				for index in indexes:
					post=post+str(line[index[0]])+":"+str(index[1])+","
				post=post+'1'#reducer would know this is aggregation
				print(post)
		
		else:#Projection with some columns mentioned..
			for i in cols:
				for j in range(len(keys)):
					if(i==keys[j]):
						indexes.append(j)
			infile=sys.stdin
			for line in infile:
				line=line.strip()
				line=line.split(",")
				post=""
				for index in indexes:
					post=post+str(line[index])+" "
				post+='0'#Reducer would know it only has to print
				print(post)
	
			









