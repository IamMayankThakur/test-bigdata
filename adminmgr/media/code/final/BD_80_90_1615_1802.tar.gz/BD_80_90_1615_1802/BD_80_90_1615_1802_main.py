import sys
import os
import subprocess
import warnings

from collections import OrderedDict

#os.system()

#subprocess.call(['ls -l'])

hdfs_dir="Desktop"#This is the database name
table_name="task3.csv"#This is the table name

def execute_cmd(command_string):
	if(command_string=="pwd"):
		val = subprocess.check_output(command_string , shell=True)
		return val
	else:
		return os.system(command_string)


def check_numeric(schema , col_name):
	flag=0
	if (col_name in schema):
		if(schema[col_name]=='int' or schema[col_name]=='float'):
			return (True,0)
		else:
			print("Non Numeric Data type of : " , col_name)
			return (False,-1)
	else:
		return (False,-2)


def validate_cols(cols):
	schema=OrderedDict()
	with open("/home/hadoop/Desktop/schema_file.txt") as fptr:
		given_schema = fptr.readlines()[0]#Get schema as a string
		given_schema = given_schema.strip()
		given_schema=given_schema[1:-1]#Remove ()
		given_schema=given_schema.split(",")#Split on , to get individual colname
		for i in given_schema:
			temp=i.split(":")
			schema[temp[0]]=temp[1]#dictionary of schema format={colname:datatype}
	cols=cols.split(",")
	keys=list(schema.keys())
	if(len(cols) > len(keys)):
		return False
	for i in cols:
		check_val=i
		flag=0
		fg=-2
		if(i.startswith('MAX') or i.startswith('AVG') or i.startswith('COUNT')):
			col_name=i.split('(')[1][0:-1]#extract the column name..
			check_val=col_name
			ret_val,fg = check_numeric(schema,col_name)#Aggregate functions only on numeric datatype
			if(ret_val==True):
				flag=1
			elif(fg==-1):
				return False
			else:
				flag=0
		else:
			for j in keys:
				if(check_val==j):
					flag=1
					break;
		if(flag==0 and fg==-2):
			print("No column by the name : ",check_val," in schema")
			return False
	return True
	
	
def evaluate_query(query):
	global hdfs_dir
	global table_name
	if(query[0]=="SELECT" and query[2]=="FROM" and len(query)==4):
		if(query[3]==table_name):
			if(query[1]=='*'):
				return True
			else:
				return validate_cols(query[1])
		else:
			print("Table Name incorrect...Exiting...\n\n")
			return False
	else:
		print("Incorrect Synatax...Exiting...\n\n")
		return False
		

def load_fn():
	print("Enter load command :(Expected format : LOAD <path to file> AS (col1:datatype,col2:datatype....)) ")
	cmd=input()
	cmd_list=cmd.split()
	if (cmd_list[0]=="LOAD" and len(cmd_list)==4):
		command_string="hdfs dfs -mkdir"
		command_string_1="hdfs dfs -put /home/hadoop/"
		path_to_file=cmd_list[1].split("/")
		if(path_to_file[0]==''):
			path_to_file=path_to_file[1:]
		global hdfs_dir
		hdfs_dir=path_to_file[0]
		global table_name
		table_name=path_to_file[-1]
		command_string=command_string+" /"+hdfs_dir
		ret_val=execute_cmd(command_string)#Directory created
		if(ret_val!=0):
			return;
		command_string_1=command_string_1 + cmd_list[1] +" /" +hdfs_dir
		#print(command_string_1)
		ret_value = execute_cmd(command_string_1)#Loaded ino hdfs csv file..
		if(ret_val!=0):
			return;
		
		file_ptr=open("schema_file.txt" , "w")
		file_ptr.write(cmd_list[3])#Schema Written to a temp file.
		file_ptr.close()
		ret_val=execute_cmd("pwd")
		cur_path=ret_val.decode("utf-8").strip()
		file_path=cur_path + "/schema_file.txt"
		command_string_2="hdfs dfs -put "+file_path+" /"+hdfs_dir
		#print(command_string_2)
		ret_val = execute_cmd(command_string_2)#Loaded Schema into hdfs
		if(ret_val!=0):
			return;
	print("    ------------Database : '", hdfs_dir , "' Created Successfully------------")
		

def query_db():
	global hdfs_dir
	global table_name
	db_name=input(" Enter Database Name ")
	query=input(" Enter a valid query...").split()
	ret_val=execute_cmd("chmod a+x try_map_me.py")#Give all read write permissions..
	ret_val=execute_cmd("chmod a+x try_red_me.py")
	cmd="hadoop jar /home/hadoop/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper /home/hadoop/Desktop/try_map_me.py -reducer /home/hadoop/Desktop/try_red_me.py -input /" + db_name+ "/"+ table_name + " -output /"+db_name+"/out10000"

	#print(hdfs_dir,table_name)

	if(db_name == hdfs_dir):
		ret_val = evaluate_query(query)
		if(ret_val==True):
			with open("/home/hadoop/Desktop/try_map_me.py") as fptr:
				lines = fptr.readlines()#lines contains a list of lines of mapper..
			
			lines[3]='sent = ' + str(query) +'\n' #Send query to mapper
			with open("/home/hadoop/Desktop/try_map_me.py","w") as fptr:
				fptr.writelines(lines)
			ret_val=execute_cmd(cmd)
		else:
			return
	else:
		print("Database undeclared...exiting...\n\n")
		return;
	
	
	

def start():
	print("1.Database Load to HDFS\n\n2.Query the database \n\n3.Exit \n\nEnter your option: ")
	client_choice = int(input())
	if(client_choice==1):
		load_fn()
	elif(client_choice==2):
		query_db()
	elif(client_choice==3):
		flag=False
	else:
		print("Invalid command\n")


start()

