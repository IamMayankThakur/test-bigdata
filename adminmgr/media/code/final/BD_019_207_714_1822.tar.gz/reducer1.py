#!/usr/bin/python3
import sys
fil=open("/home/hduser/aggregate.txt","r")
x=fil.read()
fil.close()

xx=[]
for line in sys.stdin:
	if(line.split("\t")[0]!=""):
		xx.append(line.split("\t")[0].split("\n")[0])

print("YOUR OUTPUT\n\n\n")
args=x.split(" ")
operation=args[0].strip()
order=0
asds=""

if((operation.lower())=="count"):
	count=0
	for line in xx:
		count+=1
	print("count ::"+str(count))
elif((operation.lower())=="max"):
	array=0.0
	try:
		for line in xx:
			g=float(line.strip())
			if(g>array):
				array=g
		maximum=array
		print("MAXIMUM VALUE ::"+str(maximum))
	except:
		print("WRONG DATATYPE")
	
elif((operation.lower())=="min"):
	array=999999.999
	try:
		for line in xx:
			g=float(line.strip())
			if(g<array):
				array=g
		minimum=array
		print("MIN VALUE ::"+str(minimum))
	except:
		print("WRONG DATATYPE")
	
else:
	for line in xx:
		print(line)
print("\n\n\n")
