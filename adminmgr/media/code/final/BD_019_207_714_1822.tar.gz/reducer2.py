#!/usr/bin/python3
import sys
infile=sys.stdin
val=dict()
fil=open("/home/hduser/aggregate.txt","r")
x=fil.read()
fil.close()
asds=x.split(" ")[2]
for line in infile:
	if(line!=""):
		if line.strip() not in val.keys():
			val[line.strip().split("\t")[0]]=1
		else:
			val[line.strip().split("\t")[0]]+=1
print("YOUR OUTPUT IS \n\n\n\n\n")
if(asds=="asc"):
	for i in sorted(val.items(),key= lambda x:(x[1],x[0])):
		print(i[0],i[1])
elif(asds=="desc"):
	for i in sorted(val.items(),key= lambda x:(-x[1],x[0])):
		print(i[0],i[1])
print("\n\n\n")
