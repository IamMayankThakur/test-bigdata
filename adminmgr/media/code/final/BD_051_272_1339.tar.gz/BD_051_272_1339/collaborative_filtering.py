import pandas as pd
cpairs = pd.read_csv('player_to_player.csv')
del cpairs['batsman']
del cpairs['bowler']

diff_arr = [['bowler','replacing_bowler','Econ_diff']]
bowl_fp = spark.read.csv('hdfs://loaclhost:9000/usr/sruthi/bowler.csv', header=True, inferSchema=True)
differnce = pd.DataFrame(columns=['bowler','replacing_bowler','Econ_diff'])

filename = 'collaborative_filtering.csv'
#bowling_change = pd.DataFrame(columns=['Econ'])
for i in range(len(bowl_fp)):
	for j in  range(len(bowl_fp)):
		if (i[0] == j[0] ):
			j++
		
		else
			x= float(bowl_fp[i,'Econ']) - float(bowl_fp[j,'Econ'])
			difference.at[i,'0'] = float(bowl_fp.at[i,'0'])                            #Finding cumulative probabilities
			difference.at[i,'1'] = float(bowl_fp.at[j,'0'])
			difference.at[i,'2'] = x
			
			
writer(filename, diff_arr)
			
			
			
			
def writer(fn, row_arr):
    with open(fn, 'w') as myFile:
        writer = csv.writer(myFile)
        for r in row_arr:
            writer.writerow(r)
        myFile.close()
