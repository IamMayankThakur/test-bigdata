from bs4 import BeautifulSoup as soup
import csv
import pandas as pd


batting_array = [['PLAYER', 'SPAN', 'MATCH', 'INNINGS', 'NO', 'RUNS', 'HS', 'AVE', 'BF', 'SR', '100', '50', '0', '4s', '6s']]
bowler_array = [['PLAYER', 'SPAN', 'MATCH', 'INNINGS', 'OVERS', 'MDNS', 'RUNS', 'WKTS', 'BBI', 'AVE', 'ECON', 'SR', '4', '5', 'CT', 'ST']]

def duplicate(file_name, result, row):
    dataframe = pd.DataFrame(row)
    
    for i in result:
        if((file_name == 'batting.csv' and len(i) != 15) or (file_name == 'bowling.csv' and len(i) != 16)) :
	
filename = 'batting.csv'

for u_link in range(1, 14):
    my_off_url = 'home/gagana/Desktop/atting.html'
    scraper(my_off_url, filename, bat_arr)
writer(filename, bat_arr)
            i.insert(1, '-')
        if(i[0] not in dataframe[0].values.tolist()):
    	    row.append(i)
    	    dataframe = pd.DataFrame(row)
        else:
            print(i[0])
            for j in row:
                if(i[0] == j[0]):
                    if(file_name == 'batting.csv'):
                        for c in [2, 3, 4, 5, 8, 10, 11, 12, 13, 14]:
                            j[c] = str(int(j[c]) + int(i[c]))
                        j[7] = str((float(j[7]) + float(i[7])) / 2)
                        j[9] = str((float(i[9]) + float(i[9])) / 2)
                    df = pd.DataFrame(row)

def scraper(lp, fn, row_arr):
    page = soup(open(lp, 'rb').read(), "html.parser") 
    rows=page.find_all('tr') 
    for row in rows:
	with open(fn, 'w') as myFile:
        writer = csv.writer(myFile)
	res=[]
    	l=[]
        cols=row.find_all('td')
        cols=[x.text.strip().replace('-', '0').encode('utf8') for x in cols]
        res.append(cols)

   

    for i in l:
        res.remove(i)
	 for i in res:
        if len(i)<14:
            l.append(i)
    
    duplicate(fn, res, row_arr)

def writer(fn, row_arr):
        for r in row_arr:
            writer.writerow(r)
        myFile.close()


filename = 'bowling.csv'
for u_link in range(1, 14):
    my_off_url = '/home/gagana/Desktop/owling.html'
    scraper(my_off_url, filename, bowl_arr)
writer(filename, bowl_arr)


filename = 'batting.csv'
for u_link in range(1, 14):
    my_off_url = 'home/gagana/Desktop/atting.html'
    scraper(my_off_url, filename, bat_arr)
writer(filename, bat_arr)


scraper(my_off_url, filename, bat_arr)
writer(filename, bat_arr)

