from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans

spark = SparkSession.builder.appName('cricket').getOrCreate()







def lol(x):
	a = []
	for i in x:
		if "b'" in i:
			a.append(i[2:-2])
		else:
			a.append(i)
	return a




bat_fp = spark.read.text('hdfs://localhost:9000/usr/sruthi/batting.csv').rdd.map(lambda x:x[0]).map(lambda x : x.split(",")).map(lol).map(lambda x: (x[0],x[1:]))
bowl_fp = spark.read.csv('hdfs://localhost:9000/usr/sruthi/bowling.csv').rdd.map(lambda x:x[0]).map(lambda x : x.split(",")).map(lol).map(lambda x: (x[0],x[1:]))




def EuclidianDistance(a,b):
	d = 0
	for i in range(len(a)):
		dist = dist + ((float(a[i])-float(b[i]))**2)
	return d
	
def FindCluster(a,centroid):
	
	idx = 0
	c = float("+inf")
	for i in range(len(centroid)):
		dist = EuclidianDistance(a, centroid[i])
		if dist < c:
			c = dist
			idx = i
	
	return idx
	
	






def random_points(rdd1, k):
	a = rdd1.takeSample(False, k, 1)
	v = [i[0] for i in a]
	return v
	
	

def kmeans(rdd1, k):
	cen = random_points(rdd1, k)
	conv = 0.00000000000001
	
	dist = 1.00
	
	while dist>conv :
		
		temp = rdd1.map(lambda x : (FindCluster(x[1],cen), (x[1],1)))
		temp2 = temp.reduceByKey(reducer)
		temp3 = temp2.map(avg).collect()
		dist = sum(find_distance(cen[i],idx) for (i,idx) in temp3)
		for i in temp3:
			cen[i[0]] = i[1]
			
	return cen
	

