#!/usr/bin/python3

import sys
#loads query and schema
query = open('/home/chaitra/Apache/hadoop/q.txt','r')
command = query.read()
com = command.strip().split(' ')
schema = open("/home/chaitra/Apache/hadoop/"+(com[3])[:-4]+".txt",'r')
schemacont = schema.readlines()
cols = [i.strip() for i in (schemacont[0][1:-4]).split(',')]
types = [i.strip() for i in (schemacont[1][1:-2]).split(',')]
sels = com[1].split(',')
selcol=[]
All = True
Mismatch=False
aggregate=False
Error=False
msg=''
#check for error
try:
	if len(sels)>1:
		selcol=[cols.index(i) for i in sels]
		All = False
	elif (com[1]!='*'):
		selcol = cols.index(sels[0])
		All = False
except ValueError:
	Error=True
	msg="Column not in table"
if (not Error):
	if len(com)>6 and com[4]=="where":
		try:
			where = cols.index(com[5])
		except ValueError:
			Error=True
			msg="Column not in table"
		i=8
		comp = com[7]
		if not Error:
			while(i<len(com) and com[i] != "aggregate_by"):
				comp = comp+" "+com[i]
				i = i+1
			if (types[where]=='integer' or types[where]=='float'):
				try:
					compare=float(comp)
				except ValueError:
					Mismatch=True
	if ("aggregate_by" in com):
		i=4
		aggregate = True
		while (i<len(com) and com[i]!="aggregate_by"):
			i=i+1
		if (i<len(com)):
			agg=com[i+1].strip()
#print(types[where],comp)
if not Error:
	if (Mismatch):
		msg="ERROR:Comparison between incompatible types."
		Error=True
	elif (("where" in com and types[where] == 'string') and ((com[6]!="=") and (com[6]!="!="))):
		msg="ERROR:Operation not supported for this type."
		Error=True
	elif (aggregate and ((agg=="count" and (com[1]!='*' and isinstance(selcol,list))) or (agg!="count" and not isinstance(selcol,int)))):
		msg="ERROR:Aggregate cant select more than one column."
		Error=True
	elif ("where" in com and (com[6]!="=") and (com[6]!="!=") and (com[6]!="<=") and (com[6]!="<") and (com[6]!=">=") and (com[6]!=">")):
		msg="ERROR:Operator not supported"
		Error=True
	elif (aggregate and (agg!="max") and (agg!="min") and (agg!="count")):
		msg="ERROR: No support for given aggregate function"
		Error=True
	elif (aggregate and agg!="count" and (types[selcol] == 'string')):
		msg="ERROR: Aggregate function not supported on data type"
		Error=True
#perform aggregation or identity function
Max = False
Min = False
Count = False
Empty = True
store = []
count_agg = 0
#checks if max
if (aggregate and (agg=="max")):
	Max = True
elif (aggregate and (agg=="min")):
	#checks min
	Min = True
elif (aggregate and (agg=="count")):
	#checks count
	Count = True
if (not Max and not Min and not Count and not All and not Error):
	#display selected column names
	print(*sels,sep='|')
	print('*'*80)
if All:
	print(*cols,sep='|')
	print('*'*80)

for line in sys.stdin:
	if (not Error):
		if (line != ''):
			Empty=False
		if (Max or Min):
			if float(line) not in store:
				store.append(float(line))
		elif (Count):
			if line not in store:
				store.append(line)
				count_agg = count_agg +1
		else:
			if line not in store:
				store.append(line)
				data = line.split(',')
				print(*data,sep='|') 
if (Error):
	#prints error message
	print(msg)
elif (Empty):
	print("No Matching Entries")
elif (Max):
	print('MAX('+cols[selcol]+')',max(store),sep='|')
elif (Min):
	print('MIN('+cols[selcol]+')',min(store),sep='|')
elif (Count):
	if (All):
		print('COUNT(*)',count_agg,sep='|')
	else:
		print('COUNT('+cols[selcol]+')',count_agg,sep='|')
				
