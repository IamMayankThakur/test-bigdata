MapReduce implementation of SQL Queries
The database is assumed to already  be in the normalized forms without data columns. User must specify it when loading the table into a database. 

Start all daemons.

Execute driver.py
	python3 driver.py

Once Shell prompt (shell::>>) appears,
user can execute the following commands:
	create db <db_name>
	load db <db_name>
	load <table_name.csv> as {'col1':'type1','col2':'type2'}
	select <*|column_name> from <table_name.csv> [where <col> <operator> <value>] [aggregate_by count|max|min]
	drop table <table_name.csv>
	drop db <db_name>
	exit
