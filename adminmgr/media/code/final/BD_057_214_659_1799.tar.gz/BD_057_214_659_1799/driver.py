import os
import csv
import re
import subprocess

#to store schema structure and type in table_name.txt file on local file system
def schemafy(com):
	l1= []
	l2= []
	dict= eval(com[3])
	for i in dict:
		l1.append(i)
		l2.append(dict[i])
	l1=str(l1)
	l2=str(l2)
	l1=re.sub('\'','', l1)
	l2=re.sub('\'','', l2)
	schema = com[1][:len(com[1])-4]+".txt"
	f = open(schema,"w+")
	f.write(str(l1)+"\n")
	f.write(str(l2))
	f.close()		
a =True
os.chdir("/home/chaitra/Apache/hadoop")
while(a):
	#accept command
	command = str(input("shell::>> ")).lower()
	com = command.split()
	#exit
	if(command=="exit"):
		
		a = False
	
	elif(com[0]=="create" and com[1]=='db'):
		#create a new database; makes new directory on hdfs
		c1 = "hdfs dfs -mkdir /" + com[2]
		chdfsd=com[2]
		os.system(c1)
	
	elif(com[0]=="load" and com[1]=="db"):
		#loads already existing database/directory on hdfs
		dbname=com[2]
	
	elif(com[0]=="load" and com[2]=="as"):
		#stores csv file from local file system to hdfs and generates schema file
		schema = com[1][:len(com[1])-4]+"schema.txt"
		schemafy(com)
		pwd = str(os.system('pwd'))
		table = com[1]
		c1 = "hadoop fs -copyFromLocal "+"/home/chaitra"+"/"+com[1]+" "+"/"+dbname+"/"+com[1]
		os.system(c1)
	elif (len(com) >= 4 and com[0]=="select" and com[2]=="from"):
		#checks syntax of selection query
		if ("aggregate_by" in com and "where" not in com and com[4]=="aggregate_by") or ("where" in com and "aggregate_by" in com and com[4]=="where" and com[-2]=="aggregate_by") or ("where" in com and com[4]=="where") or (len(com)==4):
			#based on query, appropriate jobs are executed on hadoop
			Syntax=True
			query = open('q.txt','w+')
			query.write(command)
			query.close()
			os.system("bin/hadoop jar share/hadoop/tools/lib/hadoop-*streaming*.jar -files /home/chaitra/mapper.py,/home/chaitra/reducer.py -mapper 'python3 /home/chaitra/mapper.py' -reducer 'python3 /home/chaitra/reducer.py' -input /"+dbname+"/"+table+" -output /"+dbname+"/out > /dev/null 2>&1 ")
			os.system("hadoop fs -text /"+dbname+"/out/*>local.txt")
			if os.stat("local.txt").st_size==0:
				print("No Entries")
			else:
				os.system("cat local.txt")
			#deletes intermediate files and directories
			os.system("hadoop fs -rm -r /"+dbname+"/out >dump.txt")
			os.system("rm q.txt > /dev/null 2>&1")
			os.system("rm local.txt > /dev/null 2>&1")
		else:
			Syntax=False
		if not Syntax:
			print("Please enter correct command")
		

	elif(com[0]=="drop" and com[1]=="db"):
		#deletes database
		c1 = "hadoop fs -rm -r /" + com[2]
		os.system(c1)
	elif(com[0]=="drop" and com[1]=="table"):
		#deletes table from database
		c1 = "hadoop fs -rm /" + dbname+ "/"+com[2]
		os.system(c1)	
	else:
		print("Unidentified command")

exit()
