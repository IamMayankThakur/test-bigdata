#!/usr/bin/python3

import sys
#reads query and schema
query = open('/home/chaitra/Apache/hadoop/q.txt','r')
command = query.readline()
com = command.strip().split(' ')
schema = open("/home/chaitra/Apache/hadoop/"+com[3][:-4]+".txt",'r')
schemacont = schema.readlines()
cols = [i.strip().lower() for i in (schemacont[0][1:-4]).split(',')]
types = [i.strip().lower() for i in (schemacont[1][1:-2]).split(',')]
sels = com[1].strip().split(',')
selcol=[]
All = True
Mismatch=False
Error=False
aggregate=False
#check for errors
try:
	if len(sels)>1:
		selcol=[cols.index(i.strip()) for i in sels]
		All = False
	elif (com[1]!='*'):
		selcol = cols.index(sels[0])
		All = False
except ValueError:
	Error=True
if (not Error):
	if "where" in com and com[4]=="where":
		try:
			where = cols.index(com[5])
		except ValueError:
			Error=True
		i=8
		comp = com[7]
		if not Error:
			while(i<len(com) and com[i] != "aggregate_by"):
				comp = comp+" "+com[i]
				i = i+1
			if (types[where]=='integer' or types[where]=='float'):
				try:
					compare=float(comp)
				except ValueError:
					Mismatch=True
	if ("aggregate_by" in com):
		i=4
		aggregate = True
		while (i<len(com) and com[i]!="aggregate_by"):
			i=i+1
		if (i<len(com)):
			agg=com[i+1].strip()
if not Error:
		if (Mismatch) or (("where" in com and types[where] == 'string') and ((com[6]!="=") and (com[6]!="!="))) or (aggregate and ((agg=="count" and (com[1]!='*' and isinstance(selcol,list))) or (agg!="count" and not isinstance(selcol,int)))) or ("where" in com and (com[6]!="=") and (com[6]!="!=") and (com[6]!="<=") and (com[6]!="<") and (com[6]!=">=") and (com[6]!=">")) or (aggregate and (agg!="max") and (agg!="min") and (agg!="count")) or (aggregate and ((agg=="max") or (agg=="min")) and (types[selcol] == 'string')):
			Error=True
for line in sys.stdin:
	if (not Error):
		send = False
		lines = line.split(',')
		#check for where clause cases
		if ("where" in com and (types[where]=='float' or types[where]=='integer')):
			if (com[6]=="="):
				if (float(lines[where]) == float(comp)):
					send = True
			elif (com[6]=="!="):
				if (float(lines[where]) != float(comp)):
					send =True
			elif (com[6]==">"):
				if (float(lines[where]) > float(comp)):
					send =True
			elif (com[6]==">="):
				if (float(lines[where]) >= float(comp)):
					send =True
			elif (com[6]=="<"):
				if (float(lines[where]) < float(comp)):
					send =True
			elif (com[6]=="<="):
				if (float(lines[where]) != float(comp)):
					send =True
		elif (len(com)>=8 and types[where]=='string'):
			if (com[6]=="="):
				if ((lines[where]).lower().strip()) == (comp.strip()):
					send = True
			elif (com[6]=="!="):
				if ((lines[where]).lower().strip()) != (comp.strip()):
					send =True
		else:
			send = True
		if (send):
			if (All):
				print(*lines,sep=',')
			else:
				if isinstance(selcol,list):
					sent = [lines[i] for i in selcol]
					print(*sent,sep=',')
				else:
					print(lines[selcol])
	else:
		print("error")

