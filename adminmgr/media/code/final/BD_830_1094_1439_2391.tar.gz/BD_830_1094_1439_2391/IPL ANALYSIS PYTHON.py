import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
import os

def start_end():
    return int(input("Enter Start Match Range = ")), int(input("Enter End Match Range = "))

def create_csv_files( path ):

    print("There are Following already created csv files,")
    for i in os.listdir( path ):
        print( i )

    print()
    print("So, Please give a diffrent name.")
    print("New Csv file name formate will be, Start Input is 1 and End is 5 then,", end=' ')
    print("Input1, Input2, .., Input5")

    start_match_range, end_match_range = start_end()

    for i in range( start_match_range, end_match_range + 1 ):
        data = pd.read_csv( str(path+'/deliveries.csv' ) )
        data[data['match_id'] == i].to_csv(f'D:\CSE\SEM5\BIG Data\project/Input{i}.csv')

    print("Thank you, Files Created")

def remove_csv_files( path ):
    print("There are Following already created files,")
    for i in os.listdir(path):
        print(i)

    print()
    print("So, Please give a diffrent name.")
    print("New Csv file name formate will be, Start Input is 1 and End is 5 then,", end=' ')
    print("Input1, Input2, .., Input5")

    start_match_range, end_match_range = start_end()

    for i in range(start_match_range, end_match_range + 1):
        os.remove( f'D:\CSE\SEM5\BIG Data\project/Input{i}.csv' )

    print("Thank you, File(s) Remove")

def Display_files( path ):
    return os.listdir(path)


def prob(*path):

    count = 1
    for i in path:
        print("Please, Wait for 10 Second....")
        print( f"Filename = { i }" )
        data = pd.read_csv(i)

        count_team1 = len(data[data['inning'] == 1]['batsman'].unique())
        count_team2 = len(data[data['inning'] == 2]['batsman'].unique())

        unique_batsman_name = data['batsman'].unique()
        unique_bowler_name = data['bowler'].unique()

        unique_bowler_name = list(unique_bowler_name)
        l = len(unique_bowler_name)

        temp_bowler_unique = []

        for i in range(l):
            if (unique_bowler_name[i] not in unique_batsman_name):
                temp_bowler_unique.append(unique_bowler_name[i])

        unique_bowler_name = temp_bowler_unique.copy()
        unique_bowler_name

        players_name = {}

        for i in unique_batsman_name:
            players_name[i] = -1

        for i in unique_bowler_name:
            players_name[i] = -1

        players_name = pd.Series(data=list(players_name.keys()))

        le = LabelEncoder()
        le_player_name = le.fit_transform(players_name)

        new_player_dict = {}

        for i in range(len(players_name)):
            new_player_dict[players_name[i]] = le_player_name[i]

        data['batsman_number'] = data['batsman']
        data['bowler_number'] = data['bowler']

        for i in range(len(data)):
            if (data['batsman'][i] in new_player_dict.keys()):
                data['batsman_number'][i] = new_player_dict[data['batsman'][i]]

            if (data['bowler'][i] in new_player_dict.keys()):
                data['bowler_number'][i] = new_player_dict[data['bowler'][i]]

        team1 = list(data[data['inning'] == 2]['batting_team'].unique())[0]
        team2 = list(data[data['inning'] == 1]['batting_team'].unique())[0]

        team1_run = 0
        team2_run = 0

        x = data.loc[:, ['inning', 'over', 'ball', 'batsman_number', 'bowler_number']]
        y = data.loc[:, 'total_runs']

        km = KMeans(n_clusters=7)
        km.fit(x)

        y_kmeans = km.fit_predict(x)
        runs = list(np.unique(y_kmeans))

        x['k_means_run'] = pd.Series(y_kmeans)
        data['k_means_run'] = pd.Series(y_kmeans)

        y_kmeans = pd.Series(y_kmeans)

        for i in range(len(x)):
            if (data['batting_team'][i] == team1):

                team1_run = team1_run + data['k_means_run'][i] %3
            else:
                team2_run = team2_run + data['k_means_run'][i] %3

        print(f"{team1} scored {team1_run} runs")
        print(f"{team2} scored {team2_run} runs")

        final_msg = ''

        if (team1_run > team2_run):
            final_msg = f"{team1} won the match against {team2} by {team1_run - team2_run} runs"

        elif (team1_run < team2_run):
            final_msg = f"{team2} won the match against {team1} by {team2_run - team1_run} runs"

        else:
            final_msg = f"Match was tied between {team1} and {team2}"

        run_prob = [0, 0, 0, 0, 0, 0, 0]

        for i in y_kmeans:
            run_prob[i] = run_prob[i] + 1

        add = run_prob[0] + run_prob[1] + run_prob[2] + run_prob[3] + run_prob[4] + run_prob[5] + run_prob[6]

        for i in range(len(run_prob)):
            run_prob[i] = run_prob[i] / add

        add = run_prob[0] + run_prob[1] + run_prob[2] + run_prob[3] + run_prob[4] + run_prob[5] + run_prob[6]

        for i in range(len(run_prob)):
            print(f"P( {i} runs ) = {run_prob[i]}")

        print(f"Sum of Probability = {add}")
        print( f"Total Player Played in { team1 } = { count_team1 }" )
        print(f"Total Player Played in {team2} = {count_team2}")

        print(f"Prob( Fall of wickets) in { team1 } = {count_team1/11}")
        print(f"Prob( Fall of wickets ) in { team2 } = {count_team2/11}")

        plt.bar(runs, run_prob, width=0.4, label="Prob(0, 1, .., 6)")  # We are using bar instead of plot.
        plt.xlabel("Runs")
        plt.ylabel("Probability")
        plt.title(f"Graph for Input : {count}, Runs V/s Probability and Output : {final_msg}")
        plt.legend()
        plt.show()
        count = count + 1

while( True ):
    op = int(input("""Choose Option : 1.Create CSV Files, 2. Remove Files, 3.Display Files,
                        4.Predict the Match Outcome, 5.Exit = """))

    if (op == 1):
        create_csv_files("D:\CSE\SEM5\BIG Data\project")

    elif (op == 2):
        remove_csv_files("D:\CSE\SEM5\BIG Data\project")

    elif (op == 3):
        files = Display_files("D:\CSE\SEM5\BIG Data\project")
        print("There are Following already created files,")
        for i in files:
            print(i)

    elif (op == 4):
        files = Display_files("D:\CSE\SEM5\BIG Data\project")
        print("There are Following already created files,")

        for i in files:
            print(i)

        start_match_range, end_match_range = start_end()
        temp = []

        for i in range( start_match_range, end_match_range+1 ):
            file_name = 'Input'+str(i)+'.csv'

            if ( file_name in files):
                prob( str(f"D:\CSE\SEM5\BIG Data\project/{file_name}"))

    elif(op == 5):
        break

    else:
        print("Wrong Selection, Try Again !")
