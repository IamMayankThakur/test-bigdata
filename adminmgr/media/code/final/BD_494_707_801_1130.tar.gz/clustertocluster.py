import pandas as pd
from subprocess import PIPE, Popen

cpairs = pd.read_csv('hdfs://localhost:9000/BigDataClassProject/player_to_player.csv')

del cpairs['batsman']
del cpairs['bowler']

final = cpairs.groupby(['batclustno','bowlclustno']).mean()

print(cpairs.groupby(['1','2']))

final.to_csv('cluster_to_cluster.csv')

hdfs_path='hdfs://localhost:9000/BigDataClassProject'

put = Popen(["hadoop", "fs", "-put", 'cluster_to_cluster.csv', hdfs_path], stdin=PIPE, bufsize=-1)
put.communicate()
