from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
from subprocess import PIPE, Popen

spark = SparkSession.builder.appName('cricket').getOrCreate()

bat_fp = spark.read.csv('hdfs://localhost:9000/BigDataClassProject/batting.csv', header=True, inferSchema=True)
bat_fp = spark.read.csv('hdfs://localhost:9000/BigDataClassProject/batting.csv', header=True, inferSchema=True)
#bat_fp = spark.read.csv('batting.csv', header=True, inferSchema=True)
#bowl_fp = spark.read.csv('bowling.csv', header=True, inferSchema=True)

bat_cols = ['Ave','SR']
bowl_cols = ['Econ','SR']

def clustering(fp, cols):
	assembler = VectorAssembler(inputCols=cols, outputCol='features')
	assembled_data = assembler.transform(fp)
	scaler = StandardScaler(inputCol='features', outputCol='scaledFeatures')

	scaler_model = scaler.fit(assembled_data)
	scaled_data = scaler_model.transform(assembled_data)


	k_means_3 = KMeans(featuresCol='scaledFeatures', k=10) 
	model_k3 = k_means_3.fit(scaled_data)
	model_k3_data = model_k3.transform(scaled_data)

	return model_k3_data

bat_det = clustering(bat_fp, bat_cols)
bowl_det = clustering(bowl_fp, bowl_cols)

new_bat = bat_det.select('Player', 'Prediction')
new_bowl = bowl_det.select('Player', 'Prediction')


new_bat.toPandas().to_csv('bat_clusters.csv',index=False)
new_bat.toPandas().to_csv('bowl_clusters.csv',index=False)

hdfs_path1='hdfs://localhost:9000/BigDataClassProject/Step1'
hdfs_path23='hdfs://localhost:9000/BigDataClassProject/Step23'

put = Popen(["hadoop", "fs", "-put", 'bat_clusters.csv', hdfs_path1], stdin=PIPE, bufsize=-1)
put.communicate()

put = Popen(["hadoop", "fs", "-put", 'bat_clusters.csv', hdfs_path23], stdin=PIPE, bufsize=-1)
put.communicate()

put = Popen(["hadoop", "fs", "-put", 'bowl_clusters.csv', hdfs_path1], stdin=PIPE, bufsize=-1)
put.communicate()

put = Popen(["hadoop", "fs", "-put", 'bowl_clusters.csv', hdfs_path23], stdin=PIPE, bufsize=-1)
put.communicate()

print("\nBATSMEN CLUSTER\n")
new_bat.show(159)

print("\nBOWLERS CLUSTER")
new_bowl.show(159)
