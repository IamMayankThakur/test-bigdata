BigData Class Project - IPL Analysis
Predicting the final scores of an IPL team by using clustering as well collaborative filtering on the data available of the previous matches.

Abstract
We analyse all the IPL matches from the data set that we have obtained, and predict the final score when two teams are given along with the batting, bowling order and which team bats first.

We use two methods to predict the score ball by ball:
Clustering using K-means
Collaborative Filtering

Required software:
Apache Spark
PySpark 
Python 2
Python 3
Hadoop File System

Approach:

Step 1: The dataset that we used from  https://cricsheet.org/. We observed that many Some of the batsman bowler combinations were not present in the data set that we obtained and were leading to some discrepancies while predicting the score. We tried to fix this by clustering the batsmen and bowlers from the match stats that were available. We scrapped the data from the website using BeautifulSoup and stored the data in the HDFS file system. We have then performed clustering using PySpark MLLIB. The clustering was done using the K-Means algorithm. The parameters that we used for clustering were Average and Strike Rate for the batsmen and Economy and Strike Rate for the bowlers.

Step 2: We then obtained the cluster vs cluster statistics for each batsmen bowler pair that was there using some parameters like 0,1,2,3,4,6 runs, not outs and number of balls where they faced each other.

We then simulate the match with the help of ball by ball prediction. To predict the outcome of a ball, we searched for the batsman-bowler combination that we had calculated earlier. We had also calculated a list of cumulative probabilities from the already existing probabilities. The predicted outcome might be 0,1,2,3,4,6 runs or a wicket might fall. We do this for the until the match is over, which occurs either when all the wickets have fallen or the 20 overs are complete.

Step 3: In this method we have used collaborative filtering as one of our algorithms to simulate the match. We simulate the entire match and obtain the final score using the clustering approach as well as the collaborative filtering approach. We then compare the two results that our obtained and find that collaborative filtering approach is more accurate when compared to the clustering algorithm for simulating the match.

Team:
Sai Tarun
Vishnu Manoj
Rohit Menon