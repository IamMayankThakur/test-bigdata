import random
import csv
import pandas as pd
import numpy as np  


team1 = []
team2 = []

bat = pd.read_csv("hdfs://localhost:9000/BigDataClassProject/bat_clusters.csv")
bowl = pd.read_csv("hdfs://localhost:9000/BigDataClassProject/bowl_clusters.csv")
bat_bowl = pd.read_csv("hdfs://localhost:9000/BigDataClassProject/player_cumalative.csv")
batsman_global={}
batsman_unique = bat_bowl.batsman.unique()
for cur_batsman in batsman_unique:
	count=0
	sumval = [0,0,0,0,0,0,0,0]
	average = [0,0,0,0,0,0,0,0]
	
	for index, row in bat_bowl.iterrows():
		if(cur_batsman==row["batsman"]):
			count+=1
			sumval[0]+=row["0"]
			sumval[1]+=row["1"]
			sumval[2]+=row["2"]
			sumval[3]+=row["3"]
			sumval[4]+=row["4"]
			sumval[5]+=row["6"]
			sumval[6]+=row["notout"]
			sumval[7]+=row["balls"]
	
	average[0]=sumval[0]/count
	average[1]=sumval[1]/count
	average[2]=sumval[2]/count
	average[3]=sumval[3]/count
	average[4]=sumval[4]/count
	average[5]=sumval[5]/count
	average[6]=sumval[6]/count
	average[7]=sumval[7]/count
	
	batsman_global[cur_batsman]=average

batsmen = list(bat['Player'])
bowlers = list(bowl['Player'])

newdf = pd.DataFrame(np.zeros((159,159)),columns=batsmen,index=bowlers)
newdf=newdf.astype('object')
count=0
for i in range(len(bat_bowl)): 
	cur_bat=bat_bowl.loc[i,"batsman"]
	cur_bowl=bat_bowl.loc[i,"bowler"]
	l=[bat_bowl.loc[i, "0"],bat_bowl.loc[i, "1"],bat_bowl.loc[i, "2"],bat_bowl.loc[i, "3"],bat_bowl.loc[i, "4"],bat_bowl.loc[i, "6"],bat_bowl.loc[i, "notout"],bat_bowl.loc[i, "balls"]]
	newdf.loc[cur_bat][cur_bowl]=l

with open('hdfs://localhost:9000/BigDataClassProject/squad.csv') as csvFile:
	reader = csv.reader(csvFile)
	next(reader)
	for row in reader:
		team1.append(row[0])
		team2.append(row[1])
csvFile.close()

player_prob = pd.read_csv('hdfs://localhost:9000/BigDataClassProject/player_cumalative.csv')

def playerprob(batsman,bowler):
	row = newdf.loc[batsman][bowler]
	rand = random.random()
	if rand <= float(row[0]):                         
		return 0				    
	elif  rand <= float(row[1]):                     
		return 1
	elif rand <= float(row[2]):
		return 2
	elif rand <= float(row[3]):
		return 3
	elif  rand <= float(row[4]):
		return 4
	elif rand <= float(row[5]):
		return 6
	else:
		return 6
	

def innings1(team1, team2):
	striker = team1[0]
	non_striker = team1[1]
	bowler = team2[len(team2)-1]
	nextbatsman = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	dic = {}
	dic[striker] = 1
	dic[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		while(balls<6 and wick <10):
			if (newdf.loc[striker][bowler]!=0):
				l1=newdf.loc[striker][bowler]
				prob=float(l1[6])
			else:
				mini=1000000
				l2=[]
				for b in batsman_global.keys():
					if b==striker or newdf.loc[b][bowler]==0:
						continue
					else:
						diff=0
						l2=batsman_global[striker]
						l1=newdf.loc[b][bowler]
						for h in range(0,len(l2)):
							diff+=(l2[h]-l1[h])
						if(diff<mini):
							mini=diff
							sim=b
							newdf.loc[striker][bowler]=newdf.loc[b][bowler]
							prob=float(l1[6])
				if(newdf.loc[striker][bowler]==0.0):
					newdf.loc[striker][bowler]=[1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.66666666666666674, 3]
					prob=float(l1[6])
			score = 0
			flag = 0
			nprob = nprob*prob
			dic[striker] = dic[striker]*prob
			if (dic[striker] > 0.5):
				score = playerprob(striker,bowler)
			elif (dic[striker] < 0.5):
				wick = wick+1
				striker = team1[nextbatsman]
				nextbatsman = (nextbatsman+1)%11
				flag = 1
				dic[striker] = 1
			if(flag==0):
				runs = runs+score
				if (score==1 or score == 3):
					striker,non_striker = non_striker,striker
			balls = balls+1
		striker,non_striker = non_striker,striker                 
		bowler = team2[len(team2)-count]                    
		count = (count+1)%5 + 1 
		overs = overs+1
	return runs,wick


def innings2(team1, team2,runs1):
	striker = team1[0]
	non_striker = team1[1]
	bowler = team2[len(team2)-1]
	nextbatsman = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	dic = {}
	dic[striker] = 1
	dic[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		cl = 0
		while(balls<6 and runs<=runs1 and wick <10):
			if (newdf.loc[striker][bowler]!=0.0):
				l1=newdf.loc[striker][bowler]
				prob=float(l1[6])
			else:
				mini=1000000
				l2=[]
				for b in batsman_global.keys():
					if b==striker or newdf.loc[b][bowler]==0:
						continue
					else:
						diff=0
						l2=batsman_global[striker]
						l1=newdf.loc[b][bowler]
						for h in range(0,len(l2)):
							diff+=(l2[h]-l1[h])
						if(diff<mini):
							mini=diff
							sim=b
							newdf.loc[striker][bowler]=newdf.loc[b][bowler]
							prob=float(l1[6])
				if(newdf.loc[striker][bowler]==0.0):
					newdf.loc[striker][bowler]=[1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.66666666666666674, 3]
					prob=float(l1[6])
			score = 0
			flag = 0
			nprob = nprob*prob
			dic[striker] = dic[striker]*prob
			if (dic[striker] > 0.5):
					score = playerprob(striker,bowler)
			elif dic[striker] < 0.5:
				wick = wick+1
				striker = team1[nextbatsman]
				nextbatsman = (nextbatsman+1)%11
				flag = 1
				dic[striker] = 1
			if(flag==0):
				runs = runs+score
				if (score==1 or score == 3):
					striker,non_striker = non_striker,striker
			balls = balls+1
		striker,non_striker = non_striker,striker                 
		bowler = team2[len(team2)-count]                    
		count = (count+1)%5 + 1 
		overs = overs+1
		if (runs>runs1):
			break
	return runs,wick

print("First Innings")
runs1 ,wicks1 = innings1(team1,team2)
print("-----------------------------------\nSecond Innings")
runs2 ,wicks2 = innings2(team2,team1,runs1)
print("\nTeam 1 Score and Wickets : ", runs1, wicks1)
print("Team 2 Score and Wickets : ", runs2, wicks2)
if(runs1 > runs2):
	print("Team 1 Won!!!\n")
elif(runs1 < runs2):
	print("Team 2 Won!!!\n")
else:
	print("Tie")