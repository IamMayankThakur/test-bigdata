from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
from subprocess import PIPE, Popen

spark = SparkSession.builder.appName('cricket').getOrCreate()

bat_bowl = spark.read.csv('hdfs://localhost:9000/BigDataClassProject/player_to_player.csv', header=True, inferSchema=True)
bat_bowl = bat_bowl.withColumn('not out', 1 - bat_bowl['out'])

columns_dropped = ['batclustno', 'bowlclustno','out']
bat_bowl = bat_bowl.drop(*columns_dropped)

bat_bowl = bat_bowl[['batsman','bowler','0','1','2','3','4','6','notout','balls']]

columns=[]
columnName=[]

for i in range(1, 7):
	if(i==5):
		continue
	elif(i==6):
		columns.append(str(i-2))
		
	else:
		columns.append(str(i-1))

	columns.append(str(i))
	columnName.append(str(i))

	bat_bowl = bat_bowl.withColumn(columnName[0], sum(bat_bowl[column] for column in columns))

	columns.clear()
	columnName.clear()

bat_bowl.toPandas().to_csv('player_cumalative.csv',index=False)

hdfs_path='hdfs://localhost:9000/BigDataClassProject'

put = Popen(["hadoop", "fs", "-put", 'player_cumalative.csv', hdfs_path], stdin=PIPE, bufsize=-1)
put.communicate()