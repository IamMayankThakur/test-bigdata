from bs4 import BeautifulSoup as soup
import csv
import pandas as pd
from subprocess import PIPE, Popen

bat_arr = [['Player', 'Mat', 'Inns', 'NO', 'Runs', 'HS', 'Ave', 'BF', 'SR', '100', '50', '0', '4s', '6s']]
bowl_arr = [['Player', 'Mat', 'Inns', 'Overs', 'Mdns', 'Runs', 'Wkts', 'BBI', 'Ave', 'Econ', 'SR', '4', '5']]

def duplicate(fn, res, row_arr):
    df = pd.DataFrame(row_arr)
    #print(df)
    #print (res)
    for dup in res:
        if(dup[0] not in df[0].values.tolist()):
    	    row_arr.append(dup)
    	    df = pd.DataFrame(row_arr)

def scraper(lp, fn, row_arr):
    page = soup(open(lp, 'rb').read(), "html.parser")
    rows=page.find_all('tr')
    res=[]
    l=[]
    for row in rows:
        #print(row)
        cols=row.find_all('td')
        #print(cols)
        cols=[x.text.strip().replace('-', '0') for x in cols]
        res.append(cols)
        #print(res)

    for i in res:
        #print(i)
        if len(i)<13:
            l.append(i)

    for i in l:
        res.remove(i)
    #print(res)
    duplicate(fn, res, row_arr)

    for cur_res in res:
        if cur_res[[0][0]]=="NM Coulter0Nile":
            cur_res[[0][0]]='NM Coulter-Nile'

    #print(res[0][0][0])

def writer(fn, row_arr):
    with open(fn, 'w') as myFile:
        writer = csv.writer(myFile)
        for r in row_arr:
            writer.writerow(r)
        myFile.close()

filename="hdfs://localhost:9000/BigDataClassProject/batsman.html"
f="batting.csv"
scraper(filename,f, bat_arr)
writer(f, bat_arr)

filename1="hdfs://localhost:9000/BigDataClassProject/bowler.html"
f1="bowling.csv"
scraper(filename1,f1, bowl_arr)
writer(f1, bowl_arr)

hdfs_path='hdfs://localhost:9000/BigDataClassProject'

put = Popen(["hadoop", "fs", "-put", 'batting.csv', hdfs_path], stdin=PIPE, bufsize=-1)
put.communicate()

put = Popen(["hadoop", "fs", "-put", 'bowling.csv', hdfs_path], stdin=PIPE, bufsize=-1)
put.communicate()
