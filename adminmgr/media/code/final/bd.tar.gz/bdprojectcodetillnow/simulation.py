import sys
import csv
from math import sqrt
import random
import bisect
import time

pvp = dict()
batclusters = dict()
bowlclusters = dict()
clusterprob = dict()
wicketprob = dict()
with open('/home/kishan/Desktop/Project/Newstuff/bowlclusters.csv','rt')as a:
	data = csv.reader(a)
	for row in data:
		name = row[0].strip("'")
		c = row[1]
		bowlclusters[name] = c
a.close()
with open('/home/kishan/Desktop/Project/Newstuff/batclusters.csv','rt')as b:
	data = csv.reader(b)
	for row in data:
		name = row[0].strip("'")
		c = row[1]
		batclusters[name] = c
b.close()
with open('/home/kishan/Desktop/Project/Newstuff/pvp.csv','rt')as c:
	data = csv.reader(c)
	for row in data:
		bat = row[0].strip()
		bowl = row[1].strip()
		prob = list(map(float,row[2:]))
		for i in range(1,7):
			prob[i] = prob[i-1]+prob[i]
		if bat not in list(pvp.keys()):
			pvp[bat] = dict()
		pvp[bat][bowl] = prob
c.close()
with open('/home/kishan/Desktop/Project/Newstuff/clustprob.csv','rt')as d:
	data = csv.reader(d)
	for row in data:
		bid = row[0]
		bowlid = row[1]
		prob = list(map(float,row[2:]))
		for i in range(1,7):
			prob[i] = prob[i-1]+prob[i]
		if bid not in list(clusterprob.keys()):
			clusterprob[bid] = dict()
		clusterprob[bid][bowlid] = prob
d.close()
#print(batclusters)
#print(bowlclusters)
#print(pvp)
#print(clusterprob)
def predictruns(batsman,bowler):
	if (batsman not in list(pvp.keys())):
		batid = batclusters[batsman].strip()
		bowlid = bowlclusters[bowler].strip()
		prob = clusterprob[batid][bowlid][:7]
		rand = random.random()
		runs = bisect.bisect(prob,rand)
		return runs
	else:	
		if (bowler not in list(pvp[batsman].keys())):
			batid = batclusters[batsman].strip()
			bowlid = bowlclusters[bowler].strip()
			prob = clusterprob[batid][bowlid][:7]
			rand = random.random()
			runs = bisect.bisect(prob,rand)
			return runs
		else:
			prob = pvp[batsman][bowler][:7]
			balls = int(pvp[batsman][bowler][-1])
			if balls>6: 
				rand = random.random()
				runs = bisect.bisect(prob,rand)
				return runs
			else:
				batid = batclusters[batsman].strip()
				bowlid = bowlclusters[bowler].strip()
				prob = clusterprob[batid][bowlid][:7]
				rand = random.random()
				runs = bisect.bisect(prob,rand)
				return runs

def predictwicket(batsman):
	wp = wicketprob[batsman]
	if wp < 0.5:
		return 1
	else:
		return 0 

def updatewicketprob(batsman,bowler):
	if batsman not in list(wicketprob.keys()):
		if (batsman not in list(pvp.keys())):
			batid = batclusters[batsman].strip()
			bowlid = bowlclusters[bowler].strip()
			wp = 1-clusterprob[batid][bowlid][-2]
			wicketprob[batsman] = wp
		else:
			if (bowler not in list(pvp[batsman].keys())):
				batid = batclusters[batsman].strip()
				bowlid = bowlclusters[bowler].strip()
				wp = 1-clusterprob[batid][bowlid][-2]
				wicketprob[batsman] = wp
			else:
				balls = int(pvp[batsman][bowler][-1])
				if balls>4: 
					wicketprob[batsman] = 1-pvp[batsman][bowler][-2]
				else:
					batid = batclusters[batsman].strip()
					bowlid = bowlclusters[bowler].strip()
					wp = 1-clusterprob[batid][bowlid][-2]
					wicketprob[batsman] = wp
	else:
		if (batsman not in list(pvp.keys())):
			batid = batclusters[batsman].strip()
			bowlid = bowlclusters[bowler].strip()
			wp = 1-clusterprob[batid][bowlid][-2]
			wicketprob[batsman] = wicketprob[batsman] * wp
		else:
			if (bowler not in list(pvp[batsman].keys())):
				batid = batclusters[batsman].strip()
				bowlid = bowlclusters[bowler].strip()
				wp = 1-clusterprob[batid][bowlid][-2]
				wicketprob[batsman] = wicketprob[batsman] * wp
			else:
				balls = int(pvp[batsman][bowler][-1])
				if balls>4: 
					wp = 1-pvp[batsman][bowler][-2]
					wicketprob[batsman] = wicketprob[batsman] * wp
				else:
					batid = batclusters[batsman].strip()
					bowlid = bowlclusters[bowler].strip()
					wp = 1-clusterprob[batid][bowlid][-2]
					wicketprob[batsman] = wicketprob[batsman] * wp

def printscore(runs,bon,bowler,balls,tr,w):
	over = balls//6
	ball = balls%6
	b = str(over)+'.'+str(ball)
	if runs == -1:
		print(b,"\tWICKET - ",bon,' bowled by ',bowler)
	else:
		print(b,"\t",str(tr)+'/'+str(w)+'\t',bon,' scored ',runs,' bowled by ',bowler)

#team1batorder = ['RG Sharma','E Lewis','Ishan Kishan','SA Yadav','HH Pandya','KH Pandya','KA Pollard','M Markande','MJ McClenaghan','Mustafizur Rahman','JJ Bumrah']
#team2bowlorder = ['DL Chahar','SR Watson','DL Chahar','SR Watson','DL Chahar','SR Watson','Harbhajan Singh','RA Jadeja','Harbhajan Singh','MA Wood','Imran Tahir','DJ Bravo','SR Watson','MA Wood','Imran Tahir','DJ Bravo','MA Wood','DJ Bravo','MA Wood','DJ Bravo']
#team2batorder = ['SR Watson', 'AT Rayudu', 'SK Raina', 'KM Jadhav', 'MS Dhoni', 'RA Jadeja','DJ Bravo','DL Chahar', 'Harbhajan Singh','MA Wood','Imran Tahir']
#team1bowlorder = ['MJ McClenaghan','Mustafizur Rahman','JJ Bumrah','HH Pandya','MJ McClenaghan','HH Pandya','M Markande','JJ Bumrah','M Markande','HH Pandya','M Markande','Mustafizur Rahman','M Markande','Mustafizur Rahman','MJ McClenaghan','JJ Bumrah','HH Pandya','MJ McClenaghan','JJ Bumrah','Mustafizur Rahman']
team1batorder = ['DA Warner','S Dhawan','MC Henriques','Yuvraj Singh','DJ Hooda','BCJ Cutting','NV Ojha','Bipul Sharma','B Kumar','BB Sran','Mustafizur Rahman']
team2bowlorder = ['S Aravind','CH Gayle','S Aravind','CH Gayle','SR Watson','CH Gayle','YS Chahal','Iqbal Abdulla','YS Chahal','CJ Jordan','SR Watson','CJ Jordan','YS Chahal','S Aravind','YS Chahal','S Aravind','CJ Jordan','SR Watson','CJ Jordan','SR Watson']
team2batorder = ['CH Gayle','V Kohli','AB deVilliers','KL Rahul','SR Watson','Sachin Baby','STR Binny','CJ Jordan','Iqbal Abdulla','S Aravind','YS Chahal']
team1bowlorder = ['B Kumar','BB Sran','B Kumar','BB Sran','BCJ Cutting','Mustafizur Rahman','MC Henriques','BCJ Cutting','MC Henriques','Mustafizur Rahman','BCJ Cutting','Bipul Sharma','BB Sran','Bipul Sharma','MC Henriques','BCJ Cutting','Mustafizur Rahman','B Kumar','Mustafizur Rahman','B Kumar']
def innings1(batorder,bowlorder):
	wickets = 0
	balls = 0
	bon = batorder[0]
	bnon = batorder[1]
	bowler = bowlorder[0]
	i=2
	j=1
	totalruns=0
	while(wickets<10 and balls<120):
		time.sleep(0.1)
		#print(i,wickets)
		balls += 1
		updatewicketprob(bon,bowler)
		if predictwicket(bon):
			wickets+=1
			printscore(-1,bon,bowler,balls,totalruns,wickets)
			if wickets == 10:
				continue
			i+=1
			bon = batorder[i-1]
		else:
			runs=predictruns(bon,bowler)
			totalruns += runs
			printscore(runs,bon,bowler,balls,totalruns,wickets)
			if(runs%2 == 1):
				bon,bnon = bnon,bon
		if(balls%6==0):
			bon,bnon = bnon,bon
			j+=1
			if balls == 120:
				continue
			bowler = bowlorder[j-1]
	return totalruns,wickets,balls

def innings2(batorder,bowlorder,target):
	wickets = 0
	balls = 0
	bon = batorder[0]
	bnon = batorder[1]
	bowler = bowlorder[0]
	i=2
	j=1
	totalruns=0
	while(wickets<10 and balls<120 and totalruns<=target):
		time.sleep(0.1)
		balls += 1
		updatewicketprob(bon,bowler)
		if predictwicket(bon):
			wickets+=1
			printscore(-1,bon,bowler,balls,totalruns,wickets)
			if wickets == 10:
				continue
			i+=1
			bon = batorder[i-1]
		else:
			runs=predictruns(bon,bowler)
			totalruns += runs
			printscore(runs,bon,bowler,balls,totalruns,wickets)
			if(runs%2 == 1):
				bon,bnon = bnon,bon
		if(balls%6==0):
			bon,bnon = bnon,bon
			j+=1
			if balls == 120:
				continue	
			bowler = bowlorder[j-1]
	return totalruns,wickets,balls

in1runs,in1wickets,in1balls = innings1(team1batorder,team2bowlorder)
print("End of innings1, score = ",str(in1runs)+'/'+str(in1wickets)," in ",str(in1balls//6)+'.'+str(in1balls%6)+' overs')
in2runs,in2wickets,in2balls = innings2(team2batorder,team1bowlorder,in1runs)
print("End of innings2, score = ",str(in2runs)+'/'+str(in2wickets)," in ",str(in2balls//6)+'.'+str(in2balls%6)+' overs')
if(in2runs > in1runs):
	print("Team 2 wins!")
else:
	print('Team 1 wins!')



