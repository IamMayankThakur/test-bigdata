from __future__ import print_function
import ast
import re
import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf
from operator import itemgetter
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
import random
import findspark

findspark.init()

conf=SparkConf()
conf.setAppName("BigData")
sc=SparkContext(conf=conf)


def sortSecond(val):
    print(type(val[1]))
    return val[1]

if __name__ == "__main__":

    # Initialize the spark context.
    spark = SparkSession\
        .builder\
        .appName("BigData")\
        .getOrCreate()

    team1 = spark.read.text("/BD_Order/csk.txt").rdd.map(lambda r : r[0])
    team2 = spark.read.text("/BD_Order/rcb.txt").rdd.map(lambda r : r[0])

    data = [("",0)]
    emp_val = sc.parallelize(data)

    team1 = list(team1.collect())
    team2 = list(team2.collect())

    
    data_schema = [StructField('name', StringType(), True),StructField('runs', StringType(), True)]
    final_struc = StructType(fields=data_schema)
    df_batsman = spark.read.csv('/BD_Batsman/*.csv', schema=final_struc)
    df_bowler = spark.read.csv('/BD_Bowler/*.csv',schema=final_struc)
    df_pairs = spark.read.csv('/BD_pairs/*.csv',schema = final_struc)
    #df_batsman.show()
    #df_bowler.show()
    #df_pairs.show()
    #df_batsman.filter(df_batsman.name == "F du Plessis").select('runs').show()
    batsman_name = "PJ Moor"
    bowler_name  = "AR Patel"
    name = "(\'"+batsman_name+"\', \'"+bowler_name+"\')"

    

    runs_batsman = [0,0,0,0,0,0,0,0,0,0,0]
    i = 1
    j = 0
    wickets = [1,1]
    batsman = [team1[i-1],team1[i]]
    total_runs = 0
    total_wick = 0
    over_count = 0
    while(over_count<20 and i<len(team1)):
        k = 0
        print("Bowler %s"%(team2[j]))
        for k in range(6):
            bowler = team2[j]
            #print("Bowler %s"%(bowler))
            name = "(\'"+batsman[0]+"\', \'"+bowler+"\')"
            try:
                runs_f = df_pairs.filter(df_pairs.name == name).select('runs').collect()[0][0]
                runs_f.sort(key=lambda x:x[0])
                flag = 0
                for x in runs_f:
                    if(x[0]==7):
                        flag = 1

                if(flag==0):
                    runs_f.append((7,0))
                runs_f.sort(key=lambda x:x[0])
                runs = runs_f[0:len(runs_f)-1]
                wickets[0] = wickets[0]*(1-runs_f[-1][1])
                if(wickets[0]>0.5):
                #print(runs)
                    run_rand = random.uniform(0,1)
                    g = 0
                    while(run_rand>runs[g][1] and g<len(runs)-1):
                        g+=1
                    run = runs[g][0]
                    print(runs)
                    if(runs%2!=0):
                        batsman = [batsman[1],batsman[0]]
                        wickets = [wickets[1],wickets[0]]
                else:
                    print("OUT!")
                    i+=1
                    if(i<12):
                        print("Batsman switched is",team1[i])
                        batsman = [team1[i],batsman[1]]
                        wickets = [1,wickets[1]]
                        total_wick+=1
                

            except:
                file2 = open("dictionary","r")
                dictionary = file2.read()
                indexes =  ast.literal_eval(dictionary)
                sameModel0 = MatrixFactorizationModel.load(sc, "model0")
                sameModel1 = MatrixFactorizationModel.load(sc, "model1")
                sameModel2 = MatrixFactorizationModel.load(sc, "model2")
                sameModel3 = MatrixFactorizationModel.load(sc, "model3")
                sameModel4 = MatrixFactorizationModel.load(sc, "model4")
                sameModel5 = MatrixFactorizationModel.load(sc, "model5")
                sameModel6 = MatrixFactorizationModel.load(sc, "model6")   
                runs1_f = ast.literal_eval(df_bowler.filter(df_bowler.name == bowler).select('runs').collect()[0][0])
                runs1_f.sort(key = lambda x:x[0])
                runs2_f = ast.literal_eval(df_batsman.filter(df_batsman.name == batsman[0]).select('runs').collect()[0][0])
                runs2_f.sort(key = lambda x:x[0])
                runs1 = runs1_f[0:len(runs1_f)-1]
                #print("runs1",runs1)
                runs2 = runs2_f[0:len(runs1_f)-1]
                wickets[0] = wickets[0]*(1-runs1_f[-1][1])
                #print("threshold:",wickets[0])
                if(wickets[0]>0.8):
                    m = 0
                    n = 0
                    runs = []
                
                    for m in range(7):
                        count = 0
                        for n in runs1:
                            if(m!=n[0]):
                                count+=1
                        if(count==len(runs1)):
                            runs1.append((m,0))
                    runs1.sort(key = lambda x:x[0])
                    m = 0
                    for m in range(7):
                        count = 0
                        for n in runs2:
                            if(m!=n[0]):
                                count+=1
                        if(count==len(runs2)):
                            runs2.append((m,0))
                    runs2.sort(key = lambda x:x[0])
                    out = []
                    for n in range(len(runs1)):
                        p = runs1[n][1]*runs2[n][1]
                        out.append([runs1[n][0],p])
                    n = 0
                
                    for n in range(1,len(out)):
                        out[n][1]+=out[n][1]+out[n-1][1]
                    n = 0    
                    for n in out:
                        n[1] = round(n[1],4)
                    #print(out)
                    run_rand = random.uniform(0,0.7)
                    a = 0
                
                    while(run_rand>out[a][1] and a<len(out)-1):
                        a+=1
                    run = out[a][0]
                    total_runs+=run
                    print("batsman:%s run:%d"%(batsman[0],run))
                    if(run%2!=0):
                        batsman = [batsman[1],batsman[0]]
                        wickets = [wickets[1],wickets[0]]
                else:
                    i+=1
                    if(i<=11):
                        print("OUT! %s"%(batsman[0]))
                        print("Batsman switched is ",team1[i])
                        batsman = [team1[i],batsman[1]]
                        wickets = [1,wickets[1]]
                        total_wick+=1
                  
        print("%d/%d"%(total_runs,total_wick))        
        j+=1
        j = j%4
        over_count+=1
        batsman = [batsman[1],batsman[0]]
        
        print("New Batting order",batsman)
        print("#################OVER CHANGE#####################")
    #os.system("final4.py")


spark.stop()
