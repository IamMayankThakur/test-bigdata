from __future__ import print_function

import re
import sys
from operator import add

from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf

from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType

import findspark
findspark.init()

conf=SparkConf()
conf.setAppName("BigData")
sc=SparkContext(conf=conf)

def group(x):
    if(x.split(",")[0]=="ball"):
        #print("Wicket status",x.split(",")[9])
        if(x.split(",")[9]=="\"\""):
            #print("Inside if")
            return ((x.split(",")[6],int(x.split(",")[7])),1)
        else:
            #print("Inside else")
            return ((x.split(",")[6],7),1)
    else:
        return ("",1)

def group_2(x):
    t = x[0]
    #print(type(t), len(t))
    '''
    for i in range(len(x[0])):
        print(i)
    '''
    return (x[0][0],(x[0][1],x[1]))
        
    


def computeContribs(x,urls, rank):
    num_urls = len(urls)
    for url in urls:
        yield (url,rank / num_urls)

def get_lines(lines):
    if(lines.split(",")[0]=="ball"):
        if(lines.split(",")[9]=="\"\""):
            return (lines.split(",")[6],(int(lines.split(",")[7]),1))
        else: 
            return (lines.split(",")[6],(int(lines.split(",")[7]),1))
    else:
        return ("",0)

def balls(lines):
    if(lines.split(",")[0]=="ball"):
        return (lines.split(",")[4],1)
    else:
        return ("",1)

def k_means_mapper1(x,centroids):
    min_c = 0
    min_diff = 100
    min_i = 0
    for i in range(len(centroids)):
        #print(i)
        #print("curr centroid",x[1][0])
        if(abs(x[1][0]-centroids[i][1][0])<min_diff):
            min_diff = abs(x[1][0]-centroids[i][1][0])
            min_c = centroids[i][1][0]
            min_i = i
    return (min_i,(x[1][0],x[0],x[1][1],min_c))

def k_means_mapper2(x,centroids):
    min_c = 0
    min_diff = 100
    min_i = 0
    for i in range(len(centroids)):
        if(abs(x[1][0]-centroids[i][1])<min_diff):
            min_diff = abs(x[1][0]-centroids[i][1])
            min_c = centroids[i]
            min_i = centroids[i][0]
    return (min_i,(x[1][0],x[0],x[1][1],min_c))

def new_cent(x):
    sum1 = 0
    count = 0
    #print("x[1] is: ",x[1])
    for i in x[1]:
        #print(i)
        sum1+=i[0]
        count+=1
    return(x[0],sum1/count)

def avg_wickets(x,y):
    return (x[0]+y[0],x[1]+y[1])

def calc(list1,x):
    list2 = []
    for i in range(len(list1)):
         y = list1[i][1]/x
         z = (list1[i][0],y)
         list2.append(z)
    return (list2)

def total_balls(x):
    sum1 = 0
    for i in x[1][2]:
       sum1+=i[1]
    return(x[0],sum1)

def probs(x):
    sum1 = 0
    for i in x[1]:
         sum1+=i[1]
    print(sum1)
    out = []
    for i in x[1]:
       a = (i[0],i[1]/sum1)
       out.append((a))
    return (x[0],out)
    """out = []
    out2 = []
    ls = x[1][1]
    d = x[1][2]
    sum1 = 0
    for i in ls:
       out.append((i[0],i[1]/d))
       print(i[1])
    for j in out:
       if(j[0]!=7):
          sum1+=j[1]
    for k in out:
       if(k[0]!=7):
         out2.append((k[0],k[1]/sum1))
       else:
         out2.append((k[0],k[1]))
    return (x[0],(x[1][0],str(out2)))"""

        

if __name__ == "__main__":

    # Initialize the spark context.
    spark = SparkSession\
        .builder\
        .appName("BigData")\
        .getOrCreate()

    lines = spark.read.text("inferno.csv").rdd.map(lambda r: r[0])
    data = [("",0)]
    emp_val = sc.parallelize(data)
    ###################################################################################################
    wickets = lines.map(lambda x: get_lines(x)).cache()
    wickets_agg = wickets.groupByKey().cache()
    num_wickets = wickets.subtractByKey(emp_val).reduceByKey(lambda x,y:avg_wickets(x,y)).cache()
    avg_wickets  =num_wickets.map(lambda x:(x[0],x[1][0]/x[1][1]))
    ###################################################################################################
    #Use this part only
    run_prob = lines.map(lambda x:group(x)).reduceByKey(add).cache()
    run_prob2 = run_prob.subtractByKey(emp_val).map(lambda x:group_2(x)).groupByKey().mapValues(list).cache()
    avg_wickets = avg_wickets.join(run_prob2).cache()
    centroids = avg_wickets.take(10)
    mapper = avg_wickets.map(lambda x:k_means_mapper1(x,centroids)).cache()
    centroids1 = mapper.groupByKey().map(lambda x:new_cent(x)).cache().take(10)
    #centroids1 = mapper.groupByKey().cache()
    
    stop = 0
    while(stop==0):
        #s_of_e = 0
        count = 0
        print(len(centroids))
        print(len(centroids1))
        for i in range(len(centroids)):
            try:
                print("Error: ",abs(centroids[i][1][0] - centroids1[i][1]))
                if(abs(centroids[i][1][0] - centroids1[i][1])<=0.01):
                    count+=1
            except:
                print("Error: ",abs(centroids[i][1] - centroids1[i][1]))
                if(abs(centroids[i][1] - centroids1[i][1])<=0.001):
                    count+=1
        print("Count:",count)
        if(abs(count)>=8):
                stop = 1
                mapper1 = avg_wickets.map(lambda x:k_means_mapper2(x,centroids1)).cache()
        else:
                out = [0,0,0,0,0,0,0,0,0,0]
                out[:len(centroids1)] = centroids1
                centroids = out
                mapper1 = avg_wickets.map(lambda x:k_means_mapper2(x,centroids1)).cache()
                #mapper1.foreach(print)
                counts = mapper1.map(lambda x:(total_balls(x))).reduceByKey(add).cache()
                #counts.foreach(print)
                centroids1 = mapper1.groupByKey().map(lambda x:new_cent(x)).cache().take(10)
                print("True length: ",len(centroids1))
    
    #print(centroids1)
    mapper3 = mapper1.join(counts).cache()
    #mapper3.foreach(print)
    mapper4 = mapper3.map(lambda x:(x[1][0][1],calc(x[1][0][2],x[1][1]))).cache()
    #mapper4.foreach(print)
    mapper5 = mapper4.map(lambda x:probs(x)).cache()
    mapper5.foreach(print)
    mapper2 = mapper5.map(lambda x:(x[0],str(x[1]))).cache()
    print("Count:")
    print(mapper2.count())
    df = mapper2.toDF()
    df = df.toDF('bowler_name','run_wicket_prob')
    df.write.save('~/BD_Bowler', format='csv', mode='append')

spark.stop()


