from __future__ import print_function

import re
import sys
from operator import add

from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf

from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType

import findspark
findspark.init()

from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating

conf=SparkConf()
conf.setAppName("BigData")
sc=SparkContext(conf=conf)

def group(x):
    if(x.split(",")[0]=="ball"):
    	return ((x.split(",")[4],int(x.split(",")[7])),1)
    else:
        return ("",1)

def group_2(x):
    t = x[0]
    #print(type(t), len(t))
    '''
    for i in range(len(x[0])):
        print(i)
    '''
    return (x[0][0],(x[0][1],x[1]))

def group_n(x):
    if(x.split(",")[0]=="ball"): 
        if(x.split(",")[9]=="\"\""):
    	    return (((x.split(",")[4],x.split(",")[6]),int(x.split(",")[7])),1)
        else:
            return (((x.split(",")[4],x.split(",")[6]),7),1)
    else:
        return ("",1)        
    


def computeContribs(x,urls, rank):
    num_urls = len(urls)
    for url in urls:
        yield (url,rank / num_urls)

def get_lines(lines):
    if(lines.split(",")[0]=="ball"):
        return (lines.split(",")[4],(int(lines.split(",")[7])))
    else:
        return ("",0)

"""def get_lines2(lines):
    if(lines.split(",")[0]=="ball"):
        return ((lines.split(",")[4],lines.split(",")[6]),(int(lines.split(",")[7])))
    else:
        return ("",0)"""

def balls(lines):
    if(lines.split(",")[0]=="ball"):
        return (lines.split(",")[4],1)
    else:
        return ("",1)

def balls_n(lines):
    if(lines.split(",")[0]=="ball"):
        return ((lines.split(",")[4],lines.split(",")[6]),1)
    else:
        return ("",1)

def k_means_mapper1(x,centroids):
    min_c = 0
    min_diff = 100
    min_i = 0
    for i in centroids:
        #print(i)
        if(abs(x[1][0]-i[1][0])<min_diff):
            min_diff = abs(x[1][0]-i[1][0])
            min_c = i[1][0]
            min_i = centroids.index(i)
    return (min_i,(x[1][0],x[0],x[1][1],min_c))

def k_means_mapper2(x,centroids):
    min_c = 0
    min_diff = 100
    min_i = 0
    for i in centroids:
        if(abs(x[1][0]-i)<min_diff):
            min_diff = abs(x[1][0]-i)
            min_c = i
            min_i = centroids.index(i)
    return (min_i,(x[1][0],x[0],x[1][1],min_c))

def new_cent(x):
    sum1 = 0
    count = 0
    #print("x[1] is: ",x[1])
    for i in x[1]:
        #print(i)
        sum1+=i[0]
        count+=1
    return(sum1/count)

def calc(list1,x):
    list2 = []
    for i in range(len(list1)):
         y = list1[i][1]/x
         z = (list1[i][0],y)
         list2.append(z)
    return (list2)
        
def calc_cum(list1):
     list1.sort(key = lambda x: x[0]) 
     x = 0
     list2 = []
     for i in range(len(list1)):
         x+=list1[i][1]
         y = (list1[i][0],x)
         list2.append(y)
     return (list2)

def prob_0(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==0):
             return list1[i][1]

def prob_1(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==1):
             return list1[i][1]

def prob_2(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==2):
             return list1[i][1]

def prob_3(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==3):
             return list1[i][1]

def prob_4(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==4):
             return list1[i][1]

def prob_5(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==5):
             return list1[i][1]

def prob_6(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==6):
             return list1[i][1]

def prob_7(list1):
    list1.sort(key = lambda x: x[0]) 
    for i in range(len(list1)):
        if(list1[i][0]==7):
             return list1[i][1]



if __name__ == "__main__":

    # Initialize the spark context.
    spark = SparkSession\
        .builder\
        .appName("BigData")\
        .getOrCreate()

    lines = spark.read.text("Abhorrent vista.csv").rdd.map(lambda r: r[0])
    data = [("",0)]
    emp_val = sc.parallelize(data)
    ###################################################################################################
    runs = lines.map(lambda x: get_lines(x)).cache()
    run_agg = runs.groupByKey().cache()
    num_runs = runs.reduceByKey(add).subtractByKey(emp_val).cache()
    ###################################################################################################
    #Use this part only
    run_prob = lines.map(lambda x:group(x)).reduceByKey(add).cache()
    run_prob2 = run_prob.subtractByKey(emp_val).map(lambda x:group_2(x)).groupByKey().mapValues(list).cache()

    #run_prob2.foreach(print)
    
    #FINAL      
    num_runs = num_runs.join(run_prob2).cache()
    balls = lines.map(lambda x:balls(x)).subtractByKey(emp_val).cache()
    num_balls = balls.reduceByKey(add).cache()
    num_runs = num_runs.join(num_balls).cache()
    #num_runs.foreach(print)
    new_d = num_runs.map(lambda x:(x[0],((x[1][0][0]/x[1][1]),x[1][0][1]))).cache()

    pairs = lines.map(lambda x: get_lines(x)).cache()
    run_agg1 = pairs.groupByKey().cache()
    num_runs1 = pairs.reduceByKey(add).subtractByKey(emp_val).cache()
    run_prob3 = lines.map(lambda x:group_n(x)).reduceByKey(add).cache()
    run_prob4 = run_prob3.subtractByKey(emp_val).map(lambda x:group_2(x)).groupByKey().mapValues(list).cache()
    balls = lines.map(lambda x:balls_n(x)).subtractByKey(emp_val).cache()
    num_balls = balls.reduceByKey(add).cache()
    num_pairs = run_prob4.join(num_balls)
    num_probs = num_pairs.map(lambda x:(x[0],calc(x[1][0],x[1][1])))
    num_probs_cum = num_probs.map(lambda x:(x[0],calc_cum(x[1])))
    



    num_probs_cumbat = num_probs.map(lambda x:x[0][0])
    num_probs_cumbat.collect() 
    num_probs_cumball = num_probs.map(lambda x:x[0][1]) 
    num_probs_pair = num_probs_cumbat.union(num_probs_cumball)
    unique_pairs_list = list(set(num_probs_pair.collect()))
    #print(unique_pairs_list)
    print(len(unique_pairs_list))
    indexes = {}
    for key,name in enumerate(unique_pairs_list):
          indexes[name] = key

    file1 = open("dictionary","w") 
    file1.write(str(indexes))
    file1.close()
    #print(indexes)





    
    #type of ball:0
    num_probs_raw0 = num_probs.map(lambda x:(x[0],prob_0(x[1])))
    num_probs0 = num_probs_raw0.filter(lambda x: x[1]!=None)
    
    pairs0 = num_probs0.keys().collect()
    unique_set0 = set()
    for i in pairs0:
        unique_set0.add(i[0])
        unique_set0.add(i[1])
    unique_list0 = list(unique_set0)
    indexes0 = {}
    for key,name in enumerate(unique_list0):
           indexes0[name]=key
    final_list0 = []
    pairs_list0 = num_probs0.collect()
    for i in pairs_list0:
         final_list0.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd0 = sc.parallelize(final_list0)


    #type of ball:1
    num_probs_raw1 = num_probs.map(lambda x:(x[0],prob_1(x[1])))
    num_probs1 = num_probs_raw1.filter(lambda x: x[1]!=None)
    
    pairs1 = num_probs1.keys().collect()
    unique_set1 = set()
    for i in pairs1:
        unique_set1.add(i[0])
        unique_set1.add(i[1])
    unique_list1 = list(unique_set1)
    indexes1 = {}
    for key,name in enumerate(unique_list1):
           indexes1[name]=key
    final_list1 = []
    pairs_list1 = num_probs1.collect()
    for i in pairs_list1:
         final_list1.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd1 = sc.parallelize(final_list1)





    #type of ball:2
    num_probs_raw2 = num_probs.map(lambda x:(x[0],prob_2(x[1])))
    num_probs2 = num_probs_raw2.filter(lambda x: x[1]!=None)
    
    pairs2 = num_probs2.keys().collect()
    unique_set2 = set()
    for i in pairs2:
        unique_set2.add(i[0])
        unique_set2.add(i[1])
    unique_list2 = list(unique_set2)
    indexes2 = {}
    for key,name in enumerate(unique_list2):
           indexes2[name]=key
    final_list2 = []
    pairs_list2 = num_probs2.collect()
    for i in pairs_list2:
         final_list2.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd2 = sc.parallelize(final_list2)



    #type of ball:3
    num_probs_raw3 = num_probs.map(lambda x:(x[0],prob_3(x[1])))
    num_probs3 = num_probs_raw3.filter(lambda x: x[1]!=None)
    
    pairs3 = num_probs3.keys().collect()
    unique_set3 = set()
    for i in pairs3:
        unique_set3.add(i[0])
        unique_set3.add(i[1])
    unique_list3 = list(unique_set3)
    indexes3 = {}
    for key,name in enumerate(unique_list3):
           indexes3[name]=key
    final_list3 = []
    pairs_list3 = num_probs3.collect()
    for i in pairs_list3:
         final_list3.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd3 = sc.parallelize(final_list3)


    #type of ball:4
    num_probs_raw4 = num_probs.map(lambda x:(x[0],prob_4(x[1])))
    num_probs4 = num_probs_raw4.filter(lambda x: x[1]!=None)
    
    pairs4 = num_probs4.keys().collect()
    unique_set4 = set()
    for i in pairs4:
        unique_set4.add(i[0])
        unique_set4.add(i[1])
    unique_list4 = list(unique_set4)
    indexes4 = {}
    for key,name in enumerate(unique_list4):
           indexes4[name]=key
    final_list4 = []
    pairs_list4 = num_probs4.collect()
    for i in pairs_list4:
         final_list4.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd4 = sc.parallelize(final_list4)



    #type of ball:5
    num_probs_raw5 = num_probs.map(lambda x:(x[0],prob_5(x[1])))
    num_probs5 = num_probs_raw5.filter(lambda x: x[1]!=None)
    
    pairs5 = num_probs5.keys().collect()
    unique_set5 = set()
    for i in pairs5:
        unique_set5.add(i[0])
        unique_set5.add(i[1])
    unique_list5 = list(unique_set5)
    indexes5 = {}
    for key,name in enumerate(unique_list5):
           indexes5[name]=key
    final_list5 = []
    pairs_list5 = num_probs5.collect()
    for i in pairs_list5:
         final_list5.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd5 = sc.parallelize(final_list5)



    #type of ball:6
    num_probs_raw6 = num_probs.map(lambda x:(x[0],prob_6(x[1])))
    num_probs6 = num_probs_raw6.filter(lambda x: x[1]!=None)
    
    pairs6 = num_probs6.keys().collect()
    unique_set6 = set()
    for i in pairs6:
        unique_set6.add(i[0])
        unique_set6.add(i[1])
    unique_list6 = list(unique_set6)
    indexes6 = {}
    for key,name in enumerate(unique_list6):
           indexes6[name]=key
    final_list6 = []
    pairs_list6 = num_probs6.collect()
    for i in pairs_list6:
         final_list6.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd6 = sc.parallelize(final_list6)



    #type of ball:7
    num_probs_raw7 = num_probs.map(lambda x:(x[0],prob_7(x[1])))
    num_probs7 = num_probs_raw7.filter(lambda x: x[1]!=None)
    
    pairs7 = num_probs7.keys().collect()
    unique_set7 = set()
    for i in pairs7:
        unique_set7.add(i[0])
        unique_set7.add(i[1])
    unique_list7 = list(unique_set7)
    indexes7 = {}
    for key,name in enumerate(unique_list7):
           indexes7[name]=key
    final_list7 = []
    pairs_list7 = num_probs7.collect()
    for i in pairs_list7:
         final_list7.append((indexes[i[0][0]],indexes[i[0][1]],i[1]))
    final_rdd7 = sc.parallelize(final_list7)

    #model0
    ratings0 = final_rdd0.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numIterations = 10
    model0 = ALS.train(ratings0, rank, numIterations)

    # Evaluate the model on training data
    testdata0 = ratings0.map(lambda p: (p[0], p[1]))
    predictions0= model0.predictAll(testdata0).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds0 = ratings0.map(lambda r: ((r[0], r[1]), r[2])).join(predictions0)
    MSE0 = ratesAndPreds0.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE0))
    model0.save(sc, "model0")
   




    #model1
    ratings1 = final_rdd1.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model1 = ALS.train(ratings1, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata1 = ratings1.map(lambda p: (p[0], p[1]))
    predictions1 = model1.predictAll(testdata1).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds1 = ratings1.map(lambda r: ((r[0], r[1]), r[2])).join(predictions1)
    MSE1 = ratesAndPreds1.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE1))
    model1.save(sc, "model1")
   






    
    #model2
    ratings2 = final_rdd2.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model2 = ALS.train(ratings2, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata2 = ratings2.map(lambda p: (p[0], p[1]))
    predictions2 = model1.predictAll(testdata2).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds2 = ratings2.map(lambda r: ((r[0], r[1]), r[2])).join(predictions2)
    MSE2 = ratesAndPreds2.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE2))
    model2.save(sc, "model2")
    
    
    
    
    
    
    #model3
    ratings3 = final_rdd3.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model3 = ALS.train(ratings3, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata3 = ratings3.map(lambda p: (p[0], p[1]))
    predictions3 = model3.predictAll(testdata3).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds3 = ratings3.map(lambda r: ((r[0], r[1]), r[2])).join(predictions3)
    MSE3 = ratesAndPreds3.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE3))
    model3.save(sc, "model3")
    




    
    #model4
    ratings4 = final_rdd4.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model4 = ALS.train(ratings4, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata4 = ratings4.map(lambda p: (p[0], p[1]))
    predictions4 = model4.predictAll(testdata4).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds4 = ratings4.map(lambda r: ((r[0], r[1]), r[2])).join(predictions4)
    MSE4 = ratesAndPreds4.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE4))
    model4.save(sc, "model4")
    




    
    #model5
    ratings5 = final_rdd5.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model5 = ALS.train(ratings1, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata5 = ratings5.map(lambda p: (p[0], p[1]))
    predictions5 = model5.predictAll(testdata5).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds5 = ratings5.map(lambda r: ((r[0], r[1]), r[2])).join(predictions5)
    MSE5 = ratesAndPreds5.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE5))
    model5.save(sc, "model5")
    




    
    #model6
    ratings6 = final_rdd6.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model6 = ALS.train(ratings6, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata6 = ratings6.map(lambda p: (p[0], p[1]))
    predictions6 = model6.predictAll(testdata6).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds6 = ratings6.map(lambda r: ((r[0], r[1]), r[2])).join(predictions6)
    MSE6 = ratesAndPreds6.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE6))
    model6.save(sc, "model6")
    






    
    #model7
    ratings7 = final_rdd7.map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 10
    numiterations1 = 10
    model7 = ALS.train(ratings7, rank, numiterations1)

    # Evaluate the model1 on training data
    testdata7 = ratings7.map(lambda p: (p[0], p[1]))
    predictions7 = model7.predictAll(testdata7).map(lambda r: ((r[0], r[1]), r[2]))
    ratesAndPreds7 = ratings7.map(lambda r: ((r[0], r[1]), r[2])).join(predictions7)
    MSE7 = ratesAndPreds7.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    print("Mean Squared Error = " + str(MSE7))

    # Save and load model1
    model7.save(sc, "model7")
    #samemodel1 = MatrixFactorizationModel.load(sc, "target/tmp/myCollaborativeFilter")




    
    
    
    
    
    
    
    #num_probs_0.foreach(print)
 
    num_probs_cum1 = num_probs_cum.map(lambda x:(str(x[0]),str(x[1]))).cache()
    #num_probs_cum.foreach(print)
    df = num_probs_cum1.toDF()
    df = df.toDF('bowler_batsmen_pair','cumulative_prob')
    df.write.save('~/BD_pairs', format='csv', mode='append')


    centroids = new_d.take(10)
    stop = 0 
    mapper = new_d.map(lambda x:k_means_mapper1(x,centroids)).cache()
    centroids1 = mapper.groupByKey().map(lambda x:new_cent(x)).cache().take(10)
"""  
    while(stop==0):
        #s_of_e = 0
        count = 0
        print(len(centroids))
        print(len(centroids1))
        for i in range(len(centroids)):
            try:
                print("Error: ",abs(centroids[i][1][0] - centroids1[i]))
                if(abs(centroids[i][1][0] - centroids1[i])<=0.01):
                    count+=1
            except:
                print("Error: ",abs(centroids[i] - centroids1[i]))
                if(abs(centroids[i] - centroids1[i])<=0.001):
                    count+=1
        print("Count:",count)
        if(abs(count)==4):
                stop = 1
                mapper1 = new_d.map(lambda x:k_means_mapper2(x,centroids1)).cache()
        else:
                centroids = centroids1
                mapper1 = new_d.map(lambda x:k_means_mapper2(x,centroids1)).cache()
                centroids1 = mapper1.groupByKey().map(lambda x:new_cent(x)).cache().take(10)
    
    mapper2 = mapper1.map(lambda x:(x[1][1],str(list(x[1][2])))).cache()
    df = mapper2.toDF()
    df = df.toDF('batsman_name','run_wicket_prob')
    df.write.save('/BD_Batsman', format='csv', mode='append') """
spark.stop()


