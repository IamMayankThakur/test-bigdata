from __future__ import print_function
import ast
import re
import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf
from operator import itemgetter
from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
import random
import findspark
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating

findspark.init()

conf=SparkConf()
conf.setAppName("BigData")
sc=SparkContext(conf=conf)


def sortSecond(val):
    print(type(val[1]))
    return val[1]

if __name__ == "__main__":

    # Initialize the spark context.
    spark = SparkSession\
        .builder\
        .appName("BigData")\
        .getOrCreate()

    data_schema = [StructField('name', StringType(), True),StructField('runs', StringType(), True)]
    final_struc = StructType(fields=data_schema)

    team1 = spark.read.text("BD_Order/csk.txt").rdd.map(lambda r : r[0])
    team2 = spark.read.text("BD_Order/rcb.txt").rdd.map(lambda r : r[0])  
    df_pairs = spark.read.csv('~/BD_pairs/*.csv',schema = final_struc)

    team1 = team1.collect()
    team2 = team2.collect()

    runs_batsman = [0,0,0,0,0,0]
    i = 1
    var = i
    j = 0
    wickets = [1,1]
    batsman = [team1[i-1],team1[i]]
    total_runs = 0
    total_wick = 0
    over_count = 0  

    while(over_count<20 and i<len(team1)):
        k = 0
        print("Bowler %s"%(team2[j]))
        for k in range(6):
            bowler = team2[j]
            #print("Bowler %s"%(bowler))
            name = "(\'"+batsman[0]+"\', \'"+bowler+"\')"
            try:
                runs_f = ast.literal_eval(df_pairs.filter(df_pairs.name == name).select('runs').collect()[0][0])
                #runs_f.sort(key=lambda x:x[0])
                flag = 0
                for x in runs_f:
                    if(x[0]==7):
                        flag = 1

                if(flag==0):
                    runs_f.append((7,0))
                runs_f.sort(key=lambda x:x[0])
                runs = runs_f[0:len(runs_f)-1]
                wickets[0] = wickets[0]*(1-runs_f[-1][1])
                if(wickets[0]>0.5):
                #print(runs)
                    run_rand = random.uniform(0,1)
                    g = 0
                    while(run_rand>runs[g][1] and g<len(runs)-1):
                        g+=1
                    run = runs[g][0]
                    print(runs)
                    if(run%2!=0):
                        batsman = [batsman[1],batsman[0]]
                        wickets = [wickets[1],wickets[0]]
                 
                else:
                    print("OUT!")
                    print(wickets[0],"balls")
                    i+=1
                    wickets = [1,wickets[1]]
                    
                    if(i<6):
                        print("Batsman switched is",team1[i])
                        batsman = [team1[i],batsman[1]]
                        
                        total_wick+=1
                    else:
                        total_wick+=1
            except:
                file2 = open("dictionary","r")
                dictionary = file2.read()
                indexes =  ast.literal_eval(dictionary)
                sameModel0 = MatrixFactorizationModel.load(sc, "model0")
                sameModel1 = MatrixFactorizationModel.load(sc, "model1")
                sameModel2 = MatrixFactorizationModel.load(sc, "model2")
                sameModel3 = MatrixFactorizationModel.load(sc, "model3")
                sameModel4 = MatrixFactorizationModel.load(sc, "model4")
                sameModel5 = MatrixFactorizationModel.load(sc, "model5")
                sameModel6 = MatrixFactorizationModel.load(sc, "model6")
                sameModel7 = MatrixFactorizationModel.load(sc, "model7")
                models = [sameModel0,sameModel1,sameModel2,sameModel5,sameModel4,sameModel5,sameModel6,sameModel7]
                try:
                        runs_f = ast.literal_eval(df_pairs.filter(df_pairs.name == name).select('runs').collect()[0][0])
                        #runs_f.sort(key=lambda x:x[0])
                        flag = 0
                        for x in runs_f:
                            if(x[0]==7):
                                flag = 1

                        if(flag==0):
                             runs_f.append((7,0))
                        runs_f.sort(key=lambda x:x[0])
                        runs = runs_f[0:len(runs_f)-1]
                        wickets[0] = wickets[0]*(1-runs_f[-1][1])
                        if(wickets[0]>0.25):
                            m = 0
                            n = 0
                            runs = []

                            for m in range(7):
                                count = 0
                                for n in runs:
                                     if(m!=n[0]):
                                         count+=1
                                if(count==len(runs)):
                                    testdata = sc.parallelize((indexes[team1[i]],indexes[team2[j]]))
                                    predictions = models[m].predictAll(testdata).map(lambda r: ((r[0],r[1]),r[2]))
                                    runs.append((m,predictions))

                            runs.sort(key = lambda x:x[0])
                            print(runs)
                            run_rand = random.uniform(0,0.5)
                            a = 0
		        
                            while(run_rand>out[a][1] and a<len(out)-1):
                                   a+=1
                            run = out[a][0]
                            total_runs+=run
                            print("batsman:%s run:%d"%(batsman[0],run))
                            if(run%2!=0):
                                batsman = [batsman[1],batsman[0]]
                                wickets = [wickets[1],wickets[0]]
                        else:
                            i+=1
                            if(i<=5):
                                print("OUT! %s"%(batsman[0]))
                                print(wickets[0])
                                print("Batsman switched is ",team1[i])
                                batsman = [team1[i],batsman[1]]
                                wickets = [1,wickets[1]]
                                total_wick+=1
                
                except:
                        type_of_balls = []
                        indi = []
                        #data = [("",0)]
                        #emp_val = sc.parallelize(data)
                        #print(team1[i],team2[j])
                        #print("team_1 index:",i,"team_2_index:",j)
                        #print(indexes[team1[i]],indexes[team2[j]],type(indexes[team2[j]]))
                        #print("Index",i)
                        indi.append((indexes[team1[i]],indexes[team2[j]]))
                        testdata = sc.parallelize(indi)
                        
                        for k in range(len(models)):
                            #print(len(models))
                            predictions = models[k].predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
                            prediction_list = predictions.collect()
                            #print("Prediction list:",prediction_list)
                            #print("index:",k)
                            type_of_balls.append((k,prediction_list[0][1]))
                        
                        n = 0
                        for g in range(len(type_of_balls)):
                            type_of_balls[g]=list(type_of_balls[g])   
                        counter = 0
                        for n in range(len(type_of_balls)-1):
                            counter+=type_of_balls[n][1]
                            type_of_balls[n][1] =counter
                        #print(type_of_balls)
                        
                        normalsum = 0
                        for n in range(len(type_of_balls)-1):
                            normalsum+=type_of_balls[n][1]
                        for n in range(len(type_of_balls)-1):
                            type_of_balls[n][1]=type_of_balls[n][1]/normalsum
                        counter = 0
                        for n in range(len(type_of_balls)-1):
                            counter+=type_of_balls[n][1]
                            type_of_balls[n][1] =counter
                        print(type_of_balls)


                        
                        runs = type_of_balls[0:len(type_of_balls)-1]
                        wickets[0] = wickets[0]*(1-type_of_balls[-1][1])
                        if(wickets[0]>0.1):
                            print("Entered")
                            m = 0
                            n = 0
                            #runs = []
                            run_rand = random.uniform(0,0.5)
                            a = 0
                            print()
                            while(run_rand>runs[a][1] and a<len(runs)):
                                #print("length:",len(runs))
                                a+=1
                            run = runs[a][0]
                            total_runs+=run
                            print("batsman:%s run:%d"%(batsman[0],run))
                            if(run%2!=0):
                                batsman = [batsman[1],batsman[0]]
                                wickets = [wickets[1],wickets[0]]
                        else:
                            i+=1
                            if(i<5):
                                print("OUT! %s"%(batsman[0]))
                                print(wickets[0])
                                print(wickets)
                                print(batsman[0])
                                print("Batsman switched is ",team1[i])
                                batsman = [team1[i],batsman[1]]
                                wickets = [1,wickets[1]]
                                total_wick+=1
                            if(i==6 and total_wick<5):
                                print(total_wick)
                                print("OUT! %s"%(batsman[0]))
                                print(wickets[0],"HELLO")
                                total_wick+=1
                                break
                           #print(types_of_balls)
                
                
                  
        print("%d/%d"%(total_runs,total_wick))        
        j+=1
        j = j%4
        over_count+=1
        batsman = [batsman[1],batsman[0]]
        
        print("New Batting order",batsman)
        print("#################OVER CHANGE#####################")
                
