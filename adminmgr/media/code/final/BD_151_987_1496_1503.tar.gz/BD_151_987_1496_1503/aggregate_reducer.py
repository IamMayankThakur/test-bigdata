#!/usr/bin/python
import sys

a = sys.argv[1]
a = a.split(";")
functions = a[0].split(",")
dtypes = a[1].split(",")
result = []

for i in functions:
    if i == "max":
        result.append(-999999999)
    else:
        result.append(0)

for line in sys.stdin:
    line = line.rstrip()
    x = line.split(",")
    for i in range(len(x)):
        if dtypes[i] == "int":
            x[i] = int(x[i])
        elif dtypes[i] == "float":
            x[i] = float(x[i])
        
    for i in range(len(x)):
        if functions[i] == "sum":
            result[i] += x[i]
        if functions[i] == "count":
            result[i]+=1
        elif functions[i] == "max":
            if result[i] < x[i]:
                result[i] = x[i]

for i in range(len(result)):
    result[i] = str(result[i])

r = "\t".join(result)
print r
    



