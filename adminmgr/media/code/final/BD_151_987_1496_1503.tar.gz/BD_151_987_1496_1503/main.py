from parser import *
hdfs_path = "/Database"
hdfs(hdfs_path).mkdir()
hdfs(hdfs_path+"/"+"dblist.db",'w').close()

while 1:
    try:
        s = input('hsql > ')
    except EOFError:
        break
    if not s:
        continue
    yacc.parse(s)
