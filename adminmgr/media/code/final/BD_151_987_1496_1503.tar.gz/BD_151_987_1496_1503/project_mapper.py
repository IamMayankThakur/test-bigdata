#!/usr/bin/python
import sys

a = sys.argv
a.pop(0)
a = list(map(lambda x: int(x),a))


for line in sys.stdin:
    try:
        if(line != '\n'):
            data = line.split(",")
            g = []
            for j in a:
                g.append(data[j])
            s = ",".join(g)
            print s.rstrip()
    except Exception as e:
        print str(e)

