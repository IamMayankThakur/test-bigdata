import ply.lex as lex

reserved = (
    'SELECT','LOAD','MAX','COUNT','SUM','USE','DATABASE','AS','INT','FLOAT','STR','FROM','WHERE','EXIT','CREATE','DROP','QUIT','TABLE','CURRENT','SCHEMA',"LIST"
)

tokens = reserved + (
    'ID', 'ICONST', 'FCONST', 'SCONST',

    'PLUS', 'MINUS', 'TIMES',
    'OR', 'AND', 'NOT', 
    'LT', 'LE', 'GT', 'GE', 'EQ', 'NE',
    'EQUALS','ALL',
    'LPAREN', 'RPAREN',
    'COMMA', 'SEMI','COLON'
)


t_ignore = ' \t\x0c'




def t_NEWLINE(t):
    r'\n+'
    t.lexer.lineno += t.value.count("\n")


t_OR = r'\|\|'
t_AND = r'&&'
t_NOT = r'!'
t_LT = r'<'
t_GT = r'>'
t_LE = r'<='
t_GE = r'>='
t_EQ = r'=='
t_NE = r'!='
t_COLON =r':'
t_ALL=r'\*'



t_EQUALS = r'='

t_LPAREN = r'\('
t_RPAREN = r'\)'
t_COMMA = r','
t_SEMI = r';'


typeid=[]
reserved_map = {}
for r in reserved:
    reserved_map[r.lower()] = r


def t_ID(t):
    r'[A-Za-z_\/~\.]+(?:[.]+[A-Za-z]+)*'
    t.type = reserved_map.get(t.value, "ID")
    t.value=t.value
    return t

t_ICONST = r'\d+([uU]|[lL]|[uU][lL]|[lL][uU])?'


t_FCONST = r'((\d+)(\.\d+)(e(\+|-)?(\d+))? | (\d+)e(\+|-)?(\d+))([lL]|[fF])?'


t_SCONST=r"""('([^\\']+|\\'|\\\\)*')|("([^\\']+|\\'|\\\\)*")""" 

# Comments


def t_comment(t):
    r'(/\*(.|\n)*?\*/)|(//[^\n]*)'
    t.lexer.lineno += t.value.count('\n')

def t_error(t):
    print("Illegal character '%s' at line number %d and position %d " % (t.value[0],t.lineno,t.lexpos))
    t.lexer.skip(1)

lexer=lex.lex()

if __name__=='__main__':
    # Tokenize
    while True:
        lexer.input(input("hsql> "))
        tok = lexer.token()
        if not tok: 
            break      # No more input
        print(tok)
 
