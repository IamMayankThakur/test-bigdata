#!/usr/bin/python
import sys

for line in sys.stdin:
    print line.rstrip()