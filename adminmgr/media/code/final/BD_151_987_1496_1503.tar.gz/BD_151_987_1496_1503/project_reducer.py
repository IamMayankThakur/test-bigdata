#!/usr/bin/python
import sys

prev = ""
for line in sys.stdin:
    try:
        if line == prev or line == '\t\n':
            continue
        else:
            prev = line
            line = line.split(",")
            line = "\t\t".join(line)
            print line.rstrip()
    except Exception as e:
        print str(e)