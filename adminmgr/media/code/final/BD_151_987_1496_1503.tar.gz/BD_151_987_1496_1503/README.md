# hsql
<h1>An SQL engine on top of Hadoop</h1>

<h2>There are 4 files</h2>

1. lexer.py : this does the job of lexing
2. parser.py : this does the parsing of the SQL queries
3. main.py : this is the one which runs the interpreter (like python !) and you can run SQL Queries
4. implemenation.py : this file contains the implemenations of SQL queries and some functions **(Must be completed)**

<h2>The SQL Queries Currently Supported :</h2>

1. select
2. use
3. drop
4. load
5. create database
6. schema (not there in standard SQL. Added to view schema of databases and tables)
7. current database (again not there in standard SQL. Added to know the currently selected database)
8. exit() or quit() (to quit the interpreter)

<h2>What are requirements ?</h2>

hadoop
python3
ply

<h2>How to install ply ?</h2>

`pip3 install ply` 


<h2>How to run the interpreter ?</h2>

`python3 main.py`


<h2>What's Currently Working ?</h2>

1. use
2. create database
3. load
4. drop
5. schema
6. current database

<h2>Syntax </h2>

1. LOAD

load csv_file_name.csv as table_name(column_name1:data_type,column_name2:data_type,...); 

2. SELECT

select column_name1,column_name2,... from table_name where condition;

3. DROP

drop table table_name;
drop database database_name;

4. CREATE

create database database_name;

5. USE

use database_name;

6. SCHEMA

schema table table_name;
schema database database_name;

7. LIST

list database;

8. CURRENT

current database;

**Note : data_type can be int,float,str** 


<h2>What's must be done ?</h2>

1. Implement select
2. Implement aggregate functions MAX, COUNT, SUM


**Note : May have to write mapper/reducer in separate files and call them via system call in the wrapper functions select, load, MAX,COUNT and SUM via hadoop streaming API**

<h2>The Directory Organization</h2>

DATABASE_ROOT/<br/>
&nbsp;&nbsp;&nbsp;&nbsp;database_name.schema <br/>
&nbsp;&nbsp;&nbsp;&nbsp;dblist.db <br/>
&nbsp;&nbsp;&nbsp;&nbsp;database_name/<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;table_name/ &nbsp;&nbsp;&nbsp;&nbsp; <br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;column_name<br/>

**Note**


1. dblist.db is file which contains the list of all the databases (only 1)
2. There is one schema file per database in database folder
3. There is one directory for each database
4. There is one folder for each table in a database which contain the csv files

**Have commented as many important lines as possible. If you have any doubts, call me.**
