import os
import sys
import subprocess
import re
hdfs_path = "/Database" 

def popen(command):

	p = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)

	(output, err) = p.communicate()  

	#This makes the wait possible
	p_status = p.wait()
	
	return output

class hdfs:
    def __init__(self,path,mode='r'):
        self.path=path
        self.mode=mode
        if mode=='w':
            try:
                if int(popen("hdfs dfs -test -e "+self.path+";echo $?"))==0:
                    pass 
                else:
                    popen("hdfs dfs -touchz "+str(self.path))
            except:
                pass

    def test(self):
        return not int(popen("hdfs dfs -test -e "+self.path+";echo $?"))

    def mkdir(self):
        try:
            if int(popen("hdfs dfs -test -e "+self.path+";echo $?"))==1:
                popen("hdfs dfs -mkdir -p "+str(self.path))
        except:
            print("COULD NOT CREATE !")
            
    def readlines(self):
        try:
            return popen("hdfs dfs -cat "+ self.path).decode().split("\n")
        except:
            return []
            
    def write(self,content):
        try:
            popen("echo '"+content+"' | hdfs dfs -appendToFile - "+str(self.path))
        except:
            print("COULD NOT WRITE !")
            
    def load(self,hdfs_file_path):
        # original_file_path : path (including name) for the loaded csv file
        # hdfs_file_path : hdfs path to store the csv file
        try:
            popen('hdfs dfs -put' + ' ' + self.path + ' ' + hdfs_file_path)
        except:
            print("COULD NOT LOAD FILE !")
            
    def drop(self):
        # what : "table" or "database"
        # path : path to table or database
        try:
            popen('hdfs dfs -rm -r -skipTrash' + ' '+ self.path)
        except:
            print("COULD NOT FROP FILE !")
            
    def close(self):
        #os.popen("rm temp.txt")
        pass
def expParserHelper(root,l,counter):
    if root!=None:
        if type(root)==str:
            yield root
        else:
            yield from expParserHelper(root.left,l,counter)
            if type(root.value) ==exp:
                yield from expParserHelper(root.value,l,counter)
            else:
                if root.type=='id':
                    l.append(root.value)
                    counter[0]+=1
                    yield "x["+str(counter[0])+"]"
                else:
                    yield root.value
            yield from expParserHelper(root.right,l,counter)          
class exp:
    def __init__(self,type,*argv):
        self.type = type
        self.left=argv[0]
        self.right=argv[1]
        self.value=argv[2]
    def convert(self):
        s=""
        l=[]
        for i in expParserHelper(self,l,[-1]):
            s+=i+" "
        return s,l

class column:
    def __init__(self,name,agg,alias):
        self.name=name
        self.agg=agg
        self.alias=alias

def db_info(db):
    """returns a dict of structure {'table_name':{'file':'csv_file_path','cols':[all the columns],'dtype':[corresponding data types for the cols]}}"""
    global hdfs_path
    f=hdfs(hdfs_path+"/"+db+"/"+db+".schema")
    flag=0
    info={}
    table=""
    for i in f.readlines():
        flag=1
        temp=i.strip().split(":")
        if temp[0]=='table':
            table=temp[1]
            info[temp[1]]={}
            info[temp[1]]["cols"]=[]
            info[temp[1]]["dtype"]=[]
        elif len(temp)==1:
            if ".csv" in temp[0]:
                info[table]['file']=temp[0]
        elif temp[0]=='column':
            continue
        else:
            info[table]["cols"].append(temp[0])
            info[table]["dtype"].append(temp[1])
    f.close()
    return info
    

def select(columns,db,table,expression):
    #columns : list of objects of type column (defined above)
    #db : name of database 
    #table : name of table 
    #expression: where expression for filtering (it is a string)
    info = db_info(db)
    columns_to_project = []  
    if(columns[0].name == "*"):
        columns_to_project = [str(i) for i in range(len(info[str(table)]["cols"]))]
    else:  
        for i in columns:
            column_index = info[str(table)]["cols"].index(i.name)
            columns_to_project.append(str(column_index))
    columns_string = " ".join(columns_to_project)
    if columns[0].agg == None:
        if expression.convert()[0] != " ":
            s,l=expression.convert()
            s = s.split()
            c = 0
            for i in range(len(s)):
                if len(re.findall("^x\[\d+\]",s[i])) == 1:
                    column_index = info[str(table)]["cols"].index(l[c])
                    s[i] = "x[{}]".format(column_index)
                    dtype = info[str(table)]["dtype"][column_index]
                    s[i] = "{}({})".format(dtype,s[i])
                    c+=1
            condition = " ".join(s)
            select_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper select_mapper.py -file /root/hsql/select_mapper.py -reducer \"select_reducer.py '{}'\" -file /root/hsql/select_reducer.py  -input /Database/{}/*.csv  -output /output".format(condition,db+"/"+table)
            project_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper 'project_mapper.py {}' -file /root/hsql/project_mapper.py -reducer project_reducer.py -file /root/hsql/project_reducer.py  -input /output/part-00000  -output /output1".format(columns_string)
            show_command = "hdfs dfs -cat /output1/part-00000"


            os.system(select_command + " > /dev/null")
            os.system(project_command + " > /dev/null")
            os.system(show_command)
            os.system("hdfs dfs -rm -r /output1 > /dev/null")
            os.system("hdfs dfs -rm -r /output > /dev/null")
        else:
            project_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper 'project_mapper.py {}' -file /root/hsql/project_mapper.py -reducer project_reducer.py -file /root/hsql/project_reducer.py  -input /Database/{}/*.csv -output /output".format(columns_string,db+"/"+table)
            show_command = "hdfs dfs -cat /output/part-00000"
            os.system(project_command + " > /dev/null")
            os.system(show_command)
            os.system("hdfs dfs -rm -r /output > /dev/null")

    else:
        aggregate_functions = []
        aggregate_dtypes = []
        for i in columns:
            aggregate_functions.append(i.agg)
            column_index = info[str(table)]["cols"].index(i.name)
            aggregate_dtypes.append(info[str(table)]["dtype"][column_index])
        
        agrregate_functions_string = ",".join(aggregate_functions)
        aggregate_dtypes_string = ",".join(aggregate_dtypes)
        aggregate_string = agrregate_functions_string + ";" + aggregate_dtypes_string

        if expression.convert()[0] != " ":
            s,l=expression.convert()
            s = s.split()
            c = 0
            for i in range(len(s)):
                if len(re.findall("^x\[\d+\]",s[i])) == 1:
                    column_index = info[str(table)]["cols"].index(l[c])
                    s[i] = "x[{}]".format(column_index)
                    dtype = info[str(table)]["dtype"][column_index]
                    s[i] = "{}({})".format(dtype,s[i])
                    c+=1
            condition = " ".join(s)
            select_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper select_mapper.py -file /root/hsql/select_mapper.py -reducer \"select_reducer.py '{}'\" -file /root/hsql/select_reducer.py  -input /Database/{}/*.csv  -output /output".format(condition,db+"/"+table)
            aggregate_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper 'project_mapper.py {}'  -file /root/hsql/project_mapper.py -reducer 'aggregate_reducer.py \"{}\"' -file /root/hsql/aggregate_reducer.py -input /output/part-00000 -output /output1".format(columns_string,aggregate_string)
            show_command = "hdfs dfs -cat /output1/part-00000"

            os.system(select_command + " > /dev/null")
            os.system(aggregate_command + " > /dev/null")
            os.system(show_command)
            os.system("hdfs dfs -rm -r /output1 > /dev/null")
            os.system("hdfs dfs -rm -r /output > /dev/null")

        else:
            aggregate_command = "hadoop jar /root/hadoop-3.2.0/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -mapper 'project_mapper.py {}'  -file /root/hsql/project_mapper.py -reducer 'aggregate_reducer.py \"{}\"' -file /root/hsql/aggregate_reducer.py -input /Database/{}/*.csv  -output /output".format(columns_string,aggregate_string,db+"/"+table)
            show_command = "hdfs dfs -cat /output/part-00000"

            os.system(aggregate_command + " > /dev/null" )
            os.system(show_command)
            os.system("hdfs dfs -rm -r /output > /dev/null")





