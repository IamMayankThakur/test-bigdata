#!/usr/bin/python
import sys

condition = sys.argv[1]

#x = [6]

#print(eval(condition))

for line in sys.stdin:
    try:
        x = line.split(",")
        if x[0] != '\t\n' and eval(condition) == True:
            print line.rstrip()
    except Exception as e:
        continue
        