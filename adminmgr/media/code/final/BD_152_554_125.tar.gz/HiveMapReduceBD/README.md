# HiveMapReduceBD
An implementation of a SQL engine using Hadoop MapReduce
