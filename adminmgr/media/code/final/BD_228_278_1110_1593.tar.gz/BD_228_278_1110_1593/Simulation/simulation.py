import csv
import random
import pandas as pd 

def compute_similarity(item1,item2,userRatings):
	averages = {}
	for (key,ratings) in userRatings.items():
		averages[key] = (float(sum(ratings.values()))/len(ratings.values()))

	num = 0
	dem1 = 0
	dem2 = 0

	for (user,ratings) in userRatings.items():
		if item1 in ratings and item2 in ratings:
			avg = averages[user]
			num += (ratings[item1] - avg) * (ratings[item2] - avg)
			dem1 += (ratings[item1] - avg) ** 2
			dem2 += (ratings[item2] - avg) ** 2
	if dem1*dem2 == 0:
		return 0
	return num / (sqrt(dem1 * dem2))

def build_similarity_matrix(userRatings):
	similarity_matrix = {}

	for i in range(0,len(itemNames)):
		band = {}
		for j in range(0,len(itemNames)):
			if itemNames[i] != itemNames[j]:
				band[itemNames[j]] = compute_similarity(itemNames[i],itemNames[j],data)
		similarity_matrix[itemNames[i]] = band
	return similarity_matrix

def normalize(rating):
	num = 2 * (rating - MINrating) - (MAXrating - MINrating)
	den = (MAXrating - MINrating)
	return num / den

def denormalize(rating):
	return (((rating + 1) * (MAXrating - MINrating))/2 ) + MINrating

def prediction(username,item):
	num = 0
	den = 0
	for band,rating in data[username].items():
		num += sm[item][band] * normalize(rating)
		den += abs(sm[item][band])

	if den == 0:
		return 0
	return denormalize(num/den)

def recommendation(username,userRatings):
	recommend = []
	for item in itemNames:
		if item not in userRatings[username].keys():
			if prediction(username,item) >= 3.5:
				recommend.append(item)
	return recommend 

class K_Means:
	def __init__(self, k =3, tolerance = 0.0001, max_iterations = 500):
		self.k = k
		self.tolerance = tolerance
		self.max_iterations = max_iterations

	def fit(self, data):

		self.centroids = {}

		#initialize the centroids, the first 'k' elements in the dataset will be our initial centroids
		for i in range(self.k):
			self.centroids[i] = data[i]

		#begin iterations
		for i in range(self.max_iterations):
			self.classes = {}
			for i in range(self.k):
				self.classes[i] = []

			#find the distance between the point and cluster; choose the nearest centroid
			for features in data:
				distances = [np.linalg.norm(features - self.centroids[centroid]) for centroid in self.centroids]
				classification = distances.index(min(distances))
				self.classes[classification].append(features)

			previous = dict(self.centroids)

			#average the cluster datapoints to re-calculate the centroids
			for classification in self.classes:
				self.centroids[classification] = np.average(self.classes[classification], axis = 0)

			isOptimal = True

			for centroid in self.centroids:

				original_centroid = previous[centroid]
				curr = self.centroids[centroid]

				if np.sum((curr - original_centroid)/original_centroid * 100.0) > self.tolerance:
					isOptimal = False

			#break out of the main loop if the results are optimal, ie. the centroids don't change their positions much(more than our tolerance)
			if isOptimal:
				break

	def pred(self, data):
		distances = [np.linalg.norm(data - self.centroids[centroid]) for centroid in self.centroids]
		classification = distances.index(min(distances))
		return classification

clust_prob = pd.DataFrame(columns=['batclustno','bowlclustno','0', '1', '2', '3', '4',  '6','notout'])
clust = pd.read_csv('intercluster.csv')
for i in range(len(clust)):
	clust_prob.at[i] = [None for n in range(9)]
	clust_prob.at[i,'0'] = float(clust.at[i,'0'])                          
	clust_prob.at[i,'1'] = float(clust.at[i,'1']) + float(clust.at[i,'0'])
	clust_prob.at[i,'2'] = float(clust.at[i,'2']) + float(clust_prob.at[i,'1'])
	clust_prob.at[i,'3'] = float(clust.at[i,'3']) + float(clust_prob.at[i,'2'])
	clust_prob.at[i,'4'] = float(clust.at[i,'4']) + float(clust_prob.at[i,'3'])
	clust_prob.at[i,'6'] = float(clust.at[i,'6']) + float(clust_prob.at[i,'4'])                
	clust_prob.at[i,'batclustno'] = clust.at[i,'batclustno']	       
	clust_prob.at[i,'bowlclustno'] = clust.at[i,'bowlclustno']
	clust_prob.at[i,'notout'] = 1 - float(clust.at[i,'out'])

team1 = list()
bat_clust = {}
team2 = list()
bowl_clust = {}

files = pd.read_csv('interplayer.csv') 
for i in range(len(files)):
	bowlname = files.loc[i].bowler.strip()   
	bowl_clust[bowlname] = files.loc[i].bowlclustno
	batname = files.loc[i].batsman.strip()     
	bat_clust[batname] = files.loc[i].batclustno


squad = pd.read_csv('teams.csv')
for index, row in squad.iterrows():
	if(row[0]!="Team1"):
		team1.append(row[0])
	if(row[1]!="Team2"):
		team2.append(row[1])
print(team1,team2)

player_prob = pd.read_csv('cumulative_prob.csv')

def playerprob(batsman,bowler):
	row = player_prob.loc[player_prob['batsman'] == batsman].loc[player_prob['bowler'] == bowler]
	rand = random.random()
	res = 0 if rand <= float(row['0']) else 1 if rand <= float(row['1']) else 2 if rand <= float(row['2']) else 3 if rand <= float(row['3']) else 4 if rand <= float(row['4']) else 6 if rand <= float(row['6']) else -1
	return res

def clusterprob(bat_clust_no,bowl_clust_no):
	row = clust_prob.loc[clust_prob['batclustno'] == bat_clust_no].loc[clust_prob['bowlclustno'] == bowl_clust_no]
	rand = random.random()
	res = 0 if rand <= float(row['0']) else 1 if rand <= float(row['1']) else 2 if rand <= float(row['2']) else 3 if rand <= float(row['3']) else 4 if rand <= float(row['4']) else 6 if rand <= float(row['6']) else -1
	return res

	

def first_innings(team1, team2):
	dic_stats = {"wickets":0,"runs":0,"nextbatsman":2,"overs":0,"striker":team1[0],"bowler":team2[-1],"non_striker":team1[1],"prob":0,"count":2,"nprob":1}
	dic = {}
	dic[dic_stats["striker"]] = 1
	dic[dic_stats["non_striker"]]=1
	while(dic_stats["overs"]<20 and  dic_stats["wickets"]< 10):
		cl = 0
		balls = 1
		while(balls<6 and dic_stats["wickets"] <10):
			try:
				row = player_prob.loc[player_prob['batsman'] == dic_stats["striker"]].loc[player_prob['bowler'] == dic_stats["bowler"]]
				dic_stats["prob"] = float(row['notout'])
			except:
				row = clust_prob.loc[clust_prob['batclustno'] == bat_clust[dic_stats["striker"]]].loc[clust_prob['bowlclustno'] == bowl_clust[dic_stats["bowler"]]]
				dic_stats["prob"] = float(row['notout'])
				cl = 1
				
			dic_stats["nprob"] = dic_stats["nprob"]*dic_stats["prob"]
			dic[dic_stats["striker"]] = dic[dic_stats["striker"]]*dic_stats["prob"]
			flag = 0
			score = 0
			if (dic[dic_stats["striker"]] < 0.5):
				dic_stats["nextbatsman"] = (dic_stats["nextbatsman"]+1)%11
				flag = 1
				dic_stats["wickets"] = dic_stats["wickets"]+1
				dic_stats["striker"] = team1[dic_stats["nextbatsman"]]
				dic[dic_stats["striker"]] = 1
			elif (dic[dic_stats["striker"]] > 0.5):
				if cl!=0:
					score = clusterprob(bat_clust[dic_stats["striker"]],bowl_clust[dic_stats["bowler"]])	
				else:
					if (int(row['balls'])<15):
						score = clusterprob(bat_clust[dic_stats["striker"]],bowl_clust[dic_stats["bowler"]])
					else:
						score = playerprob(dic_stats["striker"],dic_stats["bowler"])
			if(flag==0):
				dic_stats["runs"] = dic_stats["runs"]+score
				if (score==1 or score == 3):
					dic_stats["striker"],dic_stats["non_striker"] = dic_stats["non_striker"],dic_stats["striker"]
			balls = balls+1
		dic_stats["overs"] += 1
		dic_stats["count"] = (dic_stats["count"]+1)%5 + 1
		dic_stats["striker"],dic_stats["non_striker"] = dic_stats["non_striker"],dic_stats["striker"]                 
		dic_stats["bowler"] = team2[len(team2)-dic_stats["count"]]                    
		print(str(dic_stats["overs"])+"\t|\t"+str(dic_stats["runs"])+"    \t|\t"+str(dic_stats["wickets"]))
	return dic_stats["runs"],dic_stats["wickets"]


def second_innings(team1, team2,runs1):
	dic_stats = {"wickets":0,"runs":0,"nextbatsman":2,"overs":0,"striker":team1[0],"bowler":team2[-1],"non_striker":team1[1],"prob":0,"count":2,"nprob":1}
	dic = {}
	dic[dic_stats["striker"]] = 1
	dic[dic_stats["non_striker"]]=1
	while(dic_stats["overs"]<20 and  dic_stats["wickets"]< 10):
		cl = 0
		balls = 1
		while(balls<6 and dic_stats["runs"]<=runs1 and dic_stats["wickets"] <10):
			try:
				row = player_prob.loc[player_prob['batsman'] == dic_stats["striker"]].loc[player_prob['bowler'] == dic_stats["bowler"]]
				dic_stats["prob"] = float(row['notout'])
			except:
				row = clust_prob.loc[clust_prob['batclustno'] == bat_clust[dic_stats["striker"]]].loc[clust_prob['bowlclustno'] == bowl_clust[dic_stats["bowler"]]]
				dic_stats["prob"] = float(row['notout'])
				cl = 1
				
			dic_stats["nprob"] = dic_stats["nprob"]*dic_stats["prob"]
			dic[dic_stats["striker"]] = dic[dic_stats["striker"]]*dic_stats["prob"]
			flag = 0
			score = 0
			if (dic[dic_stats["striker"]] < 0.5):
				dic_stats["nextbatsman"] = (dic_stats["nextbatsman"]+1)%11
				flag = 1
				dic_stats["wickets"] = dic_stats["wickets"]+1
				dic_stats["striker"] = team1[dic_stats["nextbatsman"]]
				dic[dic_stats["striker"]] = 1
			elif (dic[dic_stats["striker"]] > 0.5):
				if cl!=0:
					score = clusterprob(bat_clust[dic_stats["striker"]],bowl_clust[dic_stats["bowler"]])	
				else:
					if (int(row['balls'])<15):
						score = clusterprob(bat_clust[dic_stats["striker"]],bowl_clust[dic_stats["bowler"]])
					else:
						score = playerprob(dic_stats["striker"],dic_stats["bowler"])
			if(flag==0):
				dic_stats["runs"] = dic_stats["runs"]+score
				if (score==1 or score == 3):
					dic_stats["striker"],dic_stats["non_striker"] = dic_stats["non_striker"],dic_stats["striker"]
			balls = balls+1
		dic_stats["overs"] += 1
		dic_stats["count"] = (dic_stats["count"]+1)%5 + 1
		dic_stats["striker"],dic_stats["non_striker"] = dic_stats["non_striker"],dic_stats["striker"]                 
		dic_stats["bowler"] = team2[len(team2)-dic_stats["count"]]                    
		print(str(dic_stats["overs"])+"\t|\t"+str(dic_stats["runs"])+"    \t|\t"+str(dic_stats["wickets"]))
		if(runs1<dic_stats["runs"]):
			break
	return dic_stats["runs"],dic_stats["wickets"]

print("--------------------------------------------------------")
print("\t\t SCORECARD")
print("--------------------------------------------------------")
print("\t\t  INNINGS 1")
print("--------------------------------------------------------")
print("Overs\t|\tRuns\t|\tWickets")
runs1 ,wicks1 = first_innings(team1,team2)
print("--------------------------------------------------------")
print("\t\t  INNINGS 2")
print("--------------------------------------------------------")
print("Overs\t|\tRuns\t|\tWickets")
runs2 ,wicks2 = second_innings(team2,team1,runs1)
print("--------------------------------------------------------")
print("Innings 1 Score : ", runs1, "-", wicks1)
print("Innings 2 Score : ", runs2, "-", wicks2)
print("--------------------------------------------------------")
print("TEAM 2 WON") if runs1<runs2 else print("TEAM 1 WON") if runs1>runs2 else print("TIE")
