from __future__ import print_function
import sys
#from ast import literal_eval
maximum=0

for i in sys.stdin:
    i = i.split(",")
    j= int(i[1])
    if j > maximum:
        maximum=j

print(maximum)









