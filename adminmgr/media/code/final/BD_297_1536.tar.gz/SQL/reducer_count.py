from __future__ import print_function
import sys
#initialize count to 0
count = 0

#reading the output from the mapper
for i in sys.stdin: 
        i=i.split("::")
        print(i[0])
        count += 1 #increment the count
        
print("COUNT:",count)
