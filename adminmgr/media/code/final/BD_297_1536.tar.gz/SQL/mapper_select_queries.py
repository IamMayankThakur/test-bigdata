from __future__ import print_function
query_list = ['SELECT', 'home_goals', 'FROM', 'res/results.csv']

import sys
from collections import OrderedDict     
import re

def return_index(list1,list2,d):
    pos = []    
    for i in list1.split(','):
        if(i in list2):
            pos.append(list2.index(i))
    #print(pos)   
    return pos 

d = OrderedDict()
with open('/home/kishan/Project/SQL/schema.txt') as f:
    for line in f:
        list1 = line.split(',')
        for i in list1:
            (key,val) = i.split(':')
            d[key] = val
indexes = []
flag=0
#for where condition
if len(query_list) > 5:
    if(re.search('=',query_list[5])):
        column,val = query_list[5].split('=')
        reqd_column = return_index(column,list(d.keys()),d)
    elif(re.search('<',query_list[5])):
        column,val = query_list[5].split('<')
        reqd_column = return_index(column,list(d.keys()),d)
        flag=1
    elif(re.search('>',query_list[5])):
        column,val = query_list[5].split('>')
        reqd_column = return_index(column,list(d.keys()),d)
        flag=2
#print(reqd_column)
# selecting all attributes
if query_list[1] == '*':
    for i in range(len(list(d.keys()))-1):
        indexes.append(i)
        
else: #for column selection   
    indexes = return_index(query_list[1],list(d.keys()),d)

r = sys.stdin
for i in r:
    rows = i.split(',')
    string1 = '' 
    #without where condition
    if len(query_list) < 5:
         for j in indexes:
                string1 = string1 + str(rows[j]) + '||'
         if(len(indexes)):
                print("%s::%s" % (string1[:-1],string1))
    
    else: #with where condition
        #print(reqd_column[0])
        if(flag==0):
            if rows[reqd_column[0]] == val:
	            for j in indexes:
	                string1 = string1 + str(rows[j]) + '||'
	            if(len(indexes)):
	                print("%s::%s" % (string1[:-1],string1))
        elif(flag==1):
            if rows[reqd_column[0]] < val:
                for j in indexes:
	                string1 = string1 + str(rows[j]) + '||'
                if(len(indexes)):
	                print("%s::%s" % (string1[:-1],string1))
        elif(flag==2):
            if rows[reqd_column[0]] > val:
	            for j in indexes:
	                string1 = string1 + str(rows[j]) + '||'
	            if(len(indexes)):
	                print("%s::%s" % (string1[:-1],string1))
       
    
    
    

