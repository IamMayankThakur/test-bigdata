from __future__ import print_function
import sys
#from ast import literal_eval
minimum=1234567890
for i in sys.stdin:
    i = i.split(",")
    j=int(i[1])
    if j < minimum:
        minimum=j

print(minimum)










