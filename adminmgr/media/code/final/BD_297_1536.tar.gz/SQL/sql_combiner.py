import subprocess
import sys
import fileinput
import pydoop.hdfs as hdfs
import re
from collections import OrderedDict
def run_command(args_list):
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (output, errors) = proc.communicate()
    if errors:
    	serr = str(errors).split(':')
    return (errors)

while(1):
	print("*************************************************************************************************************************************")
	print("1.LOAD\n2.QUERY\n3.QUIT\n\nEnter your choice: ")
	option = int(input())

	if(option == 1):
		print("Format: LOAD <database_name/table_name.csv> AS <schema>\n")
		load_data = input().split()
		if load_data[0] == 'LOAD':
		    if load_data[1] and load_data[3]:           
		        db = load_data[1].split('/')
		        create_database = ['hadoop','fs','-mkdir']
		        create_database.append('/'+str(db[0]))
		        run_command(create_database)
		        argument = ['hadoop','fs','-put']
		        argument.append('/home/kishan/Project/SQL/'+str(db[1])) #table name(bigdata.csv)
		        argument.append('/'+str(db[0])+'/') #database name(/project)

		        o = run_command(argument)
	 

		        fp = open('schema.txt','w')
		        fp.write(load_data[3])
		        fp.close()
		        argument_schema = ['hadoop','fs','-put']
		        argument_schema.append('/home/kishan/Project/SQL/'+'schema.txt')
		        argument_schema.append('/'+str(db[0]))
		        s = run_command(argument_schema)
		        	
	elif (option == 2):
		print("Format: SELECT <column_name> FROM <database_name/table_name.csv> WHERE <condition> AGGREGATE_BY <count/min/max>")  
		print("Enter the query: ")  
		query = input().split()
		
		#Error handling
		if(len(query)<=3):
		            print("The query must have atleast 4 parameters")
		            exit()
		            
		o=run_command(['hadoop', 'fs','-ls',"/"+str(query[3])])
		
		#Error handling
		if((o.decode('utf-8')).endswith('directory\n')):
		    print("Database or Table not found")
		    exit()
		    
		#schema    
		if query[0] == 'SELECT' and query[2] == 'FROM':        
		    d = OrderedDict()
		    with open('/home/kishan/Project/SQL/schema.txt') as f:
		        for line in f:
		            l1 = line.split(',')
		            for i in l1:
		                (key,val) = i.split(':')
		                d[key] = val

		                
		    #Error handling
		    if(len(query[1].split(","))>1):
		            for i in query[1].split(","):
		                   if(i not in d.keys()):
		                            print("Invalid Column")
		                            exit()
		    elif(query[1] not in d.keys() and query[1]!='*'):
		            print("Invalid Column")
		            exit()
		    
		    with open("/home/kishan/Project/SQL/mapper_aggregate_queries.py") as f:
		        lines = f.readlines()
		    lines[1] = 'query_list = ' + str(query) + '\n'
		    with open("/home/kishan/Project/SQL/mapper_aggregate_queries.py", "w") as f:
		        f.writelines(lines)
		  
		    input1 = '/'+query[3]
		    
		    
		    if query[-1]=='min':
		        Column = query[1]
		        l = list(d.keys())
		        if Column in l:
		            if ((d[Column] == 'integer') or (d[Column]== 'float')):
		                command = ['hadoop', 'jar', '/home/kishan/Apache/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar',
		                      '-file' ,'/home/kishan/Project/SQL/mapper_aggregate_queries.py' ,'-mapper' ,'\"python3 mapper_aggregate_queries.py\"',
		                       '-file','/home/kishan/Project/SQL/reducer_min.py','-reducer' ,'\"python3 reducer_min.py\"', '-output',
		                       '/final_output', '-input']
		                command.append(input1)   
		            else:
		                print('ERROR : Cannot apply aggregate function : Can be applied only to Column with datatype integer and float')
		                exit(0)
		                            
		    elif query[-1]=='max':
		        Column = query[1]
		        l = list(d.keys())
		        if Column in l:
		            if ((d[Column] == 'integer') or (d[Column] == 'float')):
		                command = ['hadoop', 'jar', '/home/kishan/Apache/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar',
		                      '-file' ,'/home/kishan/Project/SQL/mapper_aggregate_queries.py' ,'-mapper' ,'\"python3 mapper_aggregate_queries.py\"',
		                       '-file','/home/kishan/Project/SQL/reducer_max.py','-reducer' ,'\"python3 reducer_max.py\"', '-output',
		                       '/final_output', '-input']
		                command.append(input1) 
		            else:
		                print('ERROR : Cannot apply aggregate function : Can be applied only to Column with datatype integer and float')
		                exit(0)
		                
		    elif query[-1]=='count':
		        command = ['hadoop', 'jar', '/home/kishan/Apache/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar',
		                      '-file' ,'/home/kishan/Project/SQL/mapper_aggregate_queries.py' ,'-mapper' ,'\"python3 mapper_aggregate_queries.py\"',
		                       '-file','/home/kishan/Project/SQL/reducer_count.py','-reducer' ,'\"python3 reducer_count.py\"', '-output',
		                       '/final_output', '-input']
		        command.append(input1)
		        #print(command) 
		    else:
		        if((len(query)>4 and re.search(query[4],'AGGREGATE_BY')) or (len(query)>6 and re.search(query[6],'AGGREGATE_BY'))):
		            print("This aggregate function is not supported")
		            exit()
		        else:
		            with open("/home/kishan/Project/SQL/mapper_select_queries.py") as f:
		            	lines = f.readlines()
		            lines[1] = 'query_list = ' + str(query) + '\n'
		            with open("/home/kishan/Project/SQL/mapper_select_queries.py", "w") as f:
		            	f.writelines(lines)
		            input1 = '/' + query[3]
		            command = ['hadoop', 'jar', '/home/kishan/Apache/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar',
				                  '-file' ,'/home/kishan/Project/SQL/mapper_select_queries.py' ,'-mapper' ,'\"python3 mapper_select_queries.py\"',
				                   '-file','/home/kishan/Project/SQL/reducer_select.py','-reducer' ,'\"python3 reducer_select.py\"', '-output',
				                   '/final_output', '-input']
		            command.append(input1)
		       
		    o= run_command(command)
		    #print(o)

		    with hdfs.open('/final_output/part-00000') as f:
		        for line in f:
		            print(line.decode('utf-8'))
		    
		    del_command = ['hadoop','fs','-rm','/final_output/*']
		    frm = run_command(del_command)

		    del_dir = ['hadoop','fs','-rmdir','/final_output']
		    drm = run_command(del_dir)

		else:
		    print("Invalid syntax: The query should begin with select and have a from statement")
	elif(option==3):
	    exit()

