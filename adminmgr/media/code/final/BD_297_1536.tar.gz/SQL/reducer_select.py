from __future__ import print_function
import sys

#output of the mapper passed to the reducer
for i in sys.stdin:
        i=i.split("::") #split based on semicolon (t::t)
        print(i[0])

