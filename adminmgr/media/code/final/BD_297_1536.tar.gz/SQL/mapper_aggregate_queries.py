from __future__ import print_function
query_list = ['SELECT', 'home_goals', 'FROM', 'res/results.csv']
import sys
import re
from collections import OrderedDict

def return_index(list1,list2,d):
    pos = []    
    for i in list1.split(','):
        if(i in list2):
            pos.append(list2.index(i))
    return pos 

d = OrderedDict()
#schema
with open('/home/kishan/Project/SQL/schema.txt') as f:
    for line in f:
        list1 = line.split(',')
        for i in list1:
            (key,val) = i.split(':')
            d[key] = val
            
indexes = [] #get the indexes of the required columns

#for where condition
flag=0
if len(query_list) > 7:
    if(re.search('=',query_list[5])):
        column,val = query_list[5].split('=')
        reqd_column = return_index(column,list(d.keys()),d)
    elif(re.search('<',query_list[5])):
        column,val = query_list[5].split('<')
        reqd_column = return_index(column,list(d.keys()),d)
        flag=1
    elif(re.search('>',query_list[5])):
        column,val = query_list[5].split('>')
        reqd_column = return_index(column,list(d.keys()),d)
        flag=2
       
else: #for other aggregate functions    
    indexes = return_index(query_list[1],list(d.keys()),d)
       
r = sys.stdin
for i in r:
    rows = i.split(',')
    string1 = '' 
    #without where condition
    if len(query_list) < 8 :
        if query_list[-1]=='count':
                        for j in indexes:
                            string1 = string1 + str(rows[j]) + '||'
                        if(len(indexes)):
                            print("%s::%s" % (string1[:-1],string1))
        else:
                print("%s,%s" % (list(d.keys())[indexes[0]],rows[indexes[0]]))
            
    else: #with where condition
        #print(reqd_column[0])
        if(flag==0):
            if rows[reqd_column[0]] == val:
            	if query_list[-1]=='count':
                    for j in reqd_column:
                    	string1 = string1 + str(rows[j]) + '||'
                    if(len(reqd_column)):
                    	print("%s::%s" % (string1[:-1],string1))
            	else:
                    print("%s,%s" % (list(d.keys())[indexes[0]],rows[indexes[0]]))
        elif(flag==1):
            if rows[reqd_column[0]] < val:
                if query_list[-1]=='count':
                    for j in reqd_column:
                        string1 = string1 + str(rows[j]) + '||'
                    if(len(reqd_column)):
                        print("%s::%s" % (string1[:-1],string1))
                else:
                    print("%s,%s" % (list(d.keys())[indexes[0]],rows[indexes[0]]))
        elif(flag==2):
            if rows[reqd_column[0]] > val:
            	if query_list[-1]=='count':
	            	for j in reqd_column:
                		string1 = string1 + str(rows[j]) + '||'
            		if(len(reqd_column)):
            			print("%s::%s" % (string1[:-1],string1))
            	else:
                    print("%s,%s" % (list(d.keys())[indexes[0]],rows[indexes[0]]))
    
    

