python3 kmc_batsmandataprep.py < BattingAverages2017.csv
python3 kmc_bowlerdataprep.py < BowlingAverages2017.csv
