
import csv
import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext
import math

sc = SparkContext()

def parse_data(row):
	x= row.split(',')
	x[0]= str(x[0])
	x1 = float(x[1])
	y = float(x[2])
	return(x[0], x1,y)
def parse_data1(row):
	x= row.split(',')
	return(float(x[1]), float(x[2]))
def p(x):
	print(x)

def find_distance(x):
	s = tuple()
	d = math.sqrt(pow((x[0][1] - x[1][0]),2) + pow((x[0][2] - x[1][1]),2))
	s = (d,x[1][0],x[1][1],x[0][1], x[0][2])
	return (x[0][0],s)
def rearrange (x):
	s = str(x[1][1])+','+str(x[1][2])
	count = 1
	return (s,(x[1][3],x[1][4],count))

def findtotal(x,y):
	sum1 = x[1][0] + y[1][0]
	sum2 = x[1][1] + y[1][1]
	count = x[1][2] + y[1][2]
	return (x[0],(sum1, sum2, count))
def new_centroids_calc(x):
	new_x = round(x[1][0]/x[1][2],4)
	new_y = round(x[1][1]/x[1][2],4)
	return (new_x , new_y)
def min_distance(x,y):
	if(x>y):
		return (y)
	else:
		return (x)
def rearrange_pt3(x):
	return (x[1][0],x[1][1])
j=0
def clust_number(x):
	global j
	j = j + 1
	s = str(x[0]) + ',' + str(x[1])
	return (s,j)
def rearrange_pt2(x):
	s = str(x[1][1]) + ',' + str(x[1][2])
	return (s,x[0])
	
def tolineCSVdata(x):
	return ','.join(str(d) for d in x)	
if __name__ == "__main__":

	# Initialize the spark context.
	spark = SparkSession\
		.builder\
		.appName("sc")\
		.getOrCreate()
	lines = spark.read.text(sys.argv[1]).rdd.map(lambda r: r[0])
	#reading batsman name along with ave and SR
	links = lines.map(parse_data)
	#reading ave and SR
	mid_cent = lines.map(parse_data1)
	#selecting random centroids 
	centroids = mid_cent.takeSample(False, 7)
	#converting to RDD
	centroids = sc.parallelize(centroids)
	#Catersian product of every centroid and batsman
	cartesian_product = links.cartesian(centroids)
	#distance for each combination 
	distance_mid = cartesian_product.map(find_distance)
	#finding the minimuin distance 
	distance_final = distance_mid.reduceByKey(min_distance)	
	#find total for each centroid 
	averages_mid = distance_final.map(rearrange) 
	averages_mid_2 = averages_mid.reduceByKey(lambda x, y: (x[0]+y[0] , x[1]+y[1], x[2]+y[2]))
	#dividing by count to get new centroid 
	new_cent = averages_mid_2.map(new_centroids_calc)
	#compare new and old centroid  
	new_centroids = new_cent.collect()
	old_centroids = centroids.collect()
	#Checking new and old 
	for i in range(len(old_centroids)):
		if(new_centroids[i] not in old_centroids):
			flag = True 
			break
		else:
			flag = False
	#Runs loop till old and new centroids match  
	while flag:
		old_cent = new_cent
		cartesian_product = links.cartesian(old_cent)
		distance_mid = cartesian_product.map(find_distance)
		distance_final = distance_mid.reduceByKey(min_distance)	
		averages_mid = distance_final.map(rearrange) 
		averages_mid_2 = averages_mid.reduceByKey(lambda x, y: (x[0]+y[0] , x[1]+y[1], x[2]+y[2]))
		new_cent = averages_mid_2.map(new_centroids_calc)
		new_centroids = new_cent.collect()
		old_centroids = old_cent.collect()
		for i in range(len(old_centroids)):
			if(new_centroids[i]  not in old_centroids):
				flag = True 
				break
			else:
				flag = False
		
	clus_number = new_cent.map(clust_number)
	batsmen = distance_final.map(rearrange_pt2)
	mid_batsmen = batsmen.join(clus_number)
	final_batsmen = mid_batsmen.map(rearrange_pt3)
	final_batsmen = final_batsmen.map(tolineCSVdata)
	final_batsmen.saveAsTextFile("/cluster/bowler_output3.csv")
	#final = final_batsmen.map(lambda x :x)
	
	
	#centroids = centroids.rdd.map(list)
	
	#lines = spark.read.csv(sys.argv[1], header = False)
	#links = lines.rdd.map(list)
	#links = lines1.map(lambda urls: parse_data(urls))
	#clus_number.foreach(p)
	final_batsmen.foreach(p)

	

	
