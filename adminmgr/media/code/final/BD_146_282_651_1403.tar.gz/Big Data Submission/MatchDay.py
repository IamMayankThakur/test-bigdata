import csv
import random
import pandas as pd

team1Bat=[]
team1Bowl=[]
team2Bat=[]
team2Bowl=[]
with open('finalinput.csv','r') as InputFile:
    Teams=csv.reader(InputFile)
    for teams in Teams:
        team1Bat.append(teams[0])
        team1Bowl.append(teams[1])
        team2Bat.append(teams[2])
        team2Bowl.append(teams[3])
team1Bat=team1Bat[1:]
team1Bowl=team1Bowl[1:]
team2Bat=team2Bat[1:]
team2Bowl=team2Bowl[1:]

#print(team1)
#print(team2)
def player_player(batsmen, bowler):
    with open('P2P.csv','r') as Player_PlayerFile:
        playerprofiles=csv.reader(Player_PlayerFile)
        for profile in playerprofiles:
            if(profile[0]==batsmen and profile[1]==bowler):
                profile=list(map(float,profile[2:9]))
                profile.insert(0,batsmen)
                profile.insert(1,bowler)
                return profile
                #returns 0 1 2 3 4 6 Out
            

def cluster_cluster(batCN,bowlCN):
    with open('C2C.csv','r') as Cluster_ClusterFile:
        clusterprofiles=csv.reader(Cluster_ClusterFile)
        for cluster in clusterprofiles:
            if(cluster[0]==str(batCN) and cluster[1]==str(bowlCN)):
                cluster=list(map(float,cluster))
                return cluster
                #returns BatCN BowlCN 0 1 2 3 4 6 Out
        

def cluster_number(batsmen, bowler):
    with open('final_batsman_clusters.csv','r') as BatClusterFile:
        batclusfile=csv.reader(BatClusterFile)
        for bat in batclusfile:
            if(bat[0]==batsmen):
                batCN=bat[1]
        
    with open('final_bolwer_clusters.csv','r') as BowlClusterFile:
        bowlclusfile=csv.reader(BowlClusterFile)
        for bowl in bowlclusfile:
            if(bowl[0]==bowler):
                bowlCN=bowl[1]
            
    return int(batCN),int(bowlCN)
    #returns Cluster Numbers

#print(player_player('R Dravid','AB Dinda'))
#print(cluster_cluster(1,2))
#print(cluster_number('V Kohli','AB Dinda'))

#Now comes the main prediction part: 
#Find the cumulative probabilities for both players and clusters and store it into a different csv files
#PlayerCumulative.csv: Bat,Bowl,0,1,2,3,4,6,NotOut
#ClusterCumulative.csv: BatCN,BowlCN,0,1,2,3,4,6,NotOut
BatClustFile=open('PlayerCumulative.csv','w')
header=['Batsman','Bowler','0','1','2','3','4','6','NotOut']
Batfile=csv.DictWriter(BatClustFile,fieldnames=header)
Batfile.writeheader()
with open('P2P.csv','r') as BatsmenFile:
    Batsmenfile=csv.reader(BatsmenFile)
    next(Batsmenfile,None)
    for player in Batsmenfile:
        batsmen=player[0]
        bowler=player[1]
        player=list(map(float,player[2:]))
        Batfile.writerow({'Batsman':batsmen,'Bowler':bowler,'0':player[0],'1':player[0]+player[1],'2':player[0]+player[1]+player[2],'3':player[0]+player[1]+player[2]+player[3],'4':player[0]+player[1]+player[2]+player[3]+player[4],'6':player[0]+player[1]+player[2]+player[3]+player[4]+player[5],'NotOut':1-player[6]})
BatsmenFile.close()
BatClustFile.close()

ClustFile=open('ClusterCumulative.csv','w')
header=['BatCN','BowlCN','0','1','2','3','4','6','NotOut']
Clustfile=csv.DictWriter(ClustFile,fieldnames=header)
Clustfile.writeheader()
with open('C2C.csv','r') as BatsmenFile:
    Clusterfile=csv.reader(BatsmenFile)
    next(Clusterfile,None)
    for player in Clusterfile:
        batCN=player[0]
        bowlCN=player[1]
        player=list(map(float,player[2:]))
        Clustfile.writerow({'BatCN':batCN,'BowlCN':bowlCN,'0':player[0],'1':player[0]+player[1],'2':player[0]+player[1]+player[2],'3':player[0]+player[1]+player[2]+player[3],'4':player[0]+player[1]+player[2]+player[3]+player[4],'6':player[0]+player[1]+player[2]+player[3]+player[4]+player[5],'NotOut':1-player[6]})
BatsmenFile.close()
ClustFile.close()

#PlayerCumulative.csv: Bat,Bowl,0,1,2,3,4,6,NotOut
#ClusterCumulative.csv: BatCN,BowlCN,0,1,2,3,4,6,NotOut

#we define functions to find the runs by generating a random and checking
playerProb=pd.read_csv('PlayerCumulative.csv')
clustProb=pd.read_csv('ClusterCumulative.csv')

def playerRuns(Bat, Bowl):
    stat=playerProb.loc[playerProb['Batsman']==Bat].loc[playerProb['Bowler']==Bowl]
    prob_0=stat['0']
    prob_1=stat['1']
    prob_2=stat['2']
    prob_3=stat['3']
    prob_4=stat['4']
    prob_6=stat['6']
    run_prob=random.random()
    #print(run_prob)
    if(run_prob<=prob_0).bool()==True: return 0
    elif(run_prob<=prob_1).bool()==True: return 1
    elif(run_prob<=prob_2).bool()==True: return 2
    elif(run_prob<=prob_3).bool()==True: return 3
    elif(run_prob<=prob_4).bool()==True: return 4
    elif(run_prob<=prob_6).bool()==True: return 6

#stat1=playerRuns('DJ Hussey', 'CL White')#R15
#print(stat1)
def clusterRuns(BatCN, BowlCN):
    #print(type(clustProb['BatCN']))
    #print(type(BatCN))
    stat=clustProb.loc[clustProb['BatCN']==int(BatCN)].loc[clustProb['BowlCN']==int(BowlCN)]
    prob_0=stat['0']
    prob_1=stat['1']
    prob_2=stat['2']
    prob_3=stat['3']
    prob_4=stat['4']
    prob_6=stat['6']
    run_prob=random.random()
    #print(run_prob)
    #print(stat)
    #print((stat['NotOut']))
    #print(type(stat['NotOut']))
    if(run_prob<=prob_0).bool()!=False: return 0
    elif(run_prob<=prob_1).bool()==True: return 1
    elif(run_prob<=prob_2).bool()==True: return 2
    elif(run_prob<=prob_3).bool()==True: return 3
    elif(run_prob<=prob_4).bool()==True: return 4
    elif(run_prob<=prob_6).bool()==True: return 6
#stat2=clusterRuns(1, 2)#R15
#print(stat2)

# Now, we go on to start playing the game.
#i/p:
#team1Bat: batting order of team 1
#team1Bowl bowling order of team 1
#team2Bat batting order of team 2
#team2Bowl bowling order of team 2

def innings1(team1Bat, team2Bowl):
    on_strike=team1Bat[0]
    off_strike=team1Bat[1]
    bowler=team2Bowl[0]
    next_bat=2  #if one player gets out and then while wicket handling we'll make it %11
    next_bowl=2
    wickets=balls=runs=no_of_overs=0
    prob_nWick=1
    dic_pair={}
    dic_pair[on_strike]=dic_pair[off_strike]=1
    print("On-strike: ",on_strike)
    print("Off-strike: ",off_strike)
    while(no_of_overs<20 and wickets<10):
        balls=1
        is_cluster=False
        while(balls<=6 and wickets<10):
            try:
                stat=playerProb.loc[playerProb['Batsman']==on_strike].loc[playerProb['Bowler']==bowler]
                not_wicket_prob=float(stat['NotOut'])
            except:
                #print("in cluster")
                BatCN,BowlCN=cluster_number(on_strike,bowler)
                stat=clustProb.loc[clustProb['BatCN']==BatCN].loc[clustProb['BowlCN']==BowlCN]
                not_wicket_prob=float(stat['NotOut'])
                is_cluster=True
            run_ball=0
            is_wicket=False
            prob_nWick=prob_nWick*not_wicket_prob
            dic_pair[on_strike]*=not_wicket_prob#change here if error to not_...
            if(dic_pair[on_strike]>=0.5):
                if(is_cluster==False):
                    run_ball=playerRuns(on_strike,bowler)
                else:
                    run_ball=clusterRuns(batCN,bowlCN)
            elif(dic_pair[on_strike]<0.5):
                print('Out!')
                wickets+=1
                on_strike=team1Bat[next_bat]
                next_bat=(next_bat+1)%11
                is_wicket=True
                dic_pair[on_strike]=1
                balls=balls+1
                if(balls>6): break
            if(is_wicket==False):
                runs=runs+run_ball
                if(run_ball==1 or run_ball==3):
                    on_strike,off_strike=off_strike,on_strike
            print("{0:10d}\t{1:10d}\t\t{2:20s}\t{3:20s}\t{4:20s}".format(balls,run_ball,on_strike,off_strike,bowler))#On strike determines the batsmen who is on strike at the end of the over.
            balls+=1
        on_strike,off_strike=off_strike,on_strike
        bowler=team2Bowl[next_bowl]
        next_bowl=(next_bowl+1)%5+1
        no_of_overs+=1
        #print("{0:10d} {1:10d}".format(runs,no_of_overs))
    print("Score at the end of Innings 1: ",runs)
    if(no_of_overs==20):
        print("Overs: ",no_of_overs)
    else:
        print("Overs: %d Balls: %d"%(no_of_overs,balls-1))
    return runs

def innings2(team1Bat, team2Bowl, Inn1Runs):
    on_strike=team1Bat[0]
    off_strike=team1Bat[1]
    bowler=team2Bowl[0]
    next_bat=2  #if one player gets out and then while wicket handling we'll make it %11
    next_bowl=2
    wickets=balls=runs=no_of_overs=not_wicket_prob=0
    prob_nWick=1
    dic_pair={}
    dic_pair[on_strike]=dic_pair[off_strike]=1
    print("On-strike: ",on_strike)
    print("Off-strike: ",off_strike)
    while(no_of_overs<20 and wickets<10):
        balls=1
        is_cluster=False
        while(balls<=6 and wickets<10):
            try:
                stat=playerProb.loc[playerProb['Batsman']==on_strike].loc[playerProb['Bowler']==bowler]
                not_wicket_prob=float(stat['NotOut'])
            except:
                #print("in Cluster")
                BatCN,BowlCN=cluster_number(on_strike,bowler)
                stat=clustProb.loc[clustProb['BatCN']==BatCN].loc[clustProb['BowlCN']==BowlCN]
                not_wicket_prob=float(stat['NotOut'])
                is_cluster=True
            run_ball=0
            is_wicket=False
            prob_nWick=prob_nWick*not_wicket_prob
            dic_pair[on_strike]*=not_wicket_prob#change here if error to not_...
            if(dic_pair[on_strike]>=0.5):
                if(is_cluster==False):
                    run_ball=playerRuns(on_strike,bowler)
                else:
                    run_ball=clusterRuns(batCN,bowlCN)
            elif(dic_pair[on_strike]<0.5):
                print("Out!")
                wickets+=1
                on_strike=team1Bat[next_bat]
                next_bat=(next_bat+1)%11
                is_wicket=True
                dic_pair[on_strike]=1
                balls+=1
                if(balls>6): break
            if(is_wicket==False):
                runs=runs+run_ball
                if(run_ball==1 or run_ball==3):
                    on_strike,off_strike=off_strike,on_strike
            print("{0:10d}\t{1:10d}\t\t{2:20s}\t{3:20s}\t{4:20s}".format(balls,run_ball,on_strike,off_strike,bowler))#On strike determines the batsmen who is on strike at the end of the over.
            balls+=1
        on_strike,off_strike=off_strike,on_strike
        bowler=team2Bowl[next_bowl]
        next_bowl=(next_bowl+1)%5+1
        no_of_overs+=1
        #print("{0:10d}{1:10d}".format(runs,no_of_overs))
        if(runs>Inn1Runs): break
    print("Score at the end of Innings 2: ",runs)
    if(no_of_overs==20):
        print("Overs: ",no_of_overs)
    else:
        print("Overs: %d Balls: %d"%(no_of_overs,balls-1))
    return runs
#print('{0:10s} {1:10s} {2:10s} {3:10s}'.format(team1Bat,team1Bowl,team2Bat,team2Bowl))
print("#####################--First Innings--#########################")
print("Ball No.\t\tRun\t\tStriker\t\t\tNon-Striker\t\tBowler")
runs1=innings1(team1Bat,team2Bowl)
print("#####################--Second Innings--#########################")
print("Ball No.\t\tRun\t\tStriker\t\t\tNon-Striker\t\tBowler")
runs2=innings2(team2Bat,team1Bowl,runs1)

if(runs1>runs2):
    print("Team 1 Wins!")
elif(runs2>runs1):
    print("Team 2 Wins!")
else:
    print("Match Tied :( ")




        





