import sys
import csv
from collections import defaultdict
import pandas as pd

with open('ipl_merged.csv','r') as ReaderFile:
    file1=csv.reader(ReaderFile)
    with open('ipl_player.csv','w') as WriterFile:
        file2=csv.writer(WriterFile, delimiter=',')
        for row in file1:
            #print(row)
            if(row[0] == 'ball'):
                wicket=row[9]
                if(wicket==''):
                    file2.writerow([row[4],row[6],row[7],'0'])
                else:
                    file2.writerow([row[4],row[6],row[7],'1'])
    WriterFile.close()
ReaderFile.close()
#ipl_player.csv contains the [Batsman, Bowler, Runs_that_ball, Out or Not Out[1 or 0]]

d=defaultdict(list)
with open('ipl_player.csv','r') as readingFile:
    file3=csv.reader(readingFile)
    for line in file3:
        l=[line[2],line[3]]
        d[line[0],line[1]].append(l)
readingFile.close()
#print(d)
#d has {(batsmen,bowler):[runs_that_ball,out(1) or not_out(0),().....}

outFile=open('P2P.csv','w')
header=['Batsman','Bowler','0','1','2','3','4','6','Wickets','Balls','BatCN','BowlCN']
file4=csv.DictWriter(outFile,fieldnames=header)
file4.writeheader()
#So as of now, my headers as above have been written into P2P.csv

#Calculate the probabilities of each now
#p for players and rw for runs and wickets
for p,rw in d.items():
    no_of_dots=no_of_ones=no_of_twos=no_of_threes=no_of_fours=no_of_sixes=no_of_wickets=0
    balls=0
    BatCN=BowlCN=0
    for runs in rw:
        r=runs[0]
        w=runs[1]
        if(r=='0'): no_of_dots+=1
        elif(r=='1'):no_of_ones+=1
        elif(r=='2'):no_of_twos+=1
        elif(r=='3'):no_of_threes+=1
        elif(r=='4'):no_of_fours+=1
        elif(r=='6'):no_of_sixes+=1
        if(w=='1'):no_of_wickets+=1
        balls+=1
    prob_0=no_of_dots/balls
    prob_1=no_of_ones/balls
    prob_2=no_of_twos/balls
    prob_3=no_of_threes/balls
    prob_4=no_of_fours/balls
    prob_6=no_of_sixes/balls
    prob_wicket=no_of_wickets/balls

    with open('final_batsman_clusters.csv') as BatReaderFile:
        file1=csv.reader(BatReaderFile)
        for row in file1:
            if row[0]== p[0]:
                BatCN=row[1]
                break
    with open('final_bolwer_clusters.csv') as BowlReaderFile:
        file2=csv.reader(BowlReaderFile)
        for row in file2:
            if row[0]== p[1]:
                BowlCN=row[1]
                break
    file4.writerow({'Batsman':p[0],'Bowler':p[1],'0':prob_0,'1':prob_1,'2':prob_2,'3':prob_3,'4':prob_4,'6':prob_6,'Wickets':prob_wicket,'Balls':balls,'BatCN':BatCN,'BowlCN':BowlCN})


#As of now I have my P2P statistics which gives the probabilties 
#of ['Batsman','Bowler','0','1','2','3','4','6','Wickets'] for batsman to bowler

df=pd.read_csv('P2P.csv')
final_df=df.drop(['Balls'], axis=1)
final_df=final_df.groupby(['BatCN','BowlCN']).mean().reset_index()
final_df.to_csv("C2C.csv", index=False)