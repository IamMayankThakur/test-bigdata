import csv
import random
import pandas as pd
import pyspark.sql.functions as sql_func
from pyspark.sql.types import *
from pyspark.ml.recommendation import ALS, ALSModel
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating

sc = SparkContext('local') 
spark = SparkSession(sc)
batsmen = []
bowlers = []
dataset = []
#reading the file as a list of lists
with open("P2P.csv", 'r') as file:
    csv_file = csv.reader(file)
    next(csv_file,None)
    for row in csv_file:
        if not row:
            continue
        dataset.append(row)

for i in dataset:
    batsmen.append(i[0])
    bowlers.append(i[1])
#creating the dictionary that gives each player an int index
list_bats=list(enumerate(batsmen))
dict_bat={}
for i in range(len(list_bats)):
    dict_bat[list_bats[i][1]]=list_bats[i][0]

list_bowl=list(enumerate(bowlers))
dict_bowl={}
for i in range(len(list_bowl)):
    dict_bowl[list_bowl[i][1]]=list_bowl[i][0]
team1Bat=[]
team1Bowl=[]
team2Bat=[]
team2Bowl=[]
with open('input.csv','r') as InputFile:
    Teams=csv.reader(InputFile)
    for teams in Teams:
        team1Bat.append(teams[0])
        team1Bowl.append(teams[1])
        team2Bat.append(teams[2])
        team2Bowl.append(teams[3])
team1Bat=team1Bat[1:]
team1Bowl=team1Bowl[1:]
team2Bat=team2Bat[1:]
team2Bowl=team2Bowl[1:]

#print(team1)
#print(team2)
def player_player(batsmen, bowler):
    with open('P2P.csv','r') as Player_PlayerFile:
        playerprofiles=csv.reader(Player_PlayerFile)
        for profile in playerprofiles:
            if(profile[0]==batsmen and profile[1]==bowler):
                profile=list(map(float,profile[2:9]))
                profile.insert(0,batsmen)
                profile.insert(1,bowler)
                return profile
                #returns 0 1 2 3 4 6 Out
            


def encoding_bat(x):
    for i in dict_bat.keys():
        if x==i:
            y=dict_bat[x]
            return y

def encoding_bowl(x):
    for i in dict_bowl.keys():
        if x==i:
            return dict_bowl[x]

data = sc.textFile("P2P.csv")
header=data.first()
head=sc.parallelize([header])
data1=data.subtract(head)
ratings = data1.map(lambda l: l.split(','))
predictions = []

def R0(testdata):
    ratings_final0 = []
    l0=ratings.collect()
    for i in range(len(l0)):
        r0= Rating(encoding_bat(l0[i][0]),encoding_bowl(l0[i][1]),float(l0[i][2]))
        ratings_final0.append(r0)
    ratings_final0=sc.parallelize(ratings_final0)
    #coll_filt for run 0
    rank0 = 10
    numIterations0 = 10
    model0 = ALS.train(ratings_final0,rank0,numIterations0)
    prediction0 = model0.predict(testdata[0],testdata[1])
    return prediction0

def R1(testdata):
    ratings_final1=[]
    l1=ratings.collect()
    for i in range(len(l1)):
        r1= Rating(encoding_bat(l1[i][0]),encoding_bowl(l1[i][1]),float(l1[i][3]))
        ratings_final1.append(r1)
    ratings_final1=sc.parallelize(ratings_final1)
    #coll_filt for run 1
    rank1 = 10
    numIterations1 = 10
    model1 = ALS.train(ratings_final1,rank1,numIterations1)
    prediction1 = model1.predict(testdata[0],testdata[1])
    return prediction1

def R2(testdata):
    ratings_final2=[]
    l2=ratings.collect()
    for i in range(len(l2)):
        r2= Rating(encoding_bat(l2[i][0]),encoding_bowl(l2[i][1]),float(l2[i][4]))
        ratings_final2.append(r2)
    ratings_final2=sc.parallelize(ratings_final2)
    #coll_filt for run 2
    rank2 = 10
    numIterations2 = 10
    model2 = ALS.train(ratings_final2,rank2,numIterations2)
    prediction2 = model2.predict(testdata[0],testdata[1])
    return prediction2

def R3(testdata):
    ratings_final3=[]
    l3=ratings.collect()
    for i in range(len(l3)):
        r3= Rating(encoding_bat(l3[i][0]),encoding_bowl(l3[i][1]),float(l3[i][5]))
        ratings_final3.append(r3)
    ratings_final3=sc.parallelize(ratings_final3)
    #coll_filt for run 3
    rank3 = 10
    numIterations3 = 10
    model3 = ALS.train(ratings_final3,rank3,numIterations3)
    prediction3 = model3.predict(testdata[0],testdata[1])
    return prediction3

def R4(testdata):
    ratings_final4=[]
    l4=ratings.collect()
    for i in range(len(l4)):
        r4= Rating(encoding_bat(l4[i][0]),encoding_bowl(l4[i][1]),float(l4[i][6]))
        ratings_final4.append(r4)
    ratings_final4=sc.parallelize(ratings_final4)
    #coll_filt for run 4
    rank4 = 10
    numIterations4 = 10
    model4= ALS.train(ratings_final4,rank4,numIterations4)
    prediction4 = model4.predict(testdata[0],testdata[1])
    return prediction4

def R6(testdata):
    ratings_final6=[]
    l6=ratings.collect()
    for i in range(len(l6)):
        r6= Rating(encoding_bat(l6[i][0]),encoding_bowl(l6[i][1]),float(l6[i][7]))
        ratings_final6.append(r6)
    ratings_final6=sc.parallelize(ratings_final6)
    #coll_filt for run 6
    rank6 = 10
    numIterations6 = 10
    model6 = ALS.train(ratings_final6,rank6,numIterations6)
    prediction6 = model6.predict(testdata[0],testdata[1])
    return prediction6

def RNW(testdata):
    ratings_finalw=[]
    lw=ratings.collect()
    for i in range(len(lw)):
        rw = Rating(encoding_bat(lw[i][0]),encoding_bowl(lw[i][1]),float(lw[i][8]))
        ratings_finalw.append(rw)
    ratings_finalw=sc.parallelize(ratings_finalw)
    #coll_filt for wickets
    rankw = 10
    numIterationsw = 10
    modelw = ALS.train(ratings_finalw,rankw,numIterationsw)
    predictionw = modelw.predict(testdata[0],testdata[1])
    return predictionw


#Now comes the main prediction part: 
#Find the cumulative probabilities for both players and clusters and store it into a different csv files
#PlayerCumulative.csv: Bat,Bowl,0,1,2,3,4,6,NotOut
#ClusterCumulative.csv: BatCN,BowlCN,0,1,2,3,4,6,NotOut
BatClustFile=open('PlayerCumulative.csv','w')
header=['Batsman','Bowler','0','1','2','3','4','6','NotOut']
Batfile=csv.DictWriter(BatClustFile,fieldnames=header)
Batfile.writeheader()
with open('P2P.csv','r') as BatsmenFile:
    Batsmenfile=csv.reader(BatsmenFile)
    next(Batsmenfile,None)
    for player in Batsmenfile:
        batsmen=player[0]
        bowler=player[1]
        player=list(map(float,player[2:]))
        Batfile.writerow({'Batsman':batsmen,'Bowler':bowler,'0':player[0],'1':player[0]+player[1],'2':player[0]+player[1]+player[2],'3':player[0]+player[1]+player[2]+player[3],'4':player[0]+player[1]+player[2]+player[3]+player[4],'6':player[0]+player[1]+player[2]+player[3]+player[4]+player[5],'NotOut':1-player[6]})
BatsmenFile.close()
BatClustFile.close()


#PlayerCumulative.csv: Bat,Bowl,0,1,2,3,4,6,NotOut


#we define functions to find the runs by generating a random and checking
playerProb=pd.read_csv('PlayerCumulative.csv')


def playerRuns(Bat, Bowl):
    stat=playerProb.loc[playerProb['Batsman']==Bat].loc[playerProb['Bowler']==Bowl]
    prob_0=stat['0']
    prob_1=stat['1']
    prob_2=stat['2']
    prob_3=stat['3']
    prob_4=stat['4']
    prob_6=stat['6']
    run_prob=random.random()
    #print(run_prob)
    if(run_prob<=prob_0).bool()==True: return 0
    elif(run_prob<=prob_1).bool()==True: return 1
    elif(run_prob<=prob_2).bool()==True: return 2
    elif(run_prob<=prob_3).bool()==True: return 3
    elif(run_prob<=prob_4).bool()==True: return 4
    elif(run_prob<=prob_6).bool()==True: return 6

#stat1=playerRuns('DJ Hussey', 'CL White')#R15
#print(stat1)
def CFRuns(PR0,PR1,PR2,PR3,PR4,PR6):
    prob0=PR0
    prob1=PR0+PR1
    prob2=PR0+PR1+PR2
    prob3=PR0+PR1+PR2+PR3
    prob4=PR0+PR1+PR2+PR3+PR4
    prob6=PR0+PR1+PR2+PR3+PR5+PR6
    run_prob=random.random()
    #print(run_prob)
    if(run_prob<=prob0): return 0
    elif(run_prob<=prob1): return 1
    elif(run_prob<=prob2): return 2
    elif(run_prob<=prob3): return 3
    elif(run_prob<=prob4): return 4
    elif(run_prob<=prob6): return 6

# Now, we go on to start playing the game.
#i/p:
#team1Bat: batting order of team 1
#team1Bowl bowling order of team 1
#team2Bat batting order of team 2
#team2Bowl bowling order of team 2

def innings1(team1Bat, team2Bowl):
    on_strike=team1Bat[0]
    off_strike=team1Bat[1]
    bowler=team2Bowl[0]
    next_bat=2  #if one player gets out and then while wicket handling we'll make it %11
    next_bowl=2
    wickets=balls=runs=no_of_overs=0
    prob_nWick=1
    dic_pair={}
    dic_pair[on_strike]=dic_pair[off_strike]=1
    print("On-strike: ",on_strike)
    print("Off-strike: ",off_strike)
    while(no_of_overs<20 and wickets<10):
        balls=1
        is_CF=False
        while(balls<=6 and wickets<10):
            try:
                stat=playerProb.loc[playerProb['Batsman']==on_strike].loc[playerProb['Bowler']==bowler]
                not_wicket_prob=stat['NotOut']
            except:
                #print("in cluster")
                testdata=(encoding_bat(on_strike),encoding_bowl(bowler))
                not_wicket_prob=1-(RNW(testdata))
                is_CF=True
            run_ball=0
            is_wicket=False
            prob_nWick=prob_nWick*not_wicket_prob
            dic_pair[on_strike]*=not_wicket_prob#change here if error to not_...
            if((dic_pair[on_strike]>=0.5).bool()==True):
                if(is_CF==False):
                    run_ball=playerRuns(on_strike,bowler)
                else:
                    testdata=(encoding_bat(on_strike),encoding_bowl(bowler))
                    PRun0=R0(testdata)
                    PRun1=R1(testdata)
                    PRun2=R2(testdata)
                    PRun3=R3(testdata)
                    PRun4=R4(testdata)
                    PRun6=R6(testdata)
                    run_ball=CFRuns(PRun0,PRun1,PRun2,PRun3,PRun4,PRun6)
            elif((dic_pair[on_strike]<0.5).bool()==True):
                print('Out!')
                wickets+=1
                on_strike=team1Bat[next_bat]
                next_bat=(next_bat+1)%11
                is_wicket=True
                dic_pair[on_strike]=1
                balls=balls+1
                if(balls>6): break
            if(is_wicket==False):
                runs=runs+run_ball
                if(run_ball==1 or run_ball==3):
                    on_strike,off_strike=off_strike,on_strike
            print("{0:10d}\t{1:10d}\t\t{2:20s}\t{3:20s}\t{4:20s}".format(balls,run_ball,on_strike,off_strike,bowler))#On strike determines the batsmen who is on strike at the end of the over.
            balls+=1
        on_strike,off_strike=off_strike,on_strike
        bowler=team2Bowl[next_bowl]
        next_bowl=(next_bowl+1)%5+1
        no_of_overs+=1
        #print("{0:10d} {1:10d}".format(runs,no_of_overs))
    print("Score at the end of Innings 1: ",runs)
    if(no_of_overs==20):
        print("Overs: ",no_of_overs)
    else:
        print("Overs: %d Balls: %d"%(no_of_overs,balls-1))
    return runs

def innings2(team1Bat, team2Bowl, Inn1Runs):
    on_strike=team1Bat[0]
    off_strike=team1Bat[1]
    bowler=team2Bowl[0]
    next_bat=2  #if one player gets out and then while wicket handling we'll make it %11
    next_bowl=2
    wickets=balls=runs=no_of_overs=0
    prob_nWick=1
    dic_pair={}
    dic_pair[on_strike]=dic_pair[off_strike]=1
    print("On-strike: ",on_strike)
    print("Off-strike: ",off_strike)
    while(no_of_overs<20 and wickets<10):
        balls=1
        is_CF=False
        while(balls<=6 and wickets<10):
            try:
                stat=playerProb.loc[playerProb['Batsman']==on_strike].loc[playerProb['Bowler']==bowler]
                not_wicket_prob=stat['NotOut']
            except:
                #print("in cluster")
                testdata=(encoding_bat(on_strike),encoding_bowl(bowler))
                not_wicket_prob=1-(RNW(testdata))
                is_CF=True
            run_ball=0
            is_wicket=False
            prob_nWick=prob_nWick*not_wicket_prob
            dic_pair[on_strike]*=not_wicket_prob#change here if error to not_...
            if((dic_pair[on_strike]>=0.5).bool()==True):
                if(is_CF==False):
                    run_ball=playerRuns(on_strike,bowler)
                else:
                    testdata=(encoding_bat(on_strike),encoding_bowl(bowler))
                    PRun0=R0(testdata)
                    PRun1=R1(testdata)
                    PRun2=R2(testdata)
                    PRun3=R3(testdata)
                    PRun4=R4(testdata)
                    PRun6=R6(testdata)
                    run_ball=CFRuns(PRun0,PRun1,PRun2,PRun3,PRun4,PRun6)
            elif((dic_pair[on_strike]<0.5).bool()==True):
                print('Out!')
                wickets+=1
                on_strike=team1Bat[next_bat]
                next_bat=(next_bat+1)%11
                is_wicket=True
                dic_pair[on_strike]=1
                balls=balls+1
                if(balls>6): break
            if(is_wicket==False):
                runs=runs+run_ball
                if(run_ball==1 or run_ball==3):
                    on_strike,off_strike=off_strike,on_strike
            print("{0:10d}\t{1:10d}\t\t{2:20s}\t{3:20s}\t{4:20s}".format(balls,run_ball,on_strike,off_strike,bowler))#On strike determines the batsmen who is on strike at the end of the over.
            balls+=1
        on_strike,off_strike=off_strike,on_strike
        bowler=team2Bowl[next_bowl]
        next_bowl=(next_bowl+1)%5+1
        no_of_overs+=1
        #print("{0:10d}{1:10d}".format(runs,no_of_overs))
        if(runs>Inn1Runs): break
    print("Score at the end of Innings 2: ",runs)
    if(no_of_overs==20):
        print("Overs: ",no_of_overs)
    else:
        print("Overs: %d Balls: %d"%(no_of_overs,balls-1))
    return runs
#print('{0:10s} {1:10s} {2:10s} {3:10s}'.format(team1Bat,team1Bowl,team2Bat,team2Bowl))
print("#####################--First Innings--#########################")
print("Ball No.\t\tRun\t\tStriker\t\t\tNon-Striker\t\tBowler")
runs1=innings1(team1Bat,team2Bowl)
print("#####################--Second Innings--#########################")
print("Ball No.\t\tRun\t\tStriker\t\t\tNon-Striker\t\tBowler")
runs2=innings2(team2Bat,team1Bowl,runs1)

if(runs1>runs2):
    print("Team 1 Wins!")
elif(runs2>runs1):
    print("Team 2 Wins!")
else:
    print("Match Tied :( ")