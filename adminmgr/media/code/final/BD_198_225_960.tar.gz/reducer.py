#! /usr/bin/python
import sys
count=0
l=[]
l1=[]
for line1 in sys.stdin:
    line=line1.strip('\n')
    main_split=line.split("=")
    a=main_split[0].split("+")          
    a.pop(-1)           
    com=main_split[1].strip("\n")
    c=com.split(";")
    comp=c[0]
    l.append([a,int(line1.split(",")[1].strip('\n'))])              
    count=count+1

if(comp=='MAX'):
    a=max(l, key=lambda x: x[1])[0]
    print(" ".join(a))
elif(comp=='MIN'):
    a=min(l, key=lambda x: x[1])[0]
    print(" ".join(a))
elif(comp=='count'):
    print(count)
else:
    for i in range(len(l)):
        print(" ".join(l[i][0]))

