line="select id,a5,a1 from test where a1 = a AND a5 > 2 ;"
a1="id a1 a2 a3 a4 a5 a6 a7 a8 a9 a10"

a1="id a1 a2 a3 a4 a5 a6 a7 a8 a9 a10"




import sys
def query(line):
    
    a=[]
    command=[]
    agg=[]
    query = line.split(' ')
    query[1] = query[1].split(',')
    a = query[1]
    filename=""
    filename=query[3]+"."+"txt"
    if 'MAX' in query:
        index=query.index('MAX')
        agg.append(query[index])
        agg.append(query[index+1])

    if 'MIN' in query:
        index=query.index('MIN')
        agg.append(query[index])
        agg.append(query[index+1])
            
    if 'count' in query:
        index=query.index('count')
        agg.append(query[index])
        agg.append(query[index+1])
           
    if 'where' in query:
        start_index=query.index('where')
        and_index=[i for i, x in enumerate(query) if x == 'AND']
        if(len(and_index)!=0):
            end_index_and=and_index[0]
            index_and=slice(start_index+1, end_index_and, 1)
            final=[]
            final.append(query[index_and])
            
            for i in range(len(and_index)):
                if(i+1<len(and_index)):
                    end_index_and=and_index[i+1]
                    start_index_and=and_index[i]
                    index_and_next=slice(start_index_and+1, end_index_and, 1)
                    final.append(query[index_and_next])

            start_index_last=and_index[len(and_index)-1]
            if(len(agg)==0):    #if where multiple AND no agg
                end_index_last=query.index(';')
                index_and_last=slice(start_index_last+1, end_index_last, 1)
                final.append(query[index_and_last])
            else:   #multiple AND and agg
                end_index_last=query.index(agg[0])
                index_and_last=slice(start_index_last+1, end_index_last, 1)
                final.append(query[index_and_last])
        elif(len(agg)==0):      #if no AND but no agg is there
            start_index=query.index('where')
            end_index=query.index(';')
            index_and=slice(start_index+1, end_index, 1)
            final=[]
            final.append(query[index_and])
        else:   #no AND but MIN is there
            start_index=query.index('where')
            end_index=query.index(agg[0])
            index_and=slice(start_index+1, end_index, 1)
            final=[]
            final.append(query[index_and])
            
        return([a,filename,final,agg])
    return([a,filename,"",""])


                         
def check(condition,value,num):
    if(condition=='>'):
        if(num>value):
            return 1
    if(condition=='<'):
        if(num<value):
            return 1
    if(condition=='='):
        if(num==value):
            return 1  


def where(k2,q):
    command = q[2]
    a=q[0]    
    if a[0]=='*':
        a.pop(0)
        for i in k2[0]:
            a.append(i)
    for i in range (len(command)):
        j=0
        while(j<len(command[i])):
            answer=[]
            count=[]
            col_name = command[i][j]
            j=j+1
            condition=command[i][j]
            j=j+1
            value=command[i][j]
            j=j+1
        for k in range(len(k2)):
            if(col_name in a):
                index=a.index(col_name)
                #print(col_name)
                num=k2[k][index]
                result=check(condition,value,num)
                if(result==1):
                    answer.append(k2[k])
                    count.append(1)
        k2=[]
        k2 = answer[:]
    return answer

def select(q,header):
    a=q[0]
    #print(a)
    command=q[2]
    final=[]
    index_list=[]
    k2=[]
    for line in sys.stdin:
        col = line.split(",")
        col = list(map(str.strip,col))
        final.append(col)
    if(a[0]!='*'):
        for i in range(len(a)):
            if a[i] in header[0]:
                #print(a[i])
                index=header[0].index(a[i])
                index_list.append(index)
                #print(index_list)
        for i in range(len(final)):
            k=[]
            for j in range(len(index_list)):
                k.append(final[i][index_list[j]])
            k2.append(k)
    else:
        k2 = final[:]
    return(k2)


def mapper(line,header):
    final=[]
    q=query(line)
    #print(q)
    #print(header)
    temp1=select(q,header)
    #print(temp1)

    temp3=[]
    if (q[2]!=''): #if where cond
        temp2=where(temp1,q)
        temp3=temp2
        t=''
        if(q[3]!=[]):
            coll=0
            for i in range(len(q[0])):
                if q[0][i]==q[3][1]: 
                    coll=i
            for i in range (0,len(temp2)):
                x=""
                c=0
                for j in range(len(temp2[i])):
                    if(j==len(temp2)):
                        x=x+str(temp2[i][j])
                    else:
                        x=x+str(temp2[i][j])+"+"
                    c=c+1
                t=x+"="+q[3][0]+";"+str(coll)
                k=temp3[i][coll]
                print(t,k,sep=',')

            #for i in temp2:
                #print(i,1,sep=",")

        else: # no aggregate function
            q[3]='No_value'
            for i in range (0,len(temp2)):
                x=""
                c=0
                for j in range(len(temp2[i])):
                    if(j==len(temp2)):
                        x=x+str(temp2[i][j])
                    else:
                        x=x+str(temp2[i][j])+"+"
                    c=c+1
                temp2[i]=x+"="+"No"+";"+q[3]
            for i in temp2:
                print(i,1,sep=",")

    else:  # no where condition
        #print(temp1)
        q[3]='No_value'
        for i in range (0,len(temp1)):
            x=""
            c=0
            for j in range(len(temp1[i])):
                if(j==len(temp1)):
                    x=x+str(temp1[i][j])
                else:
                    x=x+str(temp1[i][j])+"+"
                c=c+1
            temp1[i]=x+"="+"No"+";"+q[3]
        for i in temp1:
            print(i,1,sep=",")

header=a1.split(" ")
header=[header]

mapper(line,header)

