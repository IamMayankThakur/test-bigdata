import random
cluster={}
centroids={}
def nearest(row):
	minDist=100000
	center=100
	#print("here")
	for i in centroids.keys():
		d=0.0
		y=centroids[i]
		x=row
		d+=pow(float(x[4])-float(y[0]),2)
		d+=pow(float(x[5])-float(y[1]),2)
		d+=pow(float(x[6])-float(y[2]),2)		
		d+=pow(float(x[8])-float(y[3]),2)
		d+=pow(float(x[9])-float(y[4]),2)
		d+=pow(float(x[10])-float(y[5]),2)
		d+=pow(float(x[11])-float(y[6]),2)
		d+=pow(float(x[12])-float(y[7]),2)
		d=pow(d,0.5)
		if(d<minDist):
			minDist=d
			center=i
	return center

def centrr(data):
	datapoints=[]
	for row in data:
		required=[]
		required.append(float(row[4]))
		required.append(float(row[5]))
		required.append(float(row[6]))
		required.append(float(row[8]))
		required.append(float(row[9]))
		required.append(float(row[10]))
		required.append(float(row[11]))
		required.append(float(row[12]))
		datapoints.append(required)
	center=[]
	for i in zip(*datapoints):
		center.append(sum(i)/len(i))
	return center

file=open('bowler.csv','r')
data=list([x.strip() for x in file])
for i in range(10):
	centroids[i]=[]
	row=data[random.randint(1,len(data))].split(',')
	centroids[i].append(float(row[4]))
	centroids[i].append(float(row[5]))
	centroids[i].append(float(row[6]))
	centroids[i].append(float(row[8]))
	centroids[i].append(float(row[9]))
	centroids[i].append(float(row[10]))
	centroids[i].append(float(row[11]))
	centroids[i].append(float(row[12]))
#print(centroids)
file=open('bowler.csv','r')
for i in range(1000):
	con=1
	for row in file:
		if con==1:
			con=0
			continue																																							
		row=row.strip()
		row=row.split(',')
		#print("here")
		near=nearest(row)
		#print(near)
		if near not in cluster:
			cluster[near]=[]
		cluster[near].append(row)
	#print(cluster)

	for i in cluster:
		datapoints=cluster[i]
		center=centrr(datapoints)
		centroids[i]=center
#print(centroids)
out=open('BowlClust.csv','w')
for row in cluster:
	for i in cluster[row]:
		print(row)
		st=','.join(i[1:])+','+str(row)+'\n'
		out.write(st)
			


		