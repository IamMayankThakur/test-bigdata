import sys
for line in sys.stdin:
    line = line.strip()
    lst = line.split(",")

    batcluster = int(lst[0])
    bowlclust = int(lst[1])

    '''
			0,             1,	     2, 3, 4, 5, 6, 7, 8
			BatsmanCluster,BowlerCluster,0s,1s,2s,3s,4s,6s,Dismissal
    '''
    
    key = (batcluster,bowlclust)
    val = [float(lst[2]),float(lst[3]),float(lst[4]),float(lst[5]),float(lst[6]),float(lst[7]),float(lst[8])]

    print([key,val])