#!/usr/bin/python3
from operator import itemgetter
import sys
import csv
import ast

dict = {}
tmp = {}
for line in sys.stdin:
    lst = ast.literal_eval(line)
    if lst[0] not in dict:
        dict[lst[0]] = lst[1]
        tmp[lst[0]] = 1
    else:
        for i in range(7):
            dict[lst[0]][i]+=lst[1][i]
        tmp[lst[0]]+=1
for key in dict:
    for val in range(7):
        dict[key][val] = float(dict[key][val]/tmp[key])

lst_sort = []
for i in dict:
	lst_sort.append([i[0],i[1],dict[i][0],dict[i][1],\
        dict[i][2],dict[i][3],dict[i][4],dict[i][5],dict[i][6]])
lst = sorted(lst_sort, key=itemgetter(0,1))

clustAvgF=open("cluster_average_sorted.csv","w")
for i in lst:
        #print("%d,%d,%f,%f,%f,%f,%f,%f,%f"%(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8]))
        ind = str(str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3])+','+\
            str(i[4])+','+str(i[5])+','+str(i[6])+','+str(i[7])+','+str(i[8])+'\n')
        clustAvgF.write(ind)

clustAvgF.close()