#!/usr/bin/python3
import sys

for line in sys.stdin:
    line = line.strip()
    line = line.split(",")
    try:
            run = int(line[2])
            wicket = int(line[3])
            print(str([line[0], line[1],run, wicket]))
    except:
        pass