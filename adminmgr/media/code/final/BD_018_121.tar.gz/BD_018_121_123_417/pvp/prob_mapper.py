#!usr/bin/python3
import sys
for line in sys.stdin:
        line = line.strip()
        lst  = line.split(',')

        batsman = lst[0]
        bowler = lst[1]
        #key is a batsman bowler pair
        key = (batsman,bowler)
        #       0       1       2      3       4    6       Out     Run     Ball
        val = [lst[2],lst[3],lst[4],lst[5],lst[6],lst[7],lst[8],lst[9],lst[10]]

        for i in range(9):
            val[i] = int(val[i]) 
        
        print([key,val])