#!/usr/bin/python3
from operator import itemgetter
import sys
import csv
import ast

dict = {}
for line in sys.stdin:
    lst = ast.literal_eval(line)
    if lst[0] not in dict:
        dict[lst[0]] = lst[1]
    else:
        for i in range(9):
            dict[lst[0]][i]+=lst[1][i]
 #       0       1       2      3       4    6       Out     Run     Ball  
for i in dict:
    for j in range(7):
        dict[i][j]=float(dict[i][j]/dict[i][8])	

lst_sort = []
for i in dict:
	lst_sort.append([i[0], i[1],dict[i][0],dict[i][1],\
        dict[i][2],dict[i][3],dict[i][4],dict[i][5],dict[i][6],dict[i][7]])
lst = sorted(lst_sort, key=itemgetter(0,1))

clustAvgF=open("probability.csv","w")

for i in lst:
        #                                       Bat    Bowl  0  1   2      3   4    6    wick  runs
        #print("%s,%s,%f,%f,%f,%f,%f,%f,%f,%d"%(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9]))
        ind = str(str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3])+','+\
            str(i[4])+','+str(i[5])+','+str(i[6])+','+str(i[7])+','\
                +str(i[8])+','+str(i[9])+'\n')
        clustAvgF.write(ind)

clustAvgF.close()