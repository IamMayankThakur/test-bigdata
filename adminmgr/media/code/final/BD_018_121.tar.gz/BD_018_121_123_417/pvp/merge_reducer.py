#!/usr/bin/python3
from operator import itemgetter
import sys
import ast
final = {}

for line in sys.stdin:
    res = ast.literal_eval(line)
    tup = (res[0], res[1])
    if tup in final:
        if(res[2]==0):
            final[tup][0] += 1
        elif(res[2]==1):
            final[tup][1] += 1
        elif(res[2]==2):
            final[tup][2] += 1
        elif(res[2]==3):
            final[tup][3] += 1
        elif(res[2]==4):
            final[tup][4] += 1
        elif(res[2]==6):
            final[tup][5] += 1
        #wickets
        final[tup][6] += res[3]
        #runs
        final[tup][7] += res[2]
        #deliveries
        final[tup][8] += 1
    else:
        #initialise
        final[tup] = [0,0,0,0,0,0,res[3],res[2],1]
        if(res[2]==6):
            final[tup][5] = 1
        else:
            final[tup][res[2]] = 1
lis = []
for item in final.items():
    lis.append([item[0][0],item[0][1],item[1][0],item[1][1],item[1][2]\
        ,item[1][3],item[1][4],item[1][5],item[1][6],item[1][7],item[1][8]])
lis = sorted(lis, key=itemgetter(0,1))

clustAvgF=open("alldata.csv","w")
for i in lis:
        #print(i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7],i[8],i[9],i[10])
        ind = str(str(i[0])+','+str(i[1])+','+str(i[2])+','+str(i[3])+','+\
            str(i[4])+','+str(i[5])+','+str(i[6])+','+str(i[7])+','\
                +str(i[8])+','+str(i[9])+','+str(i[10])+'\n')
        clustAvgF.write(ind)

clustAvgF.close()
