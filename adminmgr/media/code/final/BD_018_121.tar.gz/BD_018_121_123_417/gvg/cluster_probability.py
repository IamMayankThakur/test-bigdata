groupVgroup={}
batF=open('BatClust.csv','r')
batCluster={}
for row in batF:
	values=row.split(',')
	key=values[-1].split("\n")[0]
	if key not in batCluster.keys():
		batCluster[key]=[]
	batCluster[key].append(values[0].strip())

bowF=open('BowlClust.csv','r')
bowCluster={}
for row in bowF:
	values=row.split(',')
	key=values[-1].split("\n")[0]
	if key not in bowCluster:
		bowCluster[key]=[]
	bowCluster[key].append(values[0].strip())

pvpF=open('probability.csv','r')
clustAvgF=open("cluster_average.csv","w")
for row in pvpF:
	values=row.split(',')
	for batClust in batCluster:
		for player in batCluster[batClust]:
			if values[0]==player:
				batsman=batClust
				break

	for bowClust in bowCluster:
		for player in bowCluster[bowClust]:
			if values[1]==player:
				bowler=bowClust
				break
	ind=str(batsman+','+bowler+','+values[2]+','+values[3]+','+values[4]+','+values[5]+','+values[6]+','+values[7]+','+values[8]+'\n')
	clustAvgF.write(ind)

clustAvgF.close()