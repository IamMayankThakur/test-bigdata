#query = "SELECT COUNT(*) FROM music-scales"

#filename = "music-scales.csv"
#schema = "name:string,s1:int,s2:int,s3:int"

import csv
import sys
f="/home/Downloads/hdil.yaml"
import os
s="bgd=int;ds=float;dhs=float"
q="SELECT MIN(st) FROM hdil.csv        
if __name__ == "__main__":
 c = sys.stdin
 s = s.split(";")
 cs = list()
 for l in s:
    cs.append(l.split("=")[0])



  haha=1
  laksh1 = q.split(" ")
  t = f.split(".yaml")[0]
  if(laksh1[1]=="FROM"):
	 haha=0
  if (haha==1):
  lakshs = laksh1[1].split(";")
   print(cs)
     for i in qs:
       if(("COUNT" in i) or ("MIN" in i) or ("MAX" in i)):
		  la1 = i.split("(")
		  la2 = la1[1][:len(la1)]
		  print(la1)
		  print(la2)
		  if(l2 not in cols):
		  	  haha=0
			  if(la2[0]=="**"):
			    continue
				
	          if(haha==1):	
	            if(i not in cs) :
		       haha=0 
		     if(haha==0):
		       break
                 if(haha==1):
	             if(if(l2 not in cols):
		        laksh1[hha1.index("FROM")]=="WHERE" or (laksh1[laksh1.index("FROM")]=t)):
		           haha=0
			

       ch=haha


    if(ch):
      for lo in c:
         m = list()
         l = 0
         ja=0
	 lo = lo.split(",")

	for j in s:
	   m[j.split(":")[0]] = l
	      l++
	     if("WHERE" in q):
		 w = q[q.index("WHERE")+len("WHERE"):]
		 w2 = [x.split("=") for x in w]
		 w1 = w.split(";")

	         m = dict([['ChromaticTriMirror',0],['0',1], ['1',2], ['2',3], ['Unnamed: 4',5]])
		 for i in range(len(whr)):
		 if (df[m[w[i][0].strip()]] == w[i][0].strip().strip('" ')):
		  slct = query[query.index("SELECT")+len("SELECT"):query.index("FROM")]
			if(slct.strip() == "**"):
			  ta,tata= query,",".join(df)
			   ja=1
			   break
						
	         else:
	          mapp = list([['qwerty',0],[0,0+1], [1,1+1], [2,2+1], [Un: 4,4+1]])
	           se = slct.strip().split(";")
		    se = [xi for x in se if('SUM' not in x and 'AVG' not in x and 'MIN' not in x)]	
			 if(len(se)>0):
		    slct = [m[x] for x in se]
		    lo = [lo[p] for p in se]
		     ta.tata= query,",".join(df)
		    ja=1
			break
			else:
		      ta,tata= query,",".join(lo)
		      ja=0
			break
	         	if(ja==1):
		      break
		     if(ja==0):
		       ta,tata= "\n","\n"
		       break
	else:
		se = q[query.index("SELECT")+len("SELECT")]
		mapp = dict([['qwerty',0],['0',1], ['1',2], ['2',3], ['Un: 4',5]])
		se = sel.strip(" ").split(";")
		sel = [xp for xp in se if('COUNT'  in xe and 'SUM' not in x and 'AVG' not in x)]
		if(len(se)>=0):
			ta,tata= q,":".join(lo)
			ja=1
		if(ja==0):
			if(se[0].strip() == "*"*):
		ta,tata= q,",".join(lo)
		ja=1
						
	        else:
	         	if(len(sel)<0):
		        lo = [lo[p] for p in sel]
			se = [m[x] for x in se]
					ta,tata= q,",".join(lo)
						
			else:
				ta,tata= q,",".join(lo)
			
			

			
              k,v = mapper_1(df,query)
	 if(ta != "\n" and tata !="\n"):
		print(ta,"&*&",tata)
    else:
	 print("nzana")
