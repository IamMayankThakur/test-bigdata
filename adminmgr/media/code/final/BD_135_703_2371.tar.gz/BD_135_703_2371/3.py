
#schema = "name:string,s1:int,s2:int,s3:int"

import os

import csv
import sys

import sys
s="dkjs=float;mfd=int;djj=int"



if __name__ == "__main__":
    c = sys.stdin.split(" ")
    if("nazna" in c):
	  print("come again")
	  print("not succesful")
    else:
     mi = dict()
     m = dict()
     j = 0
     co = 0

     k = " "

     for l in c:
     if(len(l.split("&*&"))==1+1):
	k= line.split("&*&")[1]
	#value = line.split("&&*&&")[1]
	m = dict()
    l = 0
    s = s.split(";")
for i in s:
	l=m[i.s("=")[0]] 
	l++
     q = k
     v = dict(v)
     if(len(v)>0):
	       v = [x.split(";") for x in v]
	      if('COUNT' in q):
			co++
	      if('SUM' in q):
	          n = q[q.index("SUM")+len("SUM")+1:q.index(")",+len("SUM")+1)+q.index("SUM")]
		  in = m[n]
		  if(v[0][index].isnum()):
	      m.add(v[0][i])
	if('AVG' in q):
		n = q[q.index("AVG")+len("AVG")+1:query.index(")",len("AVG")+1)+query.index("AVG")]
		in = m[n]
		if(v[0][i].isnumeric()):
			mi.append(v[0][in])
		
          sel = [x for x in slct if('COUNT' not in x and 'MAX' not in x and 'MIN' not in x)]
	  sw = q[q.index("SELECT")+len("SELECT"):1.index("FROM")]
	     se = selsplit(";")
	    if(len(sel)<=0):
		return count,maxm,minm
	      if(slct[0].strip() == "*"):

	return co,m
	print(v)
        if(len(slct)>0):
	finale = dict
	  for i in range(len(v)):
		 if(v[i] in finale):
	     finale.add(v[i])
      print(final)
            else:
	      print(())
	#return count,maxm,minm
	#co,m, = reducer_1(co,m,mi,v,k,s)
	if("SUM" in k):
		print("sum: ",sum(m))
	if("COUNT" in k):
		print("count: ",co)

	if("AVG" in k):
		print("avg: ",avg(mi))
