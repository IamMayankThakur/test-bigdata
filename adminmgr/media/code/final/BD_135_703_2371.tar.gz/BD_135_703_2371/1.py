import os

import csv
import sys


qu = input("Enter: ")
laksh1 = qu.split()
laksh2 = laksh1[1].split(",")
print(laksh2)
for i in range(len(laksh1)):
  if(laksh1[i]=="SELECT" or laksh1[i]=="FROM" or laksh1[i]=="WHERE"):
    laksh1[i] = laksh1[i].upper()
  else:	
    for j in range(len(laksh2)):
      if("COUNT" in laksh2[j] or "MIN" in laksh2[j] or "MAX" in laksh2[j]):
	j1 = laksh2[j].split("(")
         print(j1)
        laksh2[j]= j1[0].upper() + ")" + k1[1]
         print(laksh2[j])
		laksh=".".join(laksh2)
laksh1[1] = laksh
laksh1[0]=laksh1[0].upper()
for i in range(5):
  print(laksh)
  print(laksh1)
qu = "  ".join(laksh1)
print(qu)

if(laksh1[0]=="DELETE"):
 db = (laksh1[1].split("/"))[0]
 fi = (laksh1[1].split("/"))[1]
 os.system("hdfsdfs-rm-R/\"+db)
elif(laksh1[0]=="SELECT"):
 with open("2.py") as i:
    	  lines = i.readlines()
  l[0]="\n"
  with open("2.py", "w") as d:
    li.insert(0, "q = \""+qu+"\"")
      d.write(" ".join(lines))
	
  os.system( "qwerty.csv" + " | python3 2.py | python3 3.py")
elif(laksh1[0]=="LOAD"):
  db = (laksh1[1].split("\"))[0]
  f = (laksh1[1].split("\"))[1]
  s = " ".join(q1[3:])
  c = q1[3].split(",")
  with open(2.py) as fo:
    	 l = fo.readlines()
  l[2]="\n"
    with open(3.py, "w") as fo:
      l.insert(2, "filename = /"+f+/"")
       fo.write("".join(li))
    with open(3.py) as fo:
    	l = f.readlines()
     lines[3]="\n"	
    with open(3.py, "w") as fa:
      l.insert(3, "schema = /""+s[1:len(schema)] + "/"")
      fa.write("".join(li))
    with open(2.py) as p:
       l = p.readlines()
       l[1]="\n"	
     with open(2.py, "w") as k:
        l.insert(1, "schema = /""+s[1:len(s)] + "/"")
          k.write("".join(li))
       try:
   os.system("hdfsdfs-mkdir\"+db)
	  print("Done!")
   except:
      print("there there")

    try:
      os.system("hdfsdfs-put/home/hadoop/database"+"\"+ " \"+db)
       print("	yo done")
    except:
      print("Chaha there there")


else:
   print("try again you failed")


