import random
import csv
#import pandas as pd  
import collections
import re
import sys
from operator import add

from pyspark.sql import SparkSession

bat_clust = dict()
bowl_clust = dict()
team1 = ['PA Patel','JC Buttler',
'RG Sharma',
'N Rana',
'AT Rayudu',
'KH Pandya',
'KA Pollard',
'HH Pandya',
'TG Southee',
'MJ McClenaghan',
'JJ Bumrah']

team2 = ['AB Dinda',
'DL Chahar',
'AB Dinda',
'BA Stokes',
'Imran Tahir',
'DL Chahar',
'Imran Tahir',
'BA Stokes',
'A Zampa',
'R Bhatia',
'A Zampa',
'R Bhatia',
'BA Stokes',
'R Bhatia',
'Imran Tahir',
'A Zampa',
'Imran Tahir',
'AB Dinda',
'BA Stokes',
'AB Dinda']

"""files = pd.read_csv('probability_computation/player_to_player.csv')  #Reading from the probability file 
for i in range(len(files)):
	batname = files.loc[i].batsman.strip()     #Keys of dictionary are batsman name and values are cluster number
	bat_clust[batname] = files.loc[i].batclustno
	bowlname = files.loc[i].bowler.strip()   #Keys of dictionary are bowler name and values are cluster number
	bowl_clust[bowlname] = files.loc[i].bowlclustno

#Input for the match to be simulated
with open('squad1.csv') as csvFile:
	reader = csv.reader(csvFile)
	next(reader)
	for row in reader:
		team1.append(row[0])
		team2.append(row[1])
csvFile.close()

clust = pd.read_csv('probability_computation/clust_to_clust.csv')
clust_prob = pd.DataFrame(columns=['batclustno','bowlclustno','0', '1', '2', '3', '4',  '6','notout'])
for i in range(len(clust)):
	clust_prob.at[i] = [None for n in range(9)]
	clust_prob.at[i,'batclustno'] = clust.at[i,'batclustno']	       
	clust_prob.at[i,'bowlclustno'] = clust.at[i,'bowlclustno']
	clust_prob.at[i,'0'] = float(clust.at[i,'0'])                            #Finding cumulative probabilities
	clust_prob.at[i,'1'] = float(clust.at[i,'1']) + float(clust.at[i,'0'])
	clust_prob.at[i,'2'] = float(clust.at[i,'2']) + float(clust_prob.at[i,'1'])
	clust_prob.at[i,'3'] = float(clust.at[i,'3']) + float(clust_prob.at[i,'2'])
	clust_prob.at[i,'4'] = float(clust.at[i,'4']) + float(clust_prob.at[i,'3'])
	clust_prob.at[i,'6'] = float(clust.at[i,'6']) + float(clust_prob.at[i,'4'])
	clust_prob.at[i,'notout'] = 1 - float(clust.at[i,'out'])

player_prob = pd.read_csv('player_cumprob.csv')"""
spark = SparkSession\
		.builder\
		.appName("PythonPageRank")\
		.getOrCreate()
rd1 = spark.read.text("/home/sonu/project/pvsp1.txt").rdd.map(lambda r: r[0]) #playvsplay
rd11 = rd1.collectAsMap()
rd2 = spark.read.text("/home/sonu/project/op_clusprob1.txt").rdd.map(lambda r: r[0]) #clusprob
rd12 = rd2.collectAsMap()
rd3 = spark.read.text("/home/sonu/project/op_bat_f.txt").rdd.map(lambda r: r[0]) #batsmanclus
rd13 = rd3.collectAsMap()
rd4 = spark.read.text("/home/sonu/project/op_bow_f.txt").rdd.map(lambda r: r[0]) #bowlclus
rd14 = rd4.collectAsMap()

def playerprob(batsman,bowler):
	#row = player_prob.loc[player_prob['batsman'] == batsman].loc[player_prob['bowler'] == bowler]
	key = tuple((batsman,bowler))
	l = rd11[key]
	rand = random.random()
	#format of l is: [[],[],deli,wicki]
	if rand <= l[1][0]:                         
		return 0				    
	elif  (rand > (l[1][0]) and rand <=(l[1][1])):                     
		return 1
	elif (rand > (l[1][1]) and rand <=(l[1][2])):
		return 2
	elif (rand > (l[1][2]) and rand <=(l[1][3])):
		return 3
	elif  (rand > (l[1][3]) and rand <=(l[1][4])):
		return 4
	elif (rand > (l[1][4]) and rand <=(l[1][5])):
		return 6

def clusterprob(bat_clust_no,bowl_clust_no):
	#row = clust_prob.loc[clust_prob['batclustno'] == bat_clust_no].loc[clust_prob['bowlclustno'] == bowl_clust_no]
	rand = random.random()
	key = tuple((bat_clus_no,bowl_clus_no))
	l=rd12[key]
	rand = random.random()
	#format of l is: [[],[],wicki]
	if rand <= l[1][0]:                         
		return 0				    
	elif  (rand > (l[1][0]) and rand <=(l[1][1])):                     
		return 1
	elif (rand > (l[1][1]) and rand <=(l[1][2])):
		return 2
	elif (rand > (l[1][2]) and rand <=(l[1][3])):
		return 3
	elif  (rand > (l[1][3]) and rand <=(l[1][4])):
		return 4
	elif (rand > (l[1][4]) and rand <=(l[1][5])):
		return 6

def wick(batsman,bowler):
	key = tuple((batsman,bowler))
	l=rd1.lookup(key)	
	return l[3]

def deli(batsman,bowler):
	key = tuple((batsman,bowler))
	l=rd11[key]
	return l[3]
def bat_clus(striker):
	key =tuple((striker))
	l=rd13[key]
	return l[0]

def bowl_clus(bowler):
	key=tuple((bowler))
	l=rd14[key]
	return l[0]

def innings1(team1, team2):
	striker = team1[0]
	non_striker = team1[1]
	bowler = team2[len(team2)-1]
	nextbatsman = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	dic = {}
	dic[striker] = 1
	dic[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		while(balls<=6 and wick <10):
			score = 0
			flag =0
			#nprob = nprob*prob
			there = dict.get(tuple(striker,bowler), "Not Present")
			if(there == "Not Present"):
				a = rd13[tuple((striker))]
				b = rd14[tuple((bowler))]
				l = rd12[tuple((a[0],b[0]))]
				wick = l[2] #CHECK the format
				dic[striker] = dic[striker] - wick
				if (dic[striker] > 0.5):
					score = clusterprob(bat_clus(striker),bowl_clust(bowler))
				elif (dic[striker] < 0.5):
					wick = wick+1
					striker = team1[nextbatsman]
					nextbatsman = (nextbatsman+1)%11
					flag = 1
					dic[striker] = 1
				
			else:
				li = rd11[tuple((striker,bowler))]
				wick = li[2] #CHECK the format
				dic[striker] = dic[striker] - wick
				if (dic[striker] > 0.5):
					if (deli(striker,bowler)>=15):
						score = playerprob(striker,bowler)
					else:
						score = clusterprob(bat_clus(striker),bowl_clust(bowler))
				elif (dic[striker] < 0.5):
					wick = wick+1
					striker = team1[nextbatsman]
					nextbatsman = (nextbatsman+1)%11
					flag = 1
					dic[striker] = 1
			if(flag==0):
				runs = runs+score
				if (score==1 or score == 3):
					striker,non_striker = non_striker,striker
			balls = balls+1
		#striker,non_striker = non_striker,striker                 
		bowler = team2[len(team2)-count]                    
		count = (count+1)%5 + 1 
		overs = overs+1
		print("{0:10d} {1:10d}".format(overs, runs))
		#print(overs, runs)
	return runs,wick


"""def innings2(team1, team2,runs1):
	striker = team1[0]
	non_striker = team1[1]
	bowler = team2[len(team2)-1]
	nextbatsman = 2
	wick = 0
	runs = 0
	overs = 0
	prob = 0
	count = 2
	nprob = 1
	dic = {}
	dic[striker] = 1
	dic[non_striker]=1
	while(overs<20 and wick < 10):
		balls = 1
		#cl = 0
		
		while(balls<=6 and runs<=runs1 and wick <10):
			try:
				row = player_prob.loc[player_prob['batsman'] == striker].loc[player_prob['bowler'] == bowler]
				prob = float(row['notout'])
			except:
				row = clust_prob.loc[clust_prob['batclustno'] == bat_clust[striker]].loc[clust_prob['bowlclustno'] == bowl_clust[bowler]]
				prob = float(row['notout'])
				cl = 1
				
			score = 0
			flag = 0
			#nprob = nprob*prob
			if(wick(striker,bowler))
			dic[striker] = dic[striker]-wick(striker,bowler)
			#print(striker,dic[striker])
			if (dic[striker] > 0.5):
				#if cl==0:
				if (deli(striker,bowler)>=15):
					score = playerprob(striker,bowler)
				else:
					score = clusterprob(bat_clust[striker],bowl_clust[bowler])
						
				#else:
					#print(striker,bowler)
					#score = clusterprob(bat_clust[striker],bowl_clust[bowler])
			elif dic[striker] < 0.5:
				wick = wick+1
				striker = team1[nextbatsman]
				nextbatsman = (nextbatsman+1)%11
				flag = 1
				dic[striker] = 1
			if(flag==0):
				runs = runs+score
				if (score==1 or score == 3):
					striker,non_striker = non_striker,striker
			balls = balls+1
		#striker,non_striker = non_striker,striker                 
		bowler = team2[len(team2)-count]                    
		count = (count+1)%5 + 1 
		overs = overs+1
		print("{0:10d}|{1:10d}".format(overs, runs))
		#print(overs, runs)
		if (runs>runs1):
			break
	return runs,wick"""

print("First Innings")
print("Overs{:10d}|{:10d}Runs")
runs1 ,wicks1 = innings1(team1,team2)
print("-----------------------------------\nSecond Innings")
#print("Overs{:10d}|{:10d}Runs")
#runs2 ,wicks2 = innings2(team2,team1,runs1)
print("\nTeam 1 Score and Wickets : ", runs1, wicks1)
#print("Team 2 Score and Wickets : ", runs2, wicks2)
#if(runs1 > runs2):
	#print("Team 1 Won!!!\n")
#elif(runs1 < runs2):
#	print("Team 2 Won!!!\n")
#else:
#	print("Tie")
