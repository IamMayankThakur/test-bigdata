from __future__ import print_function

import re
import sys
from operator import add

from pyspark.sql import SparkSession

def startswithoutball(x):
	parts = re.split(r',', x)
	if(parts[0]!='ball'):
		return False
	else:
		return True

def pairandruns(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	runs = parts[7]
	key = batsman+','+bowler
	return key, runs 

def pairanddels(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	key = batsman+','+bowler
	return key, int(1)

def cntfunc(x):
	cntli = [0.0,0.0,0.0,0.0,0.0,0.0]
	for i in x:
		if(float(i) == 0.0):
			cntli[0]+=1
		if(float(i) == 1.0):
			cntli[1]+=1
		if(float(i) == 2.0):
			cntli[2]+=1
		if(float(i) == 3.0):
			cntli[3]+=1
		if(float(i) == 4.0):
			cntli[4]+=1
		if(float(i) == 6.0):
			cntli[5]+=1
	
	return cntli

def probfunc(x):
	deli = float(x[0])
	probli = [0.0,0.0,0.0,0.0,0.0,0.0]
	for i in range(0,len(x[1])):
		probli[i] = round((x[1][i]/deli),4)
	return probli

def cumfunc(x):
	li = []
	li.append(x)
	cumli = [0.0,0.0,0.0,0.0,0.0,0.0]
	cumli[0] = x[0]
	for i in range(1,len(x)):
		cumli[i] = cumli[i-1]+x[i]

		
	li.append(cumli)
	return li

def wickcnt(s):
	count = 0
	for outc in s:
		if(outc =='caught' or outc =='bowled' or outc =='caught and bowled' or outc =='lbw' or outc == 'stumped' or outc =='hit wicket' or outc == 'obstructing the field'):
			count +=1
	return count

def wickbydeli(x):
	return float(x[0])/float(x[1])

def pairandwicks(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	wickets = parts[9]
	key = batsman+','+bowler
	return key, wickets

def func1(x):
	prob = x[2][0][0][0]
	cum = x[2][0][0][1]
	deli = x[2][0][1]
	wick = x[2][1]
	return (x[0],x[1],prob,cum,deli,wick)

def func2(x):
	prob = x[1][0]
	cum = x[1][1]
	#deli = x[2][0][1]
	wick = x[1][2]
	return (x[0],[prob,cum,wick])



def splitbb(x):
	key = x[0].split(',')
	return key[0], key[1], x[1]

def app_clus(lba,lbo,x):
	ba = []
	cb =[]
	bo = []
	cbo = []
	batinx = x[0]
	clus = -1
	bclus = -1
	bowinx = x[1]
	
	for i in lba:
		ba.append(i[0])
		cb.append(int(i[1]))
	for i in lbo:
		bo.append(i[0])
		cbo.append(int(i[1]))
	l = []

	if batinx in ba:
		bind = ba.index(batinx)
		clus = cb[bind]
		l.append([batinx,clus])
	else:
		l.append([batinx,clus])
	if bowinx in bo:
		boind = bo.index(bowinx)
		bclus = cbo[boind]
		l.append([bowinx,bclus])
	else:
		l.append([bowinx,bclus])
	l.append(x[2])
	l.append(x[3])
	l.append(x[4])
	l.append(x[5])
	return ((clus,bclus),list(x))

def probclus(x):
	l=[0.0,0.0,0.0,0.0,0.0,0.0]
	cuml=[0.0,0.0,0.0,0.0,0.0,0.0]
	wick = 0
	for i in x:
		for j in range(len(i[2])):
			l[j] += i[2][j]
			cuml[j] += i[3][j]
		wick +=i[5]
	return (l,cuml,wick)

def cntfunc2(x):
	l = len(x)
	return l

def clusprob1(x):
	lo = []
	li = []
	cum = []
	for i in range(len(x[0][0])):
		li.append(round((x[0][0][i]/x[1]),5))
		cum.append(round((x[0][1][i]/x[1]),5))
	wicki = round(x[0][2]/float(x[1]),5)
	lo.append(li)
	lo.append(cum)
	lo.append(wicki)
	return lo

def rem(x):
	if(x[0][0]>=0 and x[0][1]>=0):
		return True
	else:
		return False
	



if __name__ == "__main__":
	#if len(sys.argv) != 4:
		#print("Usage: pagerank <file> <iterations> <weight>", file=sys.stderr)
		#sys.exit(-1)

	# Initialize the spark context.
	spark = SparkSession\
		.builder\
		.appName("PythonPageRank")\
		.getOrCreate()
	d={}
	lines = spark.read.text(sys.argv[1]).rdd.map(lambda r: r[0])
	bow = spark.read.text(sys.argv[2]).rdd.map(lambda r:r[0]) 
	bat = spark.read.text(sys.argv[3]).rdd.map(lambda r: r[0])
	#print(bat.collect())
	lobat = [x.split(',') for x in bat.toLocalIterator()]
	#for i in lobat:
		#print(i)
	lobow = [x.split(',') for x in bow.toLocalIterator()]
	balllines = lines.filter(lambda x: startswithoutball(x))
	runrdd = balllines.map(lambda x: pairandruns(x))  #each line with pair and the runs scored
	delrdd = balllines.map(lambda x: pairanddels(x)) #each line with pair and 1.
	deliveries = delrdd.reduceByKey(lambda x,y: x+y)
	runslist = runrdd.groupByKey().mapValues(list)
	runslistcnt = runslist.mapValues(lambda x: cntfunc(x)) 
	runcntanddel = deliveries.join(runslistcnt).mapValues(list)
	prob = runcntanddel.mapValues(lambda x: probfunc(x))
	cumprob = prob.mapValues(lambda x: cumfunc(x))

	wickrdd  = balllines.map(lambda x: pairandwicks(x))
	wicklist = wickrdd.groupByKey().mapValues(list)
	wicklistcnt = wicklist.mapValues(lambda x: wickcnt(x))
	wickanddeli = wicklistcnt.join(deliveries).mapValues(list)
	wickfinal = wickanddeli.mapValues(lambda x: wickbydeli(x))
	cumprobdeli = cumprob.join(deliveries).join(wickfinal).mapValues(list)
	finalrdd = cumprobdeli.map(lambda x: splitbb(x))
	modi = finalrdd.map(lambda x: func1(x))
	#print(modi.take(5))
	lines1 = modi.map(lambda x:app_clus(lobat,lobow,x))
	#print(lines1.take(5))
	lines2 = lines1.groupByKey().mapValues(list) #gruped  by key where key =(0,2),[[],[],[]]
	#print(lines2.take(5))
	proflistcnt = lines2.mapValues(lambda x: cntfunc2(x)) #((0,2),2332)
	clusprob = lines2.mapValues(lambda x:probclus(x))
	#print(clusprob.take(5))
	jclusprob = clusprob.join(proflistcnt).mapValues(list)
	#print(jclusprob.take(5))
	fallclusprob = jclusprob.mapValues(lambda x: clusprob1(x)) #all combi with -1
	#print(fallclusprob.collect())
	fclusprob = fallclusprob.filter(lambda x:rem(x))
	#print(fclusprob.collect())
	modiabc = fclusprob.map(lambda x: func2(x))
	#print(fclusprob.collect())
	for i in modiabc.collect():
		print(i)
	#probrdd = lines1.map(lambda x:probclus(x))
	#print(probrdd.collect())
