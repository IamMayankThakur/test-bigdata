from __future__ import print_function

import sys

import numpy as np
import re
from pyspark import SparkContext


"""def parseVector(line):
	p = re.split(r',', kvp)
	if((p[1]==''and p[2]==''and p[3]==''and p[4]==''and p[5]==''and p[6]=='' and p[7]==''and p[8]==''and p[9]==''and p[10]==''and p[11]=='' and p[12]==''and p[13]==''and p[14]=='') !=1):
		return (p[0],float(p[1]),float(p[2]),float(p[3]))
    return np.array([float(x) for x in line.split(' ')])"""

def parseVector(line):
	p = re.split(r',', line)
	if((p[1]==''and p[2]==''and p[3]==''and p[4]==''and p[5]==''and p[6]=='' and p[7]==''and p[8]==''and p[9]==''and p[10]==''and p[11]=='' and p[12]==''and p[13]==''and p[14]=='') !=1):
		return np.array([float(p[8]),float(p[9]),float(p[10])])
	else:
		return "nothing"
 
def parseVector1(line):
	p = re.split(r',', line)
	if((p[1]==''and p[2]==''and p[3]==''and p[4]==''and p[5]==''and p[6]=='' and p[7]==''and p[8]==''and p[9]==''and p[10]==''and p[11]=='' and p[12]==''and p[13]==''and p[14]=='') !=1):
		return (p[0],np.array([float(p[8]),float(p[9]),float(p[10])]))
	else:
		return "nothing"


def closestPoint(p, centers):
	bestIndex = 0
	closest = float("+inf")
	for i in range(len(centers)):
		tempDist = np.sum((p - centers[i]) ** 2) 
		if tempDist < closest:
			closest = tempDist
			bestIndex = i
	return bestIndex

def closestPoint1(p, centers):
	bestIndex = 0
	closest = float("+inf")
	for i in range(len(centers)):
		tempDist = np.sum((p[1] - centers[i]) ** 2) 
		if tempDist < closest:
			closest = tempDist
			bestIndex = i
	return (p[0],bestIndex)




if __name__ == "__main__":

	if len(sys.argv) != 4:
		print("Usage: kmeans <file> <k> <convergeDist>", file=sys.stderr)
		exit(-1)

	"""printWARN: This is a naive implementation of KMeans Clustering and is given
	as an example! Please refer to examples/src/main/python/mllib/kmeans.py for an example on
	how to use MLlib's KMeans implementation., file=sys.stderr)"""

	sc = SparkContext(appName="PythonKMeans")
	lines = sc.textFile(sys.argv[1])
	data1 = lines.map(parseVector).cache()
	#print(data1.collect())
	data = data1.filter(lambda x:x!="nothing") 
	#print(data.collect())
	K = int(sys.argv[2])
	convergeDist = float(sys.argv[3])

	kPoints = data.takeSample(False, K, 1)
	tempDist = 1.0

	while tempDist > convergeDist:
		closest = data.map(
		lambda p: (closestPoint(p, kPoints), (p, 1)))
	#print(closest.collect())
		pointStats = closest.reduceByKey(
		lambda p1_c1, p2_c2: (p1_c1[0] + p2_c2[0], p1_c1[1] + p2_c2[1]))
		newPoints = pointStats.map(
		lambda st: (st[0], st[1][0] / st[1][1])).collect()

		tempDist = sum(np.sum((kPoints[iK] - p) ** 2) for (iK, p) in newPoints)

		for (iK, p) in newPoints:
			kPoints[iK] = p

	#print("Final centers: " + str(kPoints))
	df1 = lines.map(parseVector1).cache()
	df = df1.filter(lambda x:x!="nothing")
	df2 = df.map(lambda p :closestPoint1(p,kPoints))
	#print(df2)
	l = df2.collect()
	for i in l:
		#print('%s,%s' % (str(i[0]).strip(),i[1]))
		print('((%s),%s)' % (str(i[0]).strip(),[i[1]]))
		#print(t)

	sc.stop()
