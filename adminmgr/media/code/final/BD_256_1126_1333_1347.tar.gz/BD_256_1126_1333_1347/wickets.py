from __future__ import print_function

import re
import sys
from operator import add

from pyspark.sql import SparkSession

def startswithoutball(x):
	parts = re.split(r',', x)
	if(parts[0]!='ball'):
		return False
	else:
		return True

def pairandruns(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	runs = parts[7]
	key = batsman+','+bowler
	return key, runs 

def pairanddels(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	key = batsman+','+bowler
	return key, int(1)

def pairandwicks(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	wickets = parts[9]
	key = batsman+','+bowler
	return key, wickets

def cntfunc(x):
	cntli = [0.0,0.0,0.0,0.0,0.0,0.0]
	for i in x:
		if(float(i) == 0.0):
			cntli[0]+=1
		if(float(i) == 1.0):
			cntli[1]+=1
		if(float(i) == 2.0):
			cntli[2]+=1
		if(float(i) == 3.0):
			cntli[3]+=1
		if(float(i) == 4.0):
			cntli[4]+=1
		if(float(i) == 6.0):
			cntli[5]+=1
	
	return cntli

def wickcnt(s):
	count = 0
	for outc in s:
		if(outc =='caught' or outc =='bowled' or outc =='caught and bowled' or outc =='lbw' or outc == 'stumped' or outc =='hit wicket' or outc == 'obstructing the field'):
			count +=1
	return count

def wickbydeli(x):
	return float(x[0])/float(x[1])
	
def probfunc(x):
	deli = float(x[0])
	probli = [0.0,0.0,0.0,0.0,0.0,0.0]
	for i in range(0,len(x[1])):
		probli[i] = round((x[1][i]/deli),4)
	return probli

def cumfunc(x):
	li = []
	li.append(x)
	cumli = [0.0,0.0,0.0,0.0,0.0,0.0]
	cumli[0] = x[0]
	for i in range(1,len(x)):
		cumli[i] = cumli[i-1]+x[i]

		
	li.append(cumli)
	return li
				
	
	


if __name__ == "__main__":
	#if len(sys.argv) != 4:
		#print("Usage: pagerank <file> <iterations> <weight>", file=sys.stderr)
		#sys.exit(-1)

	# Initialize the spark context.
	spark = SparkSession\
		.builder\
		.appName("PythonPageRank")\
		.getOrCreate()

	lines = spark.read.text(sys.argv[1]).rdd.map(lambda r: r[0])
	#print(lines.collect())
	balllines = lines.filter(lambda x: startswithoutball(x))
	#print(balllines.collect())
	runrdd = balllines.map(lambda x: pairandruns(x))  #each line with pair and the runs scored
	delrdd = balllines.map(lambda x: pairanddels(x)) #each line with pair and 1.
	deliveries = delrdd.reduceByKey(lambda x,y: x+y)

	#wickets code
	wickrdd  = balllines.map(lambda x: pairandwicks(x))
	wicklist = wickrdd.groupByKey().mapValues(list)
	wicklistcnt = wicklist.mapValues(lambda x: wickcnt(x))
	wickanddeli = wicklistcnt.join(deliveries).mapValues(list)
	print(wickanddeli.take(5))
	wickfinal = wickanddeli.mapValues(lambda x: wickbydeli(x))
	print(wickfinal.take(5))


	#print(runrdd.collect())
	
	#print(deliveries.collect())
	#print(deliveries)
	#runslist = runrdd.groupByKey().values()
	runslist = runrdd.groupByKey().mapValues(list)
	runslistcnt = runslist.mapValues(lambda x: cntfunc(x)) 
	#print(runslistcnt.collect())
	runcntanddel = deliveries.join(runslistcnt).mapValues(list)
	#print(runcntanddel.take(5))
	prob = runcntanddel.mapValues(lambda x: probfunc(x))
	#print(prob.collect())
	cumprob = prob.mapValues(lambda x: cumfunc(x))
	#print(cumprob.collect())
	
	

