from __future__ import print_function
#import pyspark.implicits._

from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer
from pyspark.ml import Pipeline
from pyspark.sql.functions import col
import re
import sys

# $example on$
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating
# $example off$

def ballonly(x):
    if(('info' in x) or ('version' in x)):
        return False
    else:
        return True

def pairandruns(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	runs = parts[7]
	key = batsman+','+bowler
	return key, int(runs)
 
def pairanddels(x):
	parts = re.split(r',', x)
	batsman = parts[4]
	bowler = parts[6]
	key = batsman+','+bowler
	return key, int(1)
def rates(x):
	return (float(x[0])/float(x[1]))/6.000

def getbatsmen(x):
	parts = re.split(r',', x)
	return parts[4]

def getbowlers(x):
	parts = re.split(r',', x)
	return parts[6]

def cnt0(x):
	cnt0=0
	for i in x:
		if(float(i) == 0.0):
			cnt0+=1
	return cnt0

def cnt1(x):
	cnt1=0
	for i in x:
		if(float(i) == 1.0):
			cnt1+=1
	return cnt1
def cnt2(x):
	cnt2=0
	for i in x:
		if(float(i) == 2.0):
			cnt2+=1
	return cnt2

def cnt3(x):
	cnt3=0
	for i in x:
		if(float(i) == 3.0):
			cnt3+=1
	return cnt3

def cnt4(x):
	cnt4=0
	for i in x:
		if(float(i) == 4.0):
			cnt4+=1
	return cnt4

def cnt6(x):
	cnt6=0
	for i in x:
		if(float(i) == 6.0):
			cnt6+=1
	return cnt6

def probfunc(x):
	deli = float(x[0])
	probli = 0.0
	probli = round((x[1]/deli),6)
	return probli

def cumfunc(x):
	li = []
	li.append(x)
	cumli = [0.0,0.0,0.0,0.0,0.0,0.0]
	cumli[0] = round(x[0],6)
	for i in range(1,len(x)):
		cumli[i] = round(cumli[i-1]+x[i],6)

		
	li.append(cumli)
	return li

def listing(x):
	l1=[]
	if(x[0][0][0][0][0] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[0][0][0][0][0]),6))
	if(x[0][0][0][0][1] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[0][0][0][0][1]),6))
	if(x[0][0][0][1] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[0][0][0][1]),6))
	if(x[0][0][1] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[0][0][1]),6))
	if(x[0][1] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[0][1]),6))
	if(x[1] < 0):
		l1.append(0.00)
	else:
		l1.append(round(float(x[1]),6))
	return l1
	
def norm(x):
	s = sum(x)
	l1 = []
	for i in x:
		l1.append(round(float(i/s),6))	
	return l1	
			
#################################################################################			

if __name__ == "__main__":
    sc = SparkContext(appName="PythonCollaborativeFiltering")
    spark = SparkSession(sc)
    # $example on$
    # Load and parse the data
    
    batman = 'RG Sharma'
    bowman = 'Sandeep Sharma'
     
    #batman = str(sys.argv[2])
    #bowman = str(sys.argv[3])


    data = sc.textFile(sys.argv[1])
    balldata=data.filter(ballonly)
    batsmen = balldata.map(lambda x: getbatsmen(x))
    bowlers = balldata.map(lambda x: getbowlers(x))
    players = batsmen.union(bowlers)
    players = players.distinct()
    players = players.zipWithIndex()
    #print(players.lookup('DA Warner'))
    d = players.collectAsMap()

   
    #################################################################################
    #print(d)
    def func1(x):
        l=[]
        pair = x[0]
        parts = pair.split(',')
        rating = x[1]
        num1 = d[parts[0]]
        num2 = d[parts[1]]
        l.append(num1)
        l.append(num2)
        l.append(rating)
        return l

    runrdd = balldata.map(lambda x: pairandruns(x))
    delirdd  = balldata.map(lambda x: pairanddels(x))
    runrddreduced = runrdd.reduceByKey(lambda x,y: x+y)
    delirddreduced = delirdd.reduceByKey(lambda x,y: x+y)
    runslist = runrdd.groupByKey().mapValues(list)


    l = [(d[batman],d[bowman])]
    testdata = sc.parallelize(l)

    #################################################################################
    #For 0:
    runslistcnt0 = runslist.mapValues(lambda x: cnt0(x)) 
    runcntanddel0 = delirddreduced.join(runslistcnt0).mapValues(list)
    prob0 = runcntanddel0.mapValues(lambda x: probfunc(x))
   
    rate0 = prob0.map(lambda x: func1(x))
    ratings0 = rate0.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model0 = ALS.train(ratings0, rank, numIterations)

    # Evaluate the model on training data
    
    
    
    #testdata0 = ratings0.map(lambda p: (p[0], p[1]))
    #testdata0 = "(" + str(d[batman])+ ","+ str(d[bowman]) + ")"
    predictions0 = model0.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions0.collect())
    #ratesAndPreds0 = ratings0.map(lambda r: ((r[0], r[1]), r[2])).join(predictions0)
 
 
    #MSE0 = ratesAndPreds0.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error0 = " + str(MSE0))

    #################################################################################
    #For 1:
    runslistcnt1 = runslist.mapValues(lambda x: cnt1(x)) 
    runcntanddel1 = delirddreduced.join(runslistcnt1).mapValues(list)
    prob1 = runcntanddel1.mapValues(lambda x: probfunc(x))
   
    rate1 = prob1.map(lambda x: func1(x))
    ratings1 = rate1.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model1 = ALS.train(ratings1, rank, numIterations)

    # Evaluate the model on training data
    #testdata1 = ratings1.map(lambda p: (p[0], p[1]))
    
  
    predictions1 = model1.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions1.take(15))
    #ratesAndPreds1 = ratings1.map(lambda r: ((r[0], r[1]), r[2])).join(predictions1)
 
 
    #MSE1 = ratesAndPreds1.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error0 = " + str(MSE1))

    #################################################################################
    #For 2:
    runslistcnt2 = runslist.mapValues(lambda x: cnt2(x)) 
    runcntanddel2 = delirddreduced.join(runslistcnt2).mapValues(list)
    prob2 = runcntanddel2.mapValues(lambda x: probfunc(x))
   
    rate2 = prob2.map(lambda x: func1(x))
    ratings2 = rate2.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model2 = ALS.train(ratings2, rank, numIterations)

    # Evaluate the model on training data
    #testdata2 = ratings2.map(lambda p: (p[0], p[1]))
  
    predictions2 = model2.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions2.take(15))
    #ratesAndPreds2 = ratings2.map(lambda r: ((r[0], r[1]), r[2])).join(predictions2)
 
 
    #MSE2 = ratesAndPreds2.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error2 = " + str(MSE2))
    #################################################################################
    #For 3:
    runslistcnt3 = runslist.mapValues(lambda x: cnt3(x)) 
    runcntanddel3 = delirddreduced.join(runslistcnt3).mapValues(list)
    prob3 = runcntanddel3.mapValues(lambda x: probfunc(x))
   
    rate3 = prob3.map(lambda x: func1(x))
    ratings3 = rate3.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model3 = ALS.train(ratings3, rank, numIterations)

    # Evaluate the model on training data
    #testdata3 = ratings3.map(lambda p: (p[0], p[1]))
  
    predictions3 = model3.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions3.take(15))
    #ratesAndPreds3 = ratings3.map(lambda r: ((r[0], r[1]), r[2])).join(predictions3)
 
 
    #MSE3 = ratesAndPreds3.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error 3= " + str(MSE3))

    #################################################################################
    #For 4:
    runslistcnt4 = runslist.mapValues(lambda x: cnt4(x)) 
    runcntanddel4 = delirddreduced.join(runslistcnt4).mapValues(list)
    prob4 = runcntanddel4.mapValues(lambda x: probfunc(x))
   
    rate4 = prob4.map(lambda x: func1(x))
    ratings4 = rate4.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model4 = ALS.train(ratings4, rank, numIterations)

    # Evaluate the model on training data
    #testdata4 = ratings4.map(lambda p: (p[0], p[1]))
  
    predictions4 = model4.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions4.take(15))
    #ratesAndPreds4 = ratings4.map(lambda r: ((r[0], r[1]), r[2])).join(predictions4)
 
 
    #MSE4 = ratesAndPreds4.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error 4= " + str(MSE4))

    #################################################################################
    #For 6:
    runslistcnt6 = runslist.mapValues(lambda x: cnt6(x)) 
    runcntanddel6 = delirddreduced.join(runslistcnt6).mapValues(list)
    prob6 = runcntanddel6.mapValues(lambda x: probfunc(x))
   
    rate6 = prob6.map(lambda x: func1(x))
    ratings6 = rate6.map(lambda l:(int(l[0]), int(l[1]), float(l[2])))

    # Build the recommendation model using Alternating Least Squares
    rank = 5
    numIterations = 5
    model6 = ALS.train(ratings6, rank, numIterations)

    # Evaluate the model on training data
    #testdata6 = ratings6.map(lambda p: (p[0], p[1]))
  
    predictions6 = model6.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
    #print(predictions6.take(15))
    #ratesAndPreds6 = ratings6.map(lambda r: ((r[0], r[1]), r[2])).join(predictions6)
 
 
    #MSE6 = ratesAndPreds6.map(lambda r: (r[1][0] - r[1][1])**2).mean()
    #print("Mean Squared Error 6= " + str(MSE6))

    ###################################################################################
  
    finalprob = predictions0.join(predictions1).mapValues(list).join(predictions2).mapValues(list).join(predictions3).mapValues(list).join(predictions4).mapValues(list).join(predictions6).mapValues(list)
    #print("\nprobabilites")
    #print(finalprob.take(2)) 
    
    finalprob1 = finalprob.mapValues(lambda x: listing(x)) 
    #print("\nwith list probabilites")
    #print(finalprob1.take(2)) 

    finalprob2 = finalprob1.mapValues(lambda x: norm(x)) 
    #print("\nwith list probabilites normalised")
    #print(finalprob1.take(5))    
   

    finalcumprob = finalprob2.mapValues(lambda x: cumfunc(x)) 
    print("\ncumulative probabilites")
    print(finalcumprob.take(2)) 
'''
    # Save and load model
    model.save(sc, "/home/prakruti")
    sameModel = MatrixFactorizationModel.load(sc, "/home/prakruti")
    # $example off$

    together = runrddreduced.join(delirddreduced).mapValues(list)
    ratings2 = together.mapValues(lambda x: rates(x))
'''
