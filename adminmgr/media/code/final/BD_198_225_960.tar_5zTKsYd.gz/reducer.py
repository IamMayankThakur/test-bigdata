#! /usr/bin/python
import sys
count=0
l=[]
l1=[]
d=1
for line1 in sys.stdin:
    line=line1.strip('\n')
    main_split=line.split("=")
    #print(main_split)
    a=main_split[0].split("+")          
    a.pop(-1)           
    com=main_split[1].strip("\n")
    c=com.split(";")
    comp=c[0]
    row=c[1].split("@")
    #print(row)
    #print(row)
    row_f=row[1].split(",")[0]
    #print(row_f)
    
    l.append([a,float(line1.split(",")[1].strip('\n'))])              
    count=count+1
#print(row_f)
if(comp=='MAX'):
    print(row_f)
    a=max(l, key=lambda x: x[1])[0]
    print(" ".join(a))
elif(comp=='MIN'):
    print(row_f)
    a=min(l, key=lambda x: x[1])[0]
    print(" ".join(a))
elif(comp=='count'):
    print("count"+"\n"+str(count))
else:
    print(row_f)
    for i in range(len(l)):
        #print(row_f)
        #print(x)
        print(" ".join(l[i][0]))

