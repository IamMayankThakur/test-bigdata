import shlex, subprocess
'''shreya+test.txt=at1:String,at2:String
line="select at1,at5 from test where at1 = a AND at5 > 2 MIN at1 ;"'''

import shutil


c=30
mydict={}
l=[]
def line_appender(filename, line):
    with open(filename, 'r+') as f:
        content = f.read()
        f.seek(0, 0)
        f.write(line.rstrip('\r\n') + '\n' + content)
def line_prepender(filename,line):
   from_file = open(filename) 
   line1 = from_file.readline()
   line1=line
   to_file = open(filename,mode="w")
   to_file.write(line+"\n")
   shutil.copyfileobj(from_file, to_file)

def extract_tablename(query):
    l=query.split(" ")
    return l[l.index("from")+1]
	
def send_to_mapper(line,table):
    a=line.split("+")[1].split("=")
    tn=a[0]
    #print(tn)
    l=[]
    if tn==table:
        schem=a[1].split(",")
        #print(schem)
        for i in schem:
            l.append(i.split(":")[0])
        line_appender("mapper.py","a1="+"\""+" ".join(l)+"\"")
    
	

print("Welcome\n")
while(True):
    print("Choose any one of the options(Enter 1,2,3,4,5 or 6)\n1.Show databases\n2.Load a new database\n3.Delete a database\n4.Add file into database\n5.Write a query\n6.Exit")
    x=input()
    if x=='1':
        cmd3="hadoop fs -ls /"
        args3 = shlex.split(cmd3)
        p=subprocess.Popen(args3).wait()
    if x=='2':
        db=input("Enter the name of the databse\n")
        cmd="hdfs dfs -mkdir /"+db
        args = shlex.split(cmd)
        p=subprocess.Popen(args).wait()
        #Load db into HDFS
    if x=='3':
        db=input("Enter the name of the database to be deleted\n")
        cmd="hdfs dfs -rm -r /"+db
        args = shlex.split(cmd)
        p=subprocess.Popen(args).wait()
    elif x=='4':
        dict1={}
        c=1
        try:
            print("Type LOAD <db_name>/<file_name> AS <tablename> (column_name1:datatype,column_name2:datatype) ;\n")
            add_csv=input()
            list_string=add_csv.split(" ")
            
            db_name=list_string[1].split("/")[0]
            csv_name=list_string[1].split("/")[1]
            table_name=list_string[3]
            schema=list_string[4]
            schema=schema.strip("(")
            schema=schema.strip(")")
            dict1[table_name]=schema
            if db_name not in mydict.keys():
                mydict[db_name]=dict1
            f=open("schema.txt", "w+")
            for k,v in mydict.items():
                f.write(k+"+")
                for ke,val in v.items():
                    f.write(ke+"="+val)
            f.close() 
            cmd= "hdfs dfs -put "+csv_name+" /"+db_name
            args = shlex.split(cmd)
            p=subprocess.Popen(args).wait()
            l.append([csv_name,table_name])
        except:
            print("Type correct syntax")
    elif x=='5':
        try:
            #db=input("Enter the database name you want to query a table from\n")
            csv="doesn't exist"
            line_prepender("mapper.py","")
            query=input("Write your query\n")
            #print("line="+"\""+query+"\"")
            table=extract_tablename(query)
            '''for i in l:
                if table in i:
                    csv=i[1]
            if csv=="doesn't exist":
                 print(csv+"\n")
                 break
            #print(table)'''
            with open('schema.txt') as fp:
                for line in fp:
                    send_to_mapper(line,table)
        except:
            print("Type correct syntax")
        
        line_appender("mapper.py","line="+"\""+query+"\"")
        cmd="hadoop jar /home/hadoop/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -files /home/hadoop/mapper.py,/home/hadoop/reducer.py -mapper \"python3 mapper.py\" -reducer \"python3 reducer.py\" -input /try/Iris.csv -output /try/"+str(c)
        
        args = shlex.split(cmd)
        p=subprocess.Popen(args).wait()
        cmd2="hadoop fs -get /try/"+str(c)
        args2 = shlex.split(cmd2)
        p=subprocess.Popen(args2).wait()
        cam="cat "+str(c)+"/part-00000"
        c=c+1
        args3 = shlex.split(cam)
        p=subprocess.Popen(args3).wait()
	
            
    elif x=='6':
        exit()


