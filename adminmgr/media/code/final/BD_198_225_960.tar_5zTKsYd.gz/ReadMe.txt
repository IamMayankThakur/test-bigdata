Problem statement :
Implementing sql queries using map-reduce.
Implementation:
There are three files :-
1)interface.py
2)mapper.py
3)reducer.py

interface.py internally runs mapper.py and reducer.py on Hadoop.

When we run interface.py, it asks us to select from 6 options.

1)If we type 1, it will show all the databases present.
2)Allows us to add a new database ( we can simply enter the database name).
3)Allows us to delete a database.
4)This option is used to load a file onto Hadoop.
   FORMAT: 
   LOAD <db_name>/<file_name> AS <tablename> (column_name1:datatype,column_name2:datatype) ;

Note:- We need to change the csv file name and the database in interface.py  #112 according to our requirement.

<interface.py 112>
cmd="hadoop jar /home/hadoop/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -files /home/hadoop/mapper.py,/home/hadoop/reducer.py -mapper \"python3 mapper.py\" -reducer \"python3 reducer.py\" -input /<database_name>/<csv name> -output /try/"+str(c)     

5)Here, we query the data.
Working queries:
       	select * from <tablename>  ;
	select <colname1>,<colname2> where colname1 = <val1> AND colname2 = <val2> ;
	select <colname1>,<colname2> where colname1 = <val1> MAX colname1 ;
 
Aggregations that can be applied : MAX,MIN,count

6) exits from the program.
Note:- 
1)MAX and MIN cannot be used on string datatype.
2)The query should be space separated ending with a semi-colon.
3)The csv file should not contain any header.
      
