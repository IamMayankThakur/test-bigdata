from pyspark.sql import SparkSession
from pyspark.ml.feature import StandardScaler
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans

s = SparkSession.builder.appName('cricket').getOrCreate()

bat_fp = s.read.csv('/Project/Input/batsmen2016.csv', header=True, inferSchema=True)
bowl_fp = s.read.csv('/Project/Input/bowler2016.csv', header=True, inferSchema=True)

bat_cols = ['Ave','SR']
bowl_cols = ['Econ', 'SR']

#bat_fp.printSchema()#bat_fp.show(3)	

def clustering(fp, cols):
	assem = VectorAssembler(inputCols=cols, outputCol='features')
	assembled_data = assem.transform(fp)
	scaler = StandardScaler(inputCol='features', outputCol='scaledFeatures')
	print('dkks' scaler)
	#scaler.show()
	scaler_m = scaler.fit(assembled_data)
	scaled_d = scaler_m.transform(assembled_data)

	#scaled_d.printSchema()
	#scaled_d.show(4)
	#scaled_d.select('scaledFeatures').show()

	k_means = KMeans(featuresCol='scaledFeatures', k=10) #clusters = KMeans(fp, 5, maxIterations=10, initializationMode="random")#clusters.show()
	model_k7 = k_means.fit(scaled_data)
	model_k7_data = model_k7.transform(scaled_data)
	#details = model_k7_data
	#model_k7_data.groupBy('prediction').count().show()
	#details.show(50)
	return model_k7_data

bat_d = clustering(bat_fp, bat_cols)
bowl_d = clustering(bowl_fp, bowl_cols)

print("\n~~~~~~~~~~~~~~~~~~~ BATSMEN CLUSTER DETAILS ~~~~~~~~~~~~~~~~~~~\n")
bat_d.show(50)
bat_d.groupBy('prediction').count().show()

print("\n~~~~~~~~~~~~~~~~~~~ BOWLER CLUSTER DETAILS ~~~~~~~~~~~~~~~~~~~\n")
bowl_d.show(50)
bowl_d.groupBy('prediction').count().show()
