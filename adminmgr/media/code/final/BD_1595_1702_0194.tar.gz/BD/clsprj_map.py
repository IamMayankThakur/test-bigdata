import sys
from csv import reader

loadquery = input()
st_ind = loadquery.index('/')
end_ind = loadquery.index('.')
f = loadquery[st_ind+1:end_ind]
st_ind = loadquery.index('(')
end_ind = loadquery.index(')')
l1 = loadquery[st_ind+1:end_ind].split(',')
l2 = []
for i in l1:
 l2.append(i.split(":"))
headings = list(dict(l2).keys())

filename = "/usr/local/Downloads/hadoop/yarn_data/hdfs/" + f + ".csv"

database_name = open(filename,'r')
infile = database_name.readlines()

query = input()
aggr_func = ["SUM","COUNT","AVG","MAX","MIN"]

boolean = False
for func in aggr_func:
 if func in query:
  boolean = True
  FUNCTION = func
print(boolean)

if "where" in query:
 ind = query.index("where")
 st_ind = query.index(" ",ind)
 end_ind = query.index(";")
 select_attr = query[st_ind+1:end_ind].split('=')

if boolean == True:
 ind = query.index(FUNCTION)
 st_ind = ind + len(FUNCTION) + 1
 comma = query.index(',')
 grp_att = query[7:comma]
 theta = query[ind:st_ind-1]
 end_ind = query.index(')')
 theta_attr = query[st_ind:end_ind]
 print('%s' % theta)
 try:
  for line in infile[1:]:
   line = line.strip()
   my_list = line.split(';')
   if "where" in query:
    if my_list[headings.index(select_attr[0])] == select_attr[1]:
     a = my_list[headings.index(grp_att)]
     b = my_list[headings.index(theta_attr)]
     print('%s,%s' % (a,b))
   else:
    a = my_list[headings.index(grp_att)]
    b = my_list[headings.index(theta_attr)]
    print('%s,%s' % (a,b))
 except:
  print("Column Name Not Found")
else:
 if '*' not in query:
  st_ind = query.index(' ')
  end_ind = query.index(' ',st_ind+1)
  l = query[st_ind+1:end_ind].split(',')
 else:
  l = headings
 try:
  for line in infile[1:]:
   line = line.rstrip('\n')
   my_list = line.split(';')
   if "where" in query:
    if my_list[headings.index(select_attr[0])] == select_attr[1]:
     t = [my_list[headings.index(i)] for i in l]
     for i in t:
      if t.index(i) != len(t)-1:
       print(i,end=' ')
      else:
       print(i,end='')
     print(':',end='')
     for i in t:
      if t.index(i) != len(t)-1:
       print(i,end=' ')
      else:
       print(i)
   else:
    t = [my_list[headings.index(i)] for i in l]
    for i in t:
     if t.index(i) != len(t)-1:
      print(i,end=' ')
     else:
      print(i,end='')
    print(':',end='')
    for i in t:
     if t.index(i) != len(t)-1:
      print(i,end=' ')
     else:
      print(i)
 except:
  print("Column Name Not Found")
