import sys
dic = {}
infile = list(sys.stdin)
boolean = infile[0].rstrip("\n")

def aggregate(func,d):
 try:
  for key in d:
   if func == 'sum':
    d[key] = sum(d[key])
   elif func == 'count':
    d[key] = len(d[key])
   elif func == 'avg':
    d[key] = sum(d[key])/d[key].count(d[key][0])
   elif func == 'max':
    d[key] = max(d[key])
   elif func == 'min':
    d[key] = min(d[key])
   print('%s %s' % (key,d[key]))
 except:
  print("TypeError:Strings cannot be aggregated")

if boolean == "True":
 theta = infile[1].rstrip("\n")
 for line in infile[2:]:
  line = line.rstrip("\n")
  line_val = line.split(',')
  if line_val[0] in dic:
   if line_val[1] != '':
    dic[line_val[0]].append(int(line_val[1]) if line_val[1].isnumeric() else line_val[1])
   else:
    dic[line_val[0]].append(0)
  else:
   dic[line_val[0]] = []
 aggregate(theta.lower(),dic)
else:
 for line in infile[1:]:
  line = line.rstrip("\n")
  line_val = line.split(':')
  if line_val[0] in dic:
   dic[line_val[0]].append(line_val[0])
  else:
   dic[line_val[0]] = [line_val[0]]
 for key in dic:
  print(key)


  
 
